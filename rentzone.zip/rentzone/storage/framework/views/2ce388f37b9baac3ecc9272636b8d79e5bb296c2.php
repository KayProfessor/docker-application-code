

<?php $__env->startSection('content'); ?>

    <div class="container user-information-section">
        <div class="row">
            <div class="col-md-3">
                <ul id="nav-tabs-wrapper" class="nav nav-pills nav-stacked well menu-my-account">
                    <li><a href="<?php echo e(route('user.user-profile')); ?>" title="">Overview</a></li>
                    <li><a href="<?php echo e(route('user.user-edit')); ?>" title="">Profile</a></li>
                    <li class="active"><a href="<?php echo e(route('user.user-reservations')); ?>" title="">Reservations</a></li>
                </ul>
                <br>
                <ul id="nav-tabs-wrapper" class="nav nav-pills nav-stacked well menu-my-account">
                    <li class="rent-now-btn"><a href="<?php echo e(route('rent-a-car.search-car')); ?>">Rent a car</a></li>
                    <li class="rent-now-btn"><a href="<?php echo e(route('rent-a-bike.search-bike')); ?>">Rent a bike</a></li>
                    <li class="rent-now-btn"><a href="<?php echo e(route('rent-a-moto.search-moto')); ?>">Rent a moto</a></li>
                </ul>
            </div>

            <div class="col-md-9">

            <div class="col-md-4">
                <img class="img-responsive img-rounded" src="<?php echo e(Auth::user()->photo ? Auth::user()->photo['file'] : 'http://via.placeholder.com/200x200'); ?>" alt="">
            </div>

            <div class="col-md-8">
                <h1 class="name"><?php echo e(Auth::user()->name); ?></h1>
                <?php if(Auth::user()->email): ?>
                    <p><i class="fa fa-envelope-o" aria-hidden="true"></i> <?php echo e(Auth::user()->email); ?></p>
                <?php endif; ?>
                <?php if(Auth::user()->phone): ?>
                    <p><i class="fa fa-phone" aria-hidden="true"></i> <?php echo e(Auth::user()->phone); ?></p>
                <?php endif; ?>
                <?php if(Auth::user()->city || Auth::user()->address): ?>
                    <p><i class="fa fa-map-marker" aria-hidden="true"></i> <?php echo e(Auth::user()->city); ?>, <?php echo e(Auth::user()->address); ?></p>
                <?php endif; ?>
            </div>

            <div class="col-md-12">
                
             <h1 class="name margin-top40">Reservations</h1>

            <?php if($rentalcars): ?>
        
                <?php $__currentLoopData = $rentalcars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rentalcar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($rentalcar->user_id == $user->id): ?>
                    
                    <table class="table-responsive-design">
                        <thead>
                        <tr>
                            <th scope="col">ID</th>
                            <th scope="col">Car</th>
                            <th scope="col">Dates & Locations</th>
                            <th scope="col">price</th>
                            <th scope="col">status</th>
                        </tr>
                        </thead>
                        <tbody>

                    <tr>
                        <td data-label="ID"><?php echo e($rentalcar->id); ?></td>
                        <td data-label="Car"><?php echo e($rentalcar->car->name); ?></td>

                        <td data-label="Dates & Locations" align="left" width="90%"><a data-toggle="popover" data-trigger="click" data-content="<table class='table table-bordered'>
                       <tr>
                        <td>Pickup Location:</td><td><?php echo e($rentalcar->pickupConfiguration->location); ?></td>
                        </tr>
                        <tr>
                        <td>Return Location:</td><td><?php echo e($rentalcar->returnConfiguration ? $rentalcar->returnConfiguration->location : $rentalcar->pickupConfiguration->location); ?></td>
                        </tr>
                        <tr>
                        <td>Pickup Date:</td><td><?php echo e($rentalcar->pickupDate); ?></td>
                        </tr>
                        <tr>
                        <td>Return Date:</td><td><?php echo e($rentalcar->returnDate); ?></td>
                        </tr>
                        <tr>
                        <td>Pickup Time:</td><td><?php echo e($rentalcar->pickupTime); ?></td>
                        </tr>
                        <tr>
                        <td>Return Time:</td><td><?php echo e($rentalcar->returnTime); ?></td>
                        </tr>
                       </table>" title="Dates & Locations" data-html="true" class="btn btn-info">Dates & Locations</a>
                        </td>

                        <td data-label="price"><?php echo e($rentalcar->price); ?> $</td>

                        <td data-label="status status-<?php echo e($rentalcar->status); ?>">
                            <?php if($rentalcar->status == 0): ?>
                                <span>Pending</span>
                            <?php elseif($rentalcar->status == 1): ?>
                                <span>Your order shall be delivered</span>
                            <?php elseif($rentalcar->status == 2): ?>
                                <span>Order delivered</span>
                            <?php elseif($rentalcar->status == 3): ?>
                                <span>Car returned. Order completed</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    
                    </tbody>
                    </table>

                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

            <?php if($rentalbikes): ?>
 
                <?php $__currentLoopData = $rentalbikes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rentalbike): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($rentalbike->user_id == $user->id): ?>
                    
                    <table class="table-responsive-design">
                        <thead>
                        <tr>
                            <th scope="col">ID</th>
                            <th scope="col">Bike</th>
                            <th scope="col">Dates & Locations</th>
                            <th scope="col">price</th>
                            <th scope="col">status</th>
                        </tr>
                        </thead>
                        <tbody>

                        <tr>
                            <td data-label="ID"><?php echo e($rentalbike->id); ?></td>
                            <td data-label="Bike"><?php echo e($rentalbike->bike->name); ?></td>

                            <td data-label="Dates & Locations" align="left" width="90%"><a data-toggle="popover" data-trigger="click" data-content="<table class='table table-bordered'>
                               <tr>
                                <td>Pickup Location:</td><td><?php echo e($rentalbike->pickupConfiguration->location); ?></td>
                                </tr>
                                <tr>
                                <td>Return Location:</td><td><?php echo e($rentalbike->returnConfiguration ? $rentalbike->returnConfiguration->location : $rentalbike->pickupConfiguration->location); ?></td>
                                </tr>
                                <tr>
                                <td>Pickup Date:</td><td><?php echo e($rentalbike->pickupDate); ?></td>
                                </tr>
                                <tr>
                                <td>Return Date:</td><td><?php echo e($rentalbike->returnDate); ?></td>
                                </tr>
                                <tr>
                                <td>Pickup Time:</td><td><?php echo e($rentalbike->pickupTime); ?></td>
                                </tr>
                                <tr>
                                <td>Return Time:</td><td><?php echo e($rentalbike->returnTime); ?></td>
                                </tr>
                               </table>" title="Dates & Locations" data-html="true" class="btn btn-info">Dates & Locations</a>
                            </td>

                            <td data-label="price"><?php echo e($rentalbike->price); ?> $</td>

                            <td data-label="status status-<?php echo e($rentalbike->status); ?>">
                                <?php if($rentalbike->status == 0): ?>
                                    <span>Pending</span>
                                <?php elseif($rentalbike->status == 1): ?>
                                    <span>Your order shall be delivered</span>
                                <?php elseif($rentalbike->status == 2): ?>
                                    <span>Order delivered</span>
                                <?php elseif($rentalbike->status == 3): ?>
                                    <span>Bike returned. Order completed</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        </tbody>
                    </table>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
                            
                       
            <?php endif; ?>

            <?php if($rentalmotos): ?>
  
                            <?php $__currentLoopData = $rentalmotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rentalmoto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($rentalmoto->user_id == $user->id): ?>
                                
                                <table class="table-responsive-design">
                            <thead>
                            <tr>
                                <th scope="col">ID</th>
                                <th scope="col">Moto</th>
                                <th scope="col">Dates & Locations</th>
                                <th scope="col">price</th>
                                <th scope="col">status</th>
                            </tr>
                            </thead>
                            <tbody>

                                    <tr>
                                        <td data-label="ID"><?php echo e($rentalmoto->id); ?></td>
                                        <td data-label="Moto"><?php echo e($rentalmoto->moto->name); ?></td>

                                        <td data-label="Dates & Locations" align="left" width="90%"><a data-toggle="popover" data-trigger="click" data-content="<table class='table table-bordered'>
                           <tr>
                            <td>Pickup Location:</td><td><?php echo e($rentalmoto->pickupConfiguration->location); ?></td>
                            </tr>
                            <tr>
                            <td>Return Location:</td><td><?php echo e($rentalmoto->returnConfiguration ? $rentalmoto->returnConfiguration->location : $rentalmoto->pickupConfiguration->location); ?></td>
                            </tr>
                            <tr>
                            <td>Pickup Date:</td><td><?php echo e($rentalmoto->pickupDate); ?></td>
                            </tr>
                            <tr>
                            <td>Return Date:</td><td><?php echo e($rentalmoto->returnDate); ?></td>
                            </tr>
                            <tr>
                            <td>Pickup Time:</td><td><?php echo e($rentalmoto->pickupTime); ?></td>
                            </tr>
                            <tr>
                            <td>Return Time:</td><td><?php echo e($rentalmoto->returnTime); ?></td>
                            </tr>
                           </table>" title="Dates & Locations" data-html="true" class="btn btn-info">Dates & Locations</a>
                                        </td>

                                        <td data-label="price"><?php echo e($rentalmoto->price); ?> $</td>

                                        <td data-label="status status-<?php echo e($rentalmoto->status); ?>">
                                            <?php if($rentalmoto->status == 0): ?>
                                                <span>Pending</span>
                                            <?php elseif($rentalmoto->status == 1): ?>
                                                <span>Your order shall be delivered</span>
                                            <?php elseif($rentalmoto->status == 2): ?>
                                                <span>Order delivered</span>
                                            <?php elseif($rentalmoto->status == 3): ?>
                                                <span>Moto returned. Order completed</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    
                                    </tbody>
                        </table>

                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 
            <?php endif; ?>

            </div>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <script>
        $(function () {
            $('[data-toggle="popover"]').popover();
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>