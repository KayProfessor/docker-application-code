

<?php $__env->startSection('content'); ?>

    <?php if(($comments)): ?>

        <h1>Comments</h1>

        <table class="table-responsive-design">
            <thead>
            <tr>
                <th scope="col">ID</th>
                <th scope="col">Author</th>
                <th scope="col">Email</th>
                <th scope="col">Body</th>
                <th scope="col">View post</th>
                <th scope="col">Status</th>
                <th scope="col">Action</th>
            </tr>
            </thead>
            <tbody>

            <?php if($comments): ?>
                <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td data-label="ID"><?php echo e($comment->id); ?></td>
                        <td data-label="Author"><?php echo e($comment->author); ?></td>
                        <td data-label="Email"><?php echo e($comment->email); ?></td>
                        <td data-label="Body"><?php echo e($comment->body); ?></td>
                        <td data-label="View post"><a href="<?php echo e(route('home.post',$comment->post->id)); ?>">View post</a></td>
                        <td data-label="Status">


                            <?php if($comment->is_active == 1): ?>

                                <?php echo Form::model($comment, ['method' => 'PATCH', 'action' => ['PostsCommentsController@update', $comment->id] ]); ?>


                                <input type="hidden" name="is_active" value="0">

                                <div class="form-group">
                                    <?php echo Form::submit('Un-aprove', ['class' => 'btn btn-danger']); ?>

                                </div>

                                <?php echo Form::close(); ?>


                            <?php else: ?>

                                <?php echo Form::model( $comment, ['method' => 'PATCH', 'action' => ['PostsCommentsController@update', $comment->id] ]); ?>


                                <input type="hidden" name="is_active" value="1">

                                <div class="form-group">
                                    <?php echo Form::submit('Aprove', ['class' => 'btn btn-success']); ?>

                                </div>

                                <?php echo Form::close(); ?>


                            <?php endif; ?>

                        </td>

                        <td data-label="Action">

                            <?php echo Form::open(['method' => 'DELETE', 'action' => ['PostsCommentsController@destroy' , $comment->id] ]); ?>


                            <div class="form-group">
                                <?php echo Form::submit('Delete', ['class' => 'btn btn-danger']); ?>

                            </div>

                            <?php echo Form::close(); ?>


                        </td>

                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

            </tbody>
        </table>

    <?php else: ?>
        <h1>No comments</h1>

    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>