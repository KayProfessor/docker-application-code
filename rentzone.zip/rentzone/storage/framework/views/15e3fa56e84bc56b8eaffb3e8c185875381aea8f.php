<?php $__env->startSection('content'); ?>
<div style="margin-top:50px" class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading"><?php echo trans('home.Dashboard'); ?></div>

                <div class="panel-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <?php echo trans('home.You_are_logged'); ?> <br>
                    <?php echo trans('home.welcome'); ?> <?php echo e(Auth::user()->name); ?>. <?php echo trans('home.Go_to'); ?>

                    <?php if(Auth::user()->role): ?>
                        <?php if(Auth::user()->role->name == 'client'): ?>
                            <a style="color:#21aa48" href="<?php echo e(route('user.user-profile')); ?>"><?php echo trans('home.Profile'); ?> / <?php echo trans('home.Dashboard'); ?>  .</a>
                        <?php endif; ?>
                        <?php if(Auth::user()->role->name == 'author'): ?>
                            <a style="color:#21aa48" href="/admin/authors/<?php echo e(Auth::user()->id); ?>"><?php echo trans('home.Profile'); ?> / <?php echo trans('home.Dashboard'); ?>  .</a>
                        <?php endif; ?>
                        <?php if(Auth::user()->role->name == 'administrator'): ?>
                            <a style="color:#21aa48" href="<?php echo e(url('/admin/users')); ?>/<?php echo e(auth()->user()->id); ?>/edit"><?php echo trans('home.Profile'); ?> / <?php echo trans('home.Dashboard'); ?>  .</a>
                        <?php endif; ?>
                    <?php endif; ?>
                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>