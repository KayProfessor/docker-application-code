<?php $__env->startSection('content'); ?>
    <div class="container user-information-section">
        <div class="row">
            <div class="col-md-3">
                <ul id="nav-tabs-wrapper" class="nav nav-pills nav-stacked well menu-my-account">
                    <li><a href="<?php echo e(route('user.user-profile')); ?>" title=""><?php echo trans('home.Overview'); ?></a></li>
                    <li><a href="<?php echo e(route('user.user-edit')); ?>" title=""><?php echo trans('home.Profile'); ?></a></li>
                    <li class="active"><a href="<?php echo e(route('user.user-reservations')); ?>" title=""><?php echo trans('home.Reservations'); ?></a></li>
                </ul>
                <br>
                <ul id="nav-tabs-wrapper" class="nav nav-pills nav-stacked well menu-my-account">
                    <li class="rent-now-btn"><a href="<?php echo e(route('rent-a-car.search-car')); ?>"><?php echo trans('home.rent_a_car'); ?></a></li>
                </ul>
            </div>
            <div class="col-md-9">
            <div class="col-md-4">
                <img class="img-responsive img-rounded" src="<?php echo e(Auth::user()->photo ? Auth::user()->photo['file'] : 'http://via.placeholder.com/200x200'); ?>" alt="">
            </div>
            <div class="col-md-8">
                <h1 class="name"><?php echo e(Auth::user()->name); ?></h1>
                <?php if(Auth::user()->email): ?>
                    <p><i class="fa fa-envelope-o" aria-hidden="true"></i> <?php echo e(Auth::user()->email); ?></p>
                <?php endif; ?>
                <?php if(Auth::user()->phone): ?>
                    <p><i class="fa fa-phone" aria-hidden="true"></i> <?php echo e(Auth::user()->phone); ?></p>
                <?php endif; ?>
                <?php if(Auth::user()->city || Auth::user()->address): ?>
                    <p><i class="fa fa-map-marker" aria-hidden="true"></i> <?php echo e(Auth::user()->city); ?>, <?php echo e(Auth::user()->address); ?></p>
                <?php endif; ?>
            </div>
            <div class="col-md-12">
                
             <h1 class="name margin-top40"><?php echo trans('home.Reservations'); ?></h1>
            <?php if($rentalcars): ?>
        
                <?php $__currentLoopData = $rentalcars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rentalcar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($rentalcar->user_id == $user->id): ?>
                    
                    <table class="table-responsive-design">
                        <thead>
                        <tr>
                            <th scope="col">ID</th>
                            <th scope="col"><?php echo trans('home.Car'); ?></th>
                            <th scope="col"><?php echo trans('home.DATES_LOCATIONS'); ?></th>
                            <th scope="col"><?php echo trans('home.PRICE'); ?></th>
                            <th scope="col"><?php echo trans('home.Status'); ?></th>
                        </tr>
                        </thead>
                        <tbody>
                    <tr>
                        <td data-label="ID"><?php echo e($rentalcar->id); ?></td>
                        <td data-label="<?php echo trans('home.Car'); ?>"><?php echo e($rentalcar->car->name); ?></td>
                        <td data-label="<?php echo trans('home.DATES_LOCATIONS'); ?>" align="left" width="90%"><a data-toggle="popover" data-trigger="click" data-content="<table class='table table-bordered'>
                       <tr>
                        <td><?php echo trans('home.Pickup_Location'); ?>:</td><td><?php echo e($rentalcar->pickupConfiguration->location); ?></td>
                        </tr>
                        <tr>
                        <td><?php echo trans('home.Return_Location'); ?>:</td><td><?php echo e($rentalcar->returnConfiguration ? $rentalcar->returnConfiguration->location : $rentalcar->pickupConfiguration->location); ?></td>
                        </tr>
                        <tr>
                        <td><?php echo trans('home.Pickup_Date'); ?>:</td><td><?php echo e($rentalcar->pickupDate); ?></td>
                        </tr>
                        <tr>
                        <td><?php echo trans('home.Return_Date'); ?>:</td><td><?php echo e($rentalcar->returnDate); ?></td>
                        </tr>
                        <tr>
                        <td><?php echo trans('home.Pickup_Time'); ?>:</td><td><?php echo e($rentalcar->pickupTime); ?></td>
                        </tr>
                        <tr>
                        <td><?php echo trans('home.Return_Time'); ?>:</td><td><?php echo e($rentalcar->returnTime); ?></td>
                        </tr>
                        <tr>
                        <td><?php echo trans('home.Flight_number'); ?>:</td><td><?php echo e($rentalcar->flight_number); ?></td>
                        </tr>
                        <tr>
                        <td><?php echo trans('home.Reservation_info'); ?>:</td><td><?php echo e($rentalcar->reservation_info); ?></td>
                        </tr>
                       </table>" title="<?php echo trans('home.DATES_LOCATIONS'); ?>" data-html="true" class="btn btn-info"><?php echo trans('home.DATES_LOCATIONS'); ?></a>
                        </td>
                        <td data-label="<?php echo trans('home.PRICE'); ?>"><?php echo e($rentalcar->price); ?> $</td>
                        <td data-label="<?php echo trans('home.Status'); ?>">
                            <?php if($rentalcar->status == 0): ?>
                                <span><?php echo trans('home.Status1'); ?></span>
                            <?php elseif($rentalcar->status == 1): ?>
                                <span><?php echo trans('home.Status2'); ?></span>
                            <?php elseif($rentalcar->status == 2): ?>
                                <span><?php echo trans('home.Status3'); ?></span>
                            <?php elseif($rentalcar->status == 3): ?>
                                <span><?php echo trans('home.Status4'); ?></span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    
                    </tbody>
                    </table>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <script>
        $(function () {
            $('[data-toggle="popover"]').popover();
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>