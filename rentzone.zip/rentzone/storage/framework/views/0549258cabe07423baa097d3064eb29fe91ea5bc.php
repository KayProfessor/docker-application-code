<?php $__env->startSection('content'); ?>
    <h1><?php echo trans('home.Create'); ?> <?php echo trans('home.Moto'); ?></h1>
    <?php echo Form::open(['method' => 'POST', 'action' => 'MotoController@store', 'files'=>true]); ?>

    <?php echo $__env->make('includes.form-errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="row">
        <div class="col-md-6">
            <div class="form-group">
                <?php echo Form::label('name', Lang::get('home.Name')); ?>

                <?php echo Form::text('name', null, ['class' => 'form-control']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('branch_id', Lang::get('home.Location')); ?>

                <?php echo Form::select('branch_id', [''=> 'Choose Location'] + $branches, null, ['class' => 'form-control']); ?>

            </div>

            <div class="form-group">
                <?php ($day_price = Lang::get('home.PRICE') . '/' . Lang::get('home.Day') . '($)'); ?>
                <?php echo Form::label('price_per_day', $day_price); ?>

                <?php echo Form::text('price_per_day', null, ['class' => 'form-control']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('type', Lang::get('home.Type')); ?>

                <?php echo Form::text('type', null, ['class' => 'form-control']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('max_speed', Lang::get('home.Max_speed')); ?>

                <?php echo Form::text('max_speed', null, ['class' => 'form-control']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('max_weight', Lang::get('home.Max_weight')); ?>

                <?php echo Form::text('max_weight', null, ['class' => 'form-control']); ?>

            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group">
                <?php echo Form::label('fuel_economy', Lang::get('home.Fuel_Economy')); ?>

                <?php echo Form::text('fuel_economy', null, ['class' => 'form-control']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('engine', Lang::get('home.Engine')); ?>

                <?php echo Form::text('engine', null, ['class' => 'form-control']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('photo_id', Lang::get('home.Image')); ?>

                <?php echo Form::file('photo_id', null, ['class' => 'form-control']); ?>

            </div>
 <!--            <div class="form-group">
                <?php echo Form::submit(Lang::get('home.Create'), ['class' => 'btn btn-primary']); ?>

            </div> -->
        </div>
    </div>
    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>