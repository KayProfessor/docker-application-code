<?php $__env->startSection('content'); ?>
    <?php if(count($rentalbikes) > 0): ?>
        <h1><?php echo trans('home.Rental'); ?> <?php echo trans('home.Bikes'); ?></h1>
        <div class="col-md-12">
            <table class="table-responsive-design">
                <thead>
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col"><?php echo trans('home.Bike'); ?></th>
                    <th scope="col"><?php echo trans('home.DATES_LOCATIONS'); ?></th>
                    <th scope="col"><?php echo trans('home.PRICE'); ?></th>
                    <th scope="col"><?php echo trans('home.User_information'); ?></th>
                    <th scope="col"><?php echo trans('home.Status'); ?></th>
                    <th scope="col"><?php echo trans('home.Action'); ?></th>
                </tr>
                </thead>
                <tbody>
                <?php if($rentalbikes): ?>
                    <?php $__currentLoopData = $rentalbikes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rentalbike): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td data-label="ID"><?php echo e($rentalbike->id); ?></td>
                            <td data-label="<?php echo trans('home.Bike'); ?>"><?php echo e($rentalbike->bike->name); ?></td>
                            <td data-label="<?php echo trans('home.DATES_LOCATIONS'); ?>" align="left" width="90%"><a data-toggle="popover" data-trigger="click" data-content="<table class='table table-bordered'>
                                       <tr>
                                        <td><?php echo trans('home.Pickup_Location'); ?>:</td><td><?php echo e($rentalbike->pickupConfiguration->location); ?></td>
                                        </tr>
                                        <tr>
                                        <td><?php echo trans('home.Return_Location'); ?>:</td><td><?php echo e($rentalbike->returnConfiguration ? $rentalbike->returnConfiguration->location : $rentalbike->pickupConfiguration->location); ?></td>
                                        </tr>
                                        <tr>
                                        <td><?php echo trans('home.Pickup_Date'); ?>:</td><td><?php echo e($rentalbike->pickupDate); ?></td>
                                        </tr>
                                        <tr>
                                        <td><?php echo trans('home.Return_Date'); ?>:</td><td><?php echo e($rentalbike->returnDate); ?></td>
                                        </tr>
                                        <tr>
                                        <td><?php echo trans('home.Pickup_Time'); ?>:</td><td><?php echo e($rentalbike->pickupTime); ?></td>
                                        </tr>
                                        <tr>
                                        <td><?php echo trans('home.Return_Time'); ?>:</td><td><?php echo e($rentalbike->returnTime); ?></td>
                                        </tr>
                                       </table>" title="<?php echo trans('home.DATES_LOCATIONS'); ?>" data-html="true" class="btn btn-info"><?php echo trans('home.DATES_LOCATIONS'); ?></a>
                            </td>
                            <td data-label="price"><?php echo e($rentalbike->price); ?> $</td>
                            <td data-label="<?php echo trans('home.User_information'); ?>" align="left" width="90%"><a data-toggle="popover" data-trigger="click" data-content="<table class='table table-bordered'>
                                       <tr>
                                        <td>Name:</td><td><?php echo e($rentalbike->user->name); ?></td>
                                        </tr>
                                        <tr>
                                        <td>Email:</td><td><?php echo e($rentalbike->user->email); ?></td>
                                        </tr>
                                        <?php if($rentalbike->user->phone): ?>
                                        <tr>
                                        <td><?php echo trans('home.Phone'); ?>:</td><td><?php echo e($rentalbike->user->phone); ?></td>
                                        </tr>
                                        <?php endif; ?>
                                        <tr>
                                        <td><?php echo trans('home.City'); ?>:</td><td><?php echo e($rentalbike->user->city); ?></td>
                                        </tr>
                                        <tr>
                                        <td><?php echo trans('home.Address'); ?>:</td><td><?php echo e($rentalbike->user->address); ?></td>
                                        </tr>
                                       </table>" title="<?php echo trans('home.User_information'); ?>" data-html="true" class="btn btn-info"><?php echo trans('home.User_information'); ?></a>
                            </td>
                            <td data-label="status">
                                <?php if($rentalbike->status == 0): ?>
                                    <span><?php echo trans('home.Confirm'); ?></span>
                                <?php elseif($rentalbike->status == 1): ?>
                                    <span><?php echo trans('home.Confirmed'); ?></span>
                                <?php elseif($rentalbike->status == 2): ?>
                                    <span><?php echo trans('home.Bike'); ?> <?php echo trans('home.Delivered'); ?></span>
                                <?php elseif($rentalbike->status == 3): ?>
                                    <span><?php echo trans('home.Bike'); ?> <?php echo trans('home.Returned'); ?></span>
                                <?php endif; ?>
                            </td>
                            <td data-label="action">
                                <?php if($rentalbike->status == 0): ?>
                                    <?php echo Form::model($rentalbike, ['method' => 'PATCH', 'action' => ['RentalBikesController@update', $rentalbike->id] ]); ?>

                                    <input type="hidden" name="status" value="1">
                                    <div class="form-group">
                                        <?php echo Form::submit(Lang::get('home.Confirm'), ['class' => 'btn btn-success']); ?>

                                    </div>
                                    <?php echo Form::close(); ?>

                                <?php elseif($rentalbike->status == 1): ?>
                                    <?php ($bike_picked_up = Lang::get('home.Bike') . ' ' . Lang::get('home.Picked_Up') ); ?>
                                    <?php echo Form::model($rentalbike, ['method' => 'PATCH', 'action' => ['RentalBikesController@update', $rentalbike->id] ]); ?>

                                    <input type="hidden" name="status" value="2">
                                    <div class="form-group">
                                        <?php echo Form::submit($bike_picked_up, ['class' => 'btn btn-success']); ?>

                                    </div>
                                    <?php echo Form::close(); ?>

                                <?php elseif($rentalbike->status == 2): ?>
                                     <?php ($bike_returned = Lang::get('home.Bike') . ' ' . Lang::get('home.Returned') ); ?>
                                    <?php echo Form::model($rentalbike, ['method' => 'PATCH', 'action' => ['RentalBikesController@update', $rentalbike->id] ]); ?>

                                    <input type="hidden" name="status" value="3">
                                    <div class="form-group">
                                        <?php echo Form::submit($bike_returned, ['class' => 'btn btn-success']); ?>

                                    </div>
                                    <?php echo Form::close(); ?>

                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <h1><?php echo trans('home.Not'); ?> <?php echo trans('home.Reservations'); ?> <?php echo trans('home.Bikes'); ?></h1>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <script>
        $(function () {
            $('[data-toggle="popover"]').popover();
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>