<?php $__env->startSection('content'); ?>

    <h1>Update Car</h1>

    <div class="text-left">
        <img class="img-responsive" style="margin-bottom: 50px;max-width:400px" src="<?php echo e($car->photo ? $car->photo['file'] : 'http://via.placeholder.com/400x400'); ?>" alt="">
    </div>
    <div style="margin-bottom: 50px;" class="row">
    <div class="col-md-6">

        <?php echo Form::model($car, ['method' => 'PATCH', 'action' => ['CarController@update', $car->id], 'files'=>true]); ?>


        <div class="form-group">
            <?php echo Form::label('name', 'Name Car:'); ?>

            <?php echo Form::text('name', null, ['class' => 'form-control']); ?>

        </div>

        <div class="form-group">
            <?php echo Form::label('type_id', 'CarType'); ?>

            <?php echo Form::select('type_id', [''=> 'Choose type'] + $types, null, ['class' => 'form-control']); ?>

        </div>

        <div class="form-group">
            <?php echo Form::label('ac', 'AC:'); ?>

            <?php echo Form::select('ac', ['1'=> 'Yes', '0'=> 'No'], null, ['class' => 'form-control']); ?>

        </div>

        <div class="form-group">
            <?php echo Form::label('gearbox_id', 'CarType'); ?>

            <?php echo Form::select('gearbox_id', [''=> 'Choose gearbox'] + $gearboxes, null, ['class' => 'form-control']); ?>

        </div>

        <div class="form-group">
            <?php echo Form::label('passengers', 'No. Passengers:'); ?>

            <?php echo Form::text('passengers', null, ['class' => 'form-control']); ?>

        </div>

        <div class="form-group">
            <?php echo Form::label('doors', 'No. Doors:'); ?>

            <?php echo Form::text('doors', null, ['class' => 'form-control']); ?>

        </div>

        <div class="form-group">
            <?php echo Form::label('capacity', 'No. Suitcases:'); ?>

            <?php echo Form::text('capacity', null, ['class' => 'form-control']); ?>

        </div>

        <div class="form-group">
            <?php echo Form::label('aditional_info', 'Additional Info:'); ?>

            <?php echo Form::textarea('aditional_info', null, ['class' => 'form-control', 'rows'=>'5']); ?>

        </div>

        <div class="form-group">
            <?php echo Form::label('price_per_day_car', 'Price Car/Day ($) :'); ?>

            <?php echo Form::text('price_per_day_car', null, ['class' => 'form-control']); ?>

        </div>


    </div>

    <div class="col-md-6">


        <div class="form-group">
            <?php echo Form::label('gps', 'Optional GPS Price:'); ?>

            <?php echo Form::text('gps', null, ['class' => 'form-control']); ?>

        </div>

        <div class="form-group">
            <?php echo Form::label('baby_chair', 'Optional Baby Chair Price:'); ?>

            <?php echo Form::text('baby_chair', null, ['class' => 'form-control']); ?>

        </div>

        <div class="form-group">
            <?php echo Form::label('child_seat', 'Optional Child Seat Price:'); ?>

            <?php echo Form::text('child_seat', null, ['class' => 'form-control']); ?>

        </div>

        <div class="form-group">
            <?php echo Form::label('wifi_price', 'Optional WIFI Price:'); ?>

            <?php echo Form::text('wifi_price', null, ['class' => 'form-control']); ?>

        </div>

        <div class="form-group">
            <?php echo Form::label('snow_chains', 'Optional Snow Chains Price:'); ?>

            <?php echo Form::text('snow_chains', null, ['class' => 'form-control']); ?>

        </div>

        <div class="form-group">
            <?php echo Form::label('sky_support', 'Optional Sky Support Price:'); ?>

            <?php echo Form::text('sky_support', null, ['class' => 'form-control']); ?>

        </div>

        <div class="form-group">
            <?php echo Form::label('branch_id', 'Select Branch:'); ?>

            <?php echo Form::select('branch_id', [''=> 'Choose branch'] + $branches, null, ['class' => 'form-control']); ?>

        </div>

        <div class="form-group">
            <?php echo Form::label('fuel_id', 'Fuel Type:'); ?>

            <?php echo Form::select('fuel_id', [''=> 'Choose fuel'] + $fuels, null, ['class' => 'form-control']); ?>

        </div>

        <div class="form-group">
            <?php echo Form::label('photo_id', 'Featured Image:'); ?>

            <?php echo Form::file('photo_id', null, ['class' => 'form-control']); ?>

        </div>

        <div class="form-group">
            <?php echo Form::submit('Update Car', ['class' => 'btn btn-primary']); ?>

        </div>

        <?php echo $__env->make('includes.form-errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <?php echo Form::close(); ?>


        <?php echo Form::open(['method' => 'DELETE', 'action' => ['CarController@destroy', $car->id]]); ?>


        <div class="form-group">
            <?php echo Form::submit('Delete Car', ['class' => 'btn btn-danger']); ?>

        </div>

        <?php echo Form::close(); ?>


    </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>