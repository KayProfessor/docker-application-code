

<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <ul class="four steps steps1">
                    <li class="complete"></li>
                    <li class="complete"><a href="#">1</a><br><span class="stepstext">CHOOSE DATE</span></li>
                    <li class="complete"><a href="<?php echo e(URL::previous()); ?>">2</a><br><span class="stepstext">CHOOSE BIKE</span></li>
                    <li class="complete"><a href="#">3</a><br><span class="stepstext steplast">FINISH</span></li>
                </ul>
            </div>
        </div>
    </div>

    <div class="container">


        <?php echo Form::open(['method' => 'POST', 'action' => 'RentalBikesController@store','id'=>'final-step-form', 'files'=>true]); ?>


        <?php echo $__env->make('includes.form-errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <input type="hidden" name="branch_pickup" value="<?php echo e($branch_pickup); ?>">
        <input type="hidden" name="branch_return" value="<?php echo e($branch_return); ?>">
        <input type="hidden" name="pickupDate" value="<?php echo e($pickupDate); ?>">
        <input type="hidden" name="returnDate" value="<?php echo e($returnDate); ?>">
        <input type="hidden" name="pickupTime" value="<?php echo e($pickupTime); ?>">
        <input type="hidden" name="returnTime" value="<?php echo e($returnTime); ?>">
        <input type="hidden" name="bike_id" value="<?php echo e($bike_id); ?>">

        <?php ($date1=date_create($pickupDate)); ?>
        <?php ($date2=date_create($returnDate)); ?>
        <?php ($diff=date_diff($date1,$date2)); ?>
        <?php ($days=$diff->format("%a")); ?>
        <?php if($days == 0): ?>
            <?php ( $days = 1 ); ?>
        <?php endif; ?>

        <div class="row car-details-row">

            <div class="col-md-6 car_details">
                <button href="#" onclick="return false;" class="btn btn-rent-title">Finish</button>
                <?php $__currentLoopData = $bikes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bike): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($bike->id == $bike_id): ?>
                        <?php ($total_price = $days * $bike->price_per_day); ?>
                        <h1 class="car-name"><?php echo e($bike->type); ?> <?php echo e($bike->name); ?></h1>
                        <p class="days"> Rent for <strong><?php echo e($days); ?></strong> day/s <strong class="pull-right"><?php echo e($days * $bike->price_per_day); ?> $</strong></p>
                        <br>
                        <br>
                        <h3 class="total">Total Price: <span class="pull-right"><?php echo e($total_price); ?> $</span></h3>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="col-md-6 user_details">
                <button href="#" onclick="return false;" class="btn btn-rent-title">Personal Data</button>
                <?php if(Auth::user()): ?>
                    <p>Name and Surname: <?php echo e(Auth::user()->name); ?></p>
                    <?php if(Auth::user()->address): ?>
                        <p>Address:  <?php echo e(Auth::user()->address); ?></p>
                    <?php endif; ?>
                    <?php if(Auth::user()->phone): ?>
                        <p>Phone:  <?php echo e(Auth::user()->phone); ?></p>
                    <?php endif; ?>
                    <?php if(Auth::user()->email): ?>
                        <p>Email:  <?php echo e(Auth::user()->email); ?></p>
                    <?php endif; ?>

                <?php else: ?>
                    <div class="row">
                        <div class="form-group col-md-6">
                            <?php echo Form::label('name', 'Name:'); ?>

                            <?php echo Form::text('name', null, ['class' => 'form-control']); ?>

                        </div>
                        <div class="form-group col-md-6">
                            <?php echo Form::label('email', 'Email:'); ?>

                            <?php echo Form::email('email', null, ['class' => 'form-control']); ?>

                        </div>
                    </div>
                    <div class="row">
                        <div class="form-group col-md-6">
                            <?php echo Form::label('city', 'City:'); ?>

                            <?php echo Form::text('city', null, ['class' => 'form-control']); ?>

                        </div>
                        <div class="form-group col-md-6">
                            <?php echo Form::label('phone', 'Phone:'); ?>

                            <?php echo Form::text('phone', null, ['class' => 'form-control']); ?>

                        </div>
                    </div>

                    <div class="row">
                        <div class="form-group col-md-6">
                            <?php echo Form::label('password', 'Password:'); ?>

                            <?php echo Form::password('password', ['class' => 'form-control']); ?>

                        </div>
                        <div class="form-group col-md-6">
                            <?php echo Form::label('password_confirmation', 'Password Confirm:'); ?>

                            <?php echo Form::password('password_confirmation', ['class' => 'form-control']); ?>

                        </div>
                    </div>
                <?php endif; ?>
                <div class="form-group text-left">
                    <?php echo Form::submit('Payment on pickup', ['class' => 'btn btn-primary']); ?>

                </div>
            </div>

        </div>

        <input type="hidden" name="price" value="<?php echo e($total_price); ?>">

        <?php echo Form::close(); ?>


    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>