<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <ul class="four steps steps1">
                    <li class="complete"></li>
                    <li class="complete"><a href="#">1</a><br><span class="stepstext">CHOOSE DATE</span></li>
                    <li class="complete text-center"><a href="#">2</a><br><span class="stepstext">CHOOSE MOTO</span></li>
                    <li><a href="#">3</a><br><span class="stepstext steplast">FINISH</span></li>
                </ul>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="row">

            <?php echo Form::open(['method' => 'GET', 'action' => 'RentalMotoController@final_step','id'=>'car-rental-form', 'files'=>true]); ?>


            <div class="col-md-12">
                <button href="#" onclick="return false;" class="btn btn-rent-title">Choose Moto in 
                <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($branch->id == $branch_pickup): ?>
                        <?php echo e($branch->name); ?>

                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </button>
            </div>

            <div class="col-md-12">
                <?php echo $__env->make('includes.form-errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>

            <input type="hidden" name="branch_pickup" value="<?php echo e($branch_pickup); ?>">
            <input type="hidden" name="branch_return" value="<?php echo e($branch_return); ?>">
            <input type="hidden" name="pickupDate" value="<?php echo e($pickupDate); ?>">
            <input type="hidden" name="returnDate" value="<?php echo e($returnDate); ?>">
            <input type="hidden" name="pickupTime" value="<?php echo e($pickupTime); ?>">
            <input type="hidden" name="returnTime" value="<?php echo e($returnTime); ?>">

            <?php ($date1=date_create($pickupDate)); ?>
            <?php ($date2=date_create($returnDate)); ?>
            <?php ($diff=date_diff($date1,$date2)); ?>
            <?php ($result=$diff->format("%a")); ?>


            <div class="vehicles">
                <?php $__currentLoopData = $motos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $moto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($moto->branch->id == $branch_pickup && $moto->is_available == 1): ?>
                        <div class="rental_item col-lg-4 col-md-6">
                            <div class="wrap_img">
                                <div class="relative">
                                    <img class="featured" height="150" src="<?php echo e($moto->photo->file); ?>" alt="">
                                    <div class="flex-zone">
                                        <div class="flex-zone-inside">
                                            <a class="button-rent-it">SELECT MOTO</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="bottom">
                                    <div class="wrap_btn">
                                        <a href="#" class="btn_price">
                                            <span class="wrap_content"><span class="amount"><span price="<?php echo e($moto->price_per_day); ?>" class="price-amount"><span class="currencySymbol">$</span><?php echo e($moto->price_per_day); ?></span></span><span class="time">/ Day </span></span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="content">
                                <h3  name="<?php echo e($moto->id); ?>" class="title name"><?php echo e($moto->name); ?></h3>
                                <div class="car-type"><span><?php echo e($moto->type); ?></span></div>
                                <div class="features">
                                    <div class="container-fluid">
                                        <div class="row">
                                            <?php if($moto->max_weight): ?>
                                                <div class="feature-item odd"> <img src="<?php echo e(asset('public/img/icons/weighing-scale.png')); ?>" alt=""><span><?php echo e($moto->max_weight); ?></span></div>
                                            <?php endif; ?>
                                            <?php if($moto->max_speed): ?>
                                                <div class="feature-item eve"> <img src="<?php echo e(asset('public/img/icons/max-speed.png')); ?>" alt=""><span><?php echo e($moto->max_speed); ?></span></div>
                                            <?php endif; ?>
                                            <?php if($moto->fuel_economy): ?>
                                                <div class="feature-item odd"> <img src="<?php echo e(asset('public/img/icons/gas-pump.png')); ?>" alt=""><span><?php echo e($moto->fuel_economy); ?></span></div>
                                            <?php endif; ?>
                                            <?php if($moto->engine): ?>
                                                <div class="feature-item eve"> <img src="<?php echo e(asset('public/img/icons/motor.png')); ?>" alt=""><span><?php echo e($moto->engine); ?></span></div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <input class="moto-id required" type="hidden" name="moto_id" value="">

            <input type="hidden" name="status" value="0">

            <div id="next-step" class="col-md-12">
                <div class="form-group">
                    <?php echo Form::submit('Next step', ['class' => 'btn btn-primary']); ?>

                </div>
            </div>

            <p class="text"></p>
            <p class="total"></p>

            <div class="clearfix"></div>

            <?php echo Form::close(); ?>


        </div>
    </div> 

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

    <script>
        $(function() {
            /* parseaza car id si price*/
            $('.vehicles .rental_item').on('click', function(){

                var name = $('.name', this ).attr('name');
                $('.moto-id' ).attr( "value", name );

                $('.vehicles .rental_item .flex-zone' ).removeClass( "active");
                $('.vehicles .rental_item .flex-zone .button-rent-it' ).text( "SELECT MOTO");

                $('.flex-zone',this ).addClass( "active");
                $('.flex-zone .button-rent-it',this ).text( "SELECTED");
            });
        });
    </script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>