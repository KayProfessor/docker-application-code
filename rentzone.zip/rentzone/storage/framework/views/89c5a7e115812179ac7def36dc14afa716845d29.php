

<?php $__env->startSection('content'); ?>

    <h1>Create Moto</h1>

    <?php echo Form::open(['method' => 'POST', 'action' => 'MotoController@store', 'files'=>true]); ?>


    <?php echo $__env->make('includes.form-errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="row">
        <div class="col-md-6">

            <div class="form-group">
                <?php echo Form::label('name', 'Moto Name :'); ?>

                <?php echo Form::text('name', null, ['class' => 'form-control']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('branch_id', 'Select Location:'); ?>

                <?php echo Form::select('branch_id', [''=> 'Choose Location'] + $branches, null, ['class' => 'form-control']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('price_per_day', 'Price Car/Day ($) :'); ?>

                <?php echo Form::text('price_per_day', null, ['class' => 'form-control']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('type', 'Type:'); ?>

                <?php echo Form::text('type', null, ['class' => 'form-control']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('max_speed', 'Maximum speed supported :'); ?>

                <?php echo Form::text('max_speed', null, ['class' => 'form-control']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('max_weight', 'Maximum weight supported :'); ?>

                <?php echo Form::text('max_weight', null, ['class' => 'form-control']); ?>

            </div>

        </div>

        <div class="col-md-6">

            <div class="form-group">
                <?php echo Form::label('fuel_economy', 'Fuel Economy :'); ?>

                <?php echo Form::text('fuel_economy', null, ['class' => 'form-control']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('engine', 'Engine :'); ?>

                <?php echo Form::text('engine', null, ['class' => 'form-control']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('photo_id', 'Featured Image:'); ?>

                <?php echo Form::file('photo_id', null, ['class' => 'form-control']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::submit('Create Moto', ['class' => 'btn btn-primary']); ?>

            </div>

        </div>

    </div>

    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>