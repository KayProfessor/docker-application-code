

<?php $__env->startSection('content'); ?>

    <div style="margin-top:50px" class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">

            <?php if(Session::has('created_reservation_car')): ?>
                <div class="alert alert-success" role="alert">
                    <p><?php echo e(session('created_reservation_car')); ?></p>
                    <p>Go to <a href="<?php echo e(route('user.user-reservations')); ?>"><strong>Your Account</strong></a> to see your reservation status.</p>
                </div>
                <?php else: ?>
                    <script>window.location = "/";</script>
            <?php endif; ?>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>