<?php $__env->startSection('content'); ?>
    <h1><?php echo trans('home.Update'); ?> <?php echo trans('home.Post'); ?></h1>
    <div class="col-md-3">
        <img class="img-responsive img-rounded" src="<?php echo e($post->photo ? $post->photo['file'] : 'http://via.placeholder.com/200x200'); ?>" alt="">
    </div>
    <div class="col-md-9">
        <?php echo Form::model($post, ['method' => 'PATCH', 'action' => ['AdminPostsController@update', $post->id], 'files'=>true]); ?>

        <div class="form-group">
            <?php echo Form::label('title', Lang::get('home.TITLE')); ?>

            <?php echo Form::text('title', null, ['class' => 'form-control']); ?>

        </div>
        <div class="form-group">
            <?php echo Form::label('category_id', Lang::get('home.Category')); ?>

            <?php echo Form::select('category_id', $categories, null, ['class' => 'form-control']); ?>

        </div>
        <div class="form-group">
            <?php echo Form::label('photo_id', Lang::get('home.Photo')); ?>

            <?php echo Form::file('photo_id', null, ['class' => 'form-control']); ?>

        </div>
        <div class="form-group">
            <?php echo Form::label('body', Lang::get('home.BODY')); ?>

            <?php echo Form::textarea('body', null, ['class' => 'form-control', 'rows'=>10]); ?>

        </div>
        <?php ($update_post = Lang::get('home.Update') . ' ' . Lang::get('home.Post') ); ?>
        <?php ($delete_post = Lang::get('home.Delete') . ' ' . Lang::get('home.Post') ); ?>
<!--         <div class="form-group">
            <?php echo Form::submit($update_post, ['class' => 'btn btn-primary']); ?>

        </div> -->
        <?php echo $__env->make('includes.form-errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo Form::close(); ?>

        <?php echo Form::open(['method' => 'DELETE', 'action' => ['AdminPostsController@destroy', $post->id]]); ?>

<!--         <div class="form-group">
            <?php echo Form::submit($delete_post, ['class' => 'btn btn-danger']); ?>

        </div> -->
        <?php echo Form::close(); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>