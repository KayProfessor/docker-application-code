<?php $__env->startSection('content'); ?>

    <div id="yield-page" class="users-page">
        <h1><?php echo trans('home.Users'); ?></h1>

        <?php if(Session::has('deleted_user')): ?>
            <div class="alert alert-success" role="alert">
                <p><?php echo e(session('deleted_user')); ?></p>
            </div>

        <?php elseif(Session::has('updated_user')): ?>
            <div class="alert alert-success" role="alert">
                <p><?php echo e(session('updated_user')); ?></p>
            </div>

        <?php elseif(Session::has('created_user')): ?>
            <div class="alert alert-success" role="alert">
                <p><?php echo e(session('created_user')); ?></p>
            </div>

        <?php endif; ?>

        <table class="table-responsive-design">
            <thead>
            <tr>
                <th scope="col">ID</th>
                <th scope="col"><?php echo trans('home.Photo'); ?></th>
                <th scope="col"><?php echo trans('home.Name_and_Surname'); ?></th>
                <th scope="col">Info</th>
                <th scope="col"><?php echo trans('home.Role'); ?></th>
                <th scope="col"><?php echo trans('home.Status'); ?></th>

            </tr>
            </thead>
            <tbody>

            <?php if($users): ?>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td data-label="ID"><?php echo e($user->id); ?></td>
                        <td data-label="<?php echo trans('home.Photo'); ?>"><img height="60" src="<?php echo e($user->photo ? $user->photo->file : 'http://via.placeholder.com/200x200'); ?>" alt=""></td>
                        <td data-label="<?php echo trans('home.Name_and_Surname'); ?>"><a href="<?php echo e(route('admin.users.edit', $user->id)); ?>"><?php echo e($user->name); ?></td></a>

                        <td data-label="Info" align="left" width="90%"><a data-toggle="popover" data-trigger="click" data-content="<table class='table table-bordered'>
                                       <tr>
                                        <td>Email:</td><td><?php echo e($user->email); ?></td>
                                       </tr>
                                        <tr>
                                        <td><?php echo trans('home.Phone'); ?>:</td><td><?php echo e($user->phone); ?></td>
                                       </tr>
                                       <tr>
                                        <td><?php echo trans('home.City'); ?>:</td><td><?php echo e($user->city); ?></td>
                                       </tr>
                                       <tr>
                                        <td><?php echo trans('home.Address'); ?>:</td><td><?php echo e($user->address); ?></td>
                                       </tr>
                                       </table>" title="Characteristics" data-html="true" class="btn btn-info">Info</a>
                        </td>
                        <td data-label="<?php echo trans('home.Role'); ?>"><?php echo e($user->role ? $user->role->name : 'User has no role'); ?></td>
                        <td data-label="<?php echo trans('home.Status'); ?>"><?php echo e($user->is_active ? "Active" : "Offline"); ?></td>

                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

            </tbody>
        </table>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <script>
        $(function () {
            $('[data-toggle="popover"]').popover();
        });
    </script>

    <script>
        if($('#yield-page').hasClass('user-page')) {
            $('.cd-side-nav > ul > .users').addClass('active');
        }
        /* in loc de user-page poti sa pui current-page */
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>