<?php $__env->startSection('content'); ?>



<div class="container">

    <div class="row">

        <div class="col-md-12 col-sm-12 col-xs-12">

            <ul class="four steps steps1">

                <li class="complete"></li>

                <li class="complete"><a onclick="window.history.back(); return false;" href="#">1</a><br><span class="stepstext">CHOOSE CAR</span></li>

                <li class="complete"><a href="#">2</a><br><span class="stepstext">ADDITIONAL SERVICES</span></li>

                <li><a href="#">3</a><br><span class="stepstext steplast">FINISH</span></li>

            </ul>

        </div>

    </div>

</div>



<div class="container">



    <?php echo Form::open(['method' => 'GET', 'action' => 'RentalCarsController@final_step','id'=>'additional-services-form', 'files'=>true]); ?>




    <input type="hidden" name="branch_pickup" value="<?php echo e($branch_pickup); ?>">

    <input type="hidden" name="branch_return" value="<?php echo e($branch_return); ?>">

    <input type="hidden" name="pickupDate" value="<?php echo e($pickupDate); ?>">

    <input type="hidden" name="returnDate" value="<?php echo e($returnDate); ?>">

    <input type="hidden" name="pickupTime" value="<?php echo e($pickupTime); ?>">

    <input type="hidden" name="returnTime" value="<?php echo e($returnTime); ?>">

    <input type="hidden" name="car_id" value="<?php echo e($car_id); ?>">



    <?php ($date1=date_create($pickupDate)); ?>

    <?php ($date2=date_create($returnDate)); ?>

    <?php ($diff=date_diff($date1,$date2)); ?>

    <?php ($days=$diff->format("%a")); ?>

    <?php if($days == 0): ?>

        <?php ( $days = 1 ); ?>

    <?php endif; ?>



    <div class="row additional-services-row">

    <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <?php if($car->id == $car_id): ?>



            <?php if($car->gps || $car->child_seat || $car->baby_chair || $car->wifi_price || $car->snow_chains || $car->sky_support): ?>

                <div class="col-md-12">

                    <button href="#" onclick="return false;" class="btn btn-rent-title">Additional Services</button>

                </div>

            <?php endif; ?>



            <div class="clearfix"></div>



            

            <?php if($car->gps): ?>

                <div class="col-md-4 echipamentebox">

                    <input name="car_gps" id="echipamente6" class="echipamente hidden" type="checkbox" value="<?php echo e($car->gps * $days); ?>">

                    <label for="echipamente6">

                        <div class="serviciibox">

                            <div class="col-md-4 boxright">

                                <img class="pull-left" width="64" height="64" src="<?php echo e(asset('/public/img/additionals/gps.png')); ?>" title="">

                            </div>

                            <div class="col-md-8 zi9 boxleft">

                                <span class="titleechipament titleechipament6">gps</span>

                                <p price="<?php echo e($car->gps); ?>" class="echipamentep echipamentep6"><?php echo e($car->gps); ?> $ /day</p>

                            </div>

                        </div>

                    </label>

                </div>

            <?php endif; ?>

            

            <?php if($car->child_seat): ?>

                <div class="col-md-4 echipamentebox">

                    <input name="child_seat" id="echipamente5" class="echipamente hidden" type="checkbox" value="<?php echo e($car->child_seat * $days); ?>">

                    <label for="echipamente5">

                        <div class="serviciibox">

                            <div class="col-md-4 boxright">

                                <img class="pull-left" width="64" height="64" src="<?php echo e(asset('/public/img/additionals/child_seat.png')); ?>" title="">

                            </div>

                            <div class="col-md-8 zi9 boxleft">

                                <span class="titleechipament titleechipament5">child seat</span>

                                <p price="<?php echo e($car->child_seat); ?>" class="echipamentep echipamentep5"><?php echo e($car->child_seat); ?> $ /day</p>

                            </div>

                        </div>

                    </label>

                </div>

            <?php endif; ?>

            

            <?php if($car->baby_chair): ?>

                <div class="col-md-4 echipamentebox"><input name="baby_chair" id="echipamente4" class="echipamente hidden" type="checkbox" value="<?php echo e($car->baby_chair * $days); ?>">

                    <label for="echipamente4">

                        <div class="serviciibox">

                            <div class="col-md-4 boxright">

                                <img class="pull-left" width="64" height="64" src="<?php echo e(asset('/public/img/additionals/baby_seat.png')); ?>" title="">

                            </div>

                            <div class="col-md-8 zi9 boxleft">

                                <span class="titleechipament titleechipament4">baby chair</span>

                                <p price="<?php echo e($car->baby_chair); ?>" class="echipamentep echipamentep4"><?php echo e($car->baby_chair); ?> $ /day</p>

                            </div>

                        </div>

                    </label>

                </div>

            <?php endif; ?>

            

            <?php if($car->wifi_price): ?>

                <div class="col-md-4 echipamentebox"><input name="wifi_price" id="echipamente3" class="echipamente hidden" type="checkbox" value="<?php echo e($car->wifi_price * $days); ?>">

                    <label for="echipamente3">

                        <div class="serviciibox">

                            <div class="col-md-4 boxright">

                                <img class="pull-left" width="64" height="64" src="<?php echo e(asset('/public/img/additionals/wifi.png')); ?>" title="">

                            </div>

                            <div class="col-md-8 zi9 boxleft">

                                <span class="titleechipament titleechipament3">wi-fi router</span>

                                <p price="<?php echo e($car->wifi_price); ?>" class="echipamentep echipamentep3"><?php echo e($car->wifi_price); ?> $ /day</p>

                            </div>

                        </div>

                    </label>

                </div>

            <?php endif; ?>

            

            <?php if($car->snow_chains): ?>

                <div class="col-md-4 echipamentebox"><input name="snow_chains" id="echipamente2" class="echipamente hidden" type="checkbox" value="<?php echo e($car->snow_chains * $days); ?>">

                    <label for="echipamente2">

                        <div class="serviciibox">

                            <div class="col-md-4 boxright">

                                <img class="pull-left" width="64" height="64" src="<?php echo e(asset('/public/img/additionals/snow_chains.png')); ?>" title="">

                            </div>

                            <div class="col-md-8 zi9 boxleft">

                                <span class="titleechipament titleechipament2">snow chains</span>

                                <p price="<?php echo e($car->snow_chains); ?>" class="echipamentep echipamentep2"><?php echo e($car->snow_chains); ?> $ /day</p>

                            </div>

                        </div>

                    </label>

                </div>

            <?php endif; ?>

            

            <?php if($car->sky_support): ?>

                <div class="col-md-4 echipamentebox"><input name="sky_support" id="echipamente1" class="echipamente hidden" type="checkbox" value="<?php echo e($car->sky_support * $days); ?>">

                    <label for="echipamente1">

                        <div class="serviciibox">

                            <div class="col-md-4 boxright">

                                <img class="pull-left" width="64" height="64" src="<?php echo e(asset('/public/img/additionals/ski_support.png')); ?>" title="">

                            </div>

                            <div class="col-md-8 zi9 boxleft">

                                <span class="titleechipament titleechipament1">sky support</span>

                                <p price="<?php echo e($car->sky_support); ?>" class="echipamentep echipamentep1"><?php echo e($car->sky_support); ?> $ /day</p>

                            </div>

                        </div>

                    </label>

                </div>

            <?php endif; ?>

        <?php endif; ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div> 



    <div class="row car-details-row">

        <div class="col-md-6 car_details">

            <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php if($car->id == $car_id): ?>

                    <h1 class="car-name"><?php echo e($car->type->name); ?> <?php echo e($car->name); ?></h1>

                    <p class="days"> Rent for <strong><?php echo e($days); ?></strong> day/s <strong class="pull-right"><?php echo e($days * $car->price_per_day_car); ?> $</strong></p>

                    <p class="additional-car-services-title">Additional Car Services</p>

                    <div id="fulloptions"></div>

                    <br>

                    <br>

                    <br>

                    <br>

                    <h3 class="total">Total Price: <span class="pull-right"><?php echo e($days * $car->price_per_day_car); ?> $</span></h3>

                    <p class="calculate hidden" price="<?php echo e($car->price_per_day_car); ?>" days="<?php echo e($days); ?>"></p>

                <?php endif; ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



            <div class="form-group">

                <?php echo Form::submit('Next step', ['class' => 'btn btn-primary']); ?>


            </div>



        </div>

        <div class="col-md-6 car_image">

            <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php if($car->id == $car_id): ?>

                    <img class="img-responsive" src="<?php echo e($car->photo ? $car->photo->file : 'http://via.placeholder.com/200x200'); ?>" alt="">

                <?php endif; ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

    </div>











    <?php echo $__env->make('includes.form-errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>



    <?php echo Form::close(); ?>




</div>



<?php $__env->stopSection(); ?>



<?php $__env->startSection('footer'); ?>

    <script>



        var price = $('.car_details .calculate').attr('price');

        var days = $('.car_details .calculate').attr('days');



        $('.echipamente:checkbox').change(function () {

            var total = days * price;

            $('input:checkbox:checked').each(function(){

                total += isNaN(parseInt($(this).val())) ? 0 : parseInt($(this).val());

            });

            $('.total').html("Total price: " + "<span class='pull-right'>" + total + " $</span>");

        });





    </script>



    <script>



        //service6



        var price6 = $('.echipamentep6').attr('price');

        var service6 = $( ".titleechipament6" ).text();

        $("#echipamente6").click(function() {

            if($('#echipamente6').is(':checked')) {

                $( "#fulloptions" ).append( '<p class="service6">' + service6 + " x " +days + " days " + "<strong class='pull-right'>" + ( price6 * days ) + " $</strong>" +  '</p>' );

            } else {

                $( ".service6" ).remove();

            }

        });

        //service5

        var price5 = $('.echipamentep5').attr('price');

        var service5 = $( ".titleechipament5" ).text();

        $("#echipamente5").click(function() {

            if($('#echipamente5').is(':checked')) {

                $( "#fulloptions" ).append( '<p class="service5">' + service5 + " x " +days + " days " + "<strong class='pull-right'>" + ( price5 * days ) + " $</strong>" +  '</p>' );

            } else {

                $( ".service5" ).remove();

            }

        });

        //service4

        var price4 = $('.echipamentep4').attr('price');

        var service4 = $( ".titleechipament4" ).text();

        $("#echipamente4").click(function() {

            if($('#echipamente4').is(':checked')) {

                $( "#fulloptions" ).append( '<p class="service4">' + service4 + " x " +days + " days " + "<strong class='pull-right'>" + ( price4 * days ) + " $</strong>" +  '</p>' );

            } else {

                $( ".service4" ).remove();

            }

        });

        //service3

        var price3 = $('.echipamentep3').attr('price');

        var service3 = $( ".titleechipament3" ).text();

        $("#echipamente3").click(function() {

            if($('#echipamente3').is(':checked')) {

                $( "#fulloptions" ).append( '<p class="service3">' + service3 + " x " +days + " days " + "<strong class='pull-right'>" + ( price3 * days ) + " $</strong>" +  '</p>' );

            } else {

                $( ".service3" ).remove();

            }

        });

        //service2

        var price2 = $('.echipamentep2').attr('price');

        var service2 = $( ".titleechipament2" ).text();

        $("#echipamente2").click(function() {

            if($('#echipamente2').is(':checked')) {

                $( "#fulloptions" ).append( '<p class="service2">' + service2 + " x " +days + " days " + "<strong class='pull-right'>" + ( price2 * days ) + " $</strong>" +  '</p>' );

            } else {

                $( ".service2" ).remove();

            }

        });

        //service1

        var price1 = $('.echipamentep1').attr('price');

        var service1 = $( ".titleechipament1" ).text();

        $("#echipamente1").click(function() {

            if($('#echipamente1').is(':checked')) {

                $( "#fulloptions" ).append( '<p class="service1">' + service1 + " x " +days + " days " + "<strong class='pull-right'>" + ( price1 * days ) + " $</strong>" +  '</p>' );

            } else {

                $( ".service1" ).remove();

            }

        });



    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>