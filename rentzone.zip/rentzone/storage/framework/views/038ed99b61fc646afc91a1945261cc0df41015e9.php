

<?php $__env->startSection('content'); ?>



    <h1>Create Car</h1>

    <?php echo Form::open(['method' => 'POST', 'action' => 'CarController@store', 'files'=>true]); ?>


    <?php echo $__env->make('includes.form-errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="row">
    <div class="col-md-6">

    <div class="form-group">
        <?php echo Form::label('name', 'Car Name :'); ?>

        <?php echo Form::text('name', null, ['class' => 'form-control']); ?>

    </div>

    <div class="form-group">
        <?php echo Form::label('type_id', 'Car Type'); ?>

        <?php echo Form::select('type_id', [''=> 'Choose type'] + $types, null, ['class' => 'form-control']); ?>

    </div>

    <div class="form-group">
        <?php echo Form::label('ac', 'AC:'); ?>

        <?php echo Form::select('ac', ['1'=> 'Yes', '0'=> 'No'], null, ['class' => 'form-control']); ?>

    </div>

    <div class="form-group">
        <?php echo Form::label('gearbox_id', 'Gearbox Type:'); ?>

        <?php echo Form::select('gearbox_id', [''=> 'Choose gearbox'] + $gearboxes, null, ['class' => 'form-control']); ?>

    </div>

    <div class="form-group">
        <?php echo Form::label('passengers', 'No. Passengers:'); ?>

        <?php echo Form::text('passengers', null, ['class' => 'form-control']); ?>

    </div>

    <div class="form-group">
        <?php echo Form::label('doors', 'No. Doors:'); ?>

        <?php echo Form::text('doors', null, ['class' => 'form-control']); ?>

    </div>

    <div class="form-group">
        <?php echo Form::label('capacity', 'No. Suitcases:'); ?>

        <?php echo Form::text('capacity', null, ['class' => 'form-control']); ?>

    </div>

    <div class="form-group">
        <?php echo Form::label('aditional_info', 'Additional Info:'); ?>

        <?php echo Form::textarea('aditional_info', null, ['class' => 'form-control', 'rows'=>'5']); ?>

    </div>

    <div class="form-group">
        <?php echo Form::label('price_per_day_car', 'Price Car/Day ($) :'); ?>

        <?php echo Form::text('price_per_day_car', null, ['class' => 'form-control']); ?>

    </div>

    </div>

    <div class="col-md-6">

    <div class="form-group">
        <?php echo Form::label('gps', 'Optional GPS Price:'); ?>

        <?php echo Form::text('gps', null, ['class' => 'form-control']); ?>

    </div>

    <div class="form-group">
        <?php echo Form::label('baby_chair', 'Optional Baby Chair Price:'); ?>

        <?php echo Form::text('baby_chair', null, ['class' => 'form-control']); ?>

    </div>

    <div class="form-group">
        <?php echo Form::label('child_seat', 'Optional Child Seat Price:'); ?>

        <?php echo Form::text('child_seat', null, ['class' => 'form-control']); ?>

    </div>

    <div class="form-group">
        <?php echo Form::label('wifi_price', 'Optional WIFI Price:'); ?>

        <?php echo Form::text('wifi_price', null, ['class' => 'form-control']); ?>

    </div>

    <div class="form-group">
        <?php echo Form::label('snow_chains', 'Optional Snow Chains Price:'); ?>

        <?php echo Form::text('snow_chains', null, ['class' => 'form-control']); ?>

    </div>

    <div class="form-group">
        <?php echo Form::label('sky_support', 'Optional Sky Support Price:'); ?>

        <?php echo Form::text('sky_support', null, ['class' => 'form-control']); ?>

    </div>

    <div class="form-group">
        <?php echo Form::label('branch_id', 'Select Location:'); ?>

        <?php echo Form::select('branch_id', [''=> 'Choose location'] + $branches, null, ['class' => 'form-control']); ?>

    </div>

    <div class="form-group">
        <?php echo Form::label('fuel_id', 'CarFuel'); ?>

        <?php echo Form::select('fuel_id', [''=> 'Choose fuel'] + $fuels, null, ['class' => 'form-control']); ?>

    </div>

    <div class="form-group">
        <?php echo Form::label('photo_id', 'Featured Image:'); ?>

        <?php echo Form::file('photo_id', null, ['class' => 'form-control']); ?>

    </div>


    <div class="form-group">
        <?php echo Form::submit('Create Car', ['class' => 'btn btn-primary']); ?>

    </div>

    </div>
    </div>

    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>