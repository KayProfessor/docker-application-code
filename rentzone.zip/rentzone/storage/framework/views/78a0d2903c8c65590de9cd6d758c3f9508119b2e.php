

<?php $__env->startSection('content'); ?>

    <?php if(count($posts) > 0): ?>

    <h1>Posts</h1>

    <table class="table-responsive-design">
        <thead>
        <tr>
            <th scope="col">ID</th>
            <th scope="col">Photo</th>
            <th scope="col">Owner</th>
            <th scope="col">Title</th>
            <th scope="col">Category</th>
            <th scope="col">Body</th>
            <th scope="col">Created</th>
            <th scope="col">Updated</th>
            <th scope="col">View Post</th>
            <th scope="col">View Comments</th>
        </tr>
        </thead>
        <tbody>

        <?php if($posts): ?>
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td data-label="ID"><?php echo e($post->id); ?></td>
                    <td data-label="Photo"><img height="50" src="<?php echo e($post->photo ? $post->photo->file : 'http://via.placeholder.com/200x200'); ?>" alt=""></td>
                    <td data-label="Owner"><?php echo e($post->user->name); ?></td>
                    <td data-label="Title"><a href="<?php echo e(route('admin.posts.edit', $post->id)); ?>"><?php echo e($post->title); ?></a></td>
                    <td data-label="Category"><?php echo e($post->category ? $post->category->name : 'Uncategorized'); ?></td>
                    <td data-label="Body"><?php echo e(str_limit($post->body,6)); ?></td>
                    <td data-label="Created"><?php echo e($post->created_at->diffForHumans()); ?></td>
                    <td data-label="Updated"><?php echo e($post->updated_at->diffForHumans()); ?></td>
                    <td data-label="View Post"><a href="<?php echo e(route('home.post', $post->slug)); ?>">View Post</a></td>
                    <td data-label="View Comments"><a href="<?php echo e(route('admin.comments.show', $post->id)); ?>">View Comments</a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

        </tbody>
    </table>

    <div class="row">
        <div class="col-sm-12 text-center"><?php echo e($posts->render()); ?></div>
    </div>

    <?php else: ?>
        <h1>No Posts</h1>

    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>