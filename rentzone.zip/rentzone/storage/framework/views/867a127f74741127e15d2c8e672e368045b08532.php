<?php $__env->startSection('content'); ?>
    <?php if(count($cars) > 0): ?>
        <h1><?php echo trans('home.Cars'); ?></h1>
        <table class="table-responsive-design">
            <thead>
            <tr>
                <th scope="col">ID</th>
                <th scope="col">Name</th>
                <th scope="col"><?php echo trans('home.Image'); ?></th>
                <th scope="col"><?php echo trans('home.PRICE'); ?></th>
                <th scope="col"><?php echo trans('home.Characteristics'); ?></th>
                <th scope="col">Extra</th>
                <th scope="col"><?php echo trans('home.AVAILABLE'); ?></th>
            </tr>
            </thead>
            <tbody>
            <?php if($cars): ?>
                <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td data-label="ID"><?php echo e($car->id); ?></td>
                        <td valign="center" data-label="Name"><a href="<?php echo e(route('cars.edit', $car->id)); ?>"><?php echo e($car->name); ?></a></td>
                        <td data-label="<?php echo trans('home.Image'); ?>"><img height="50" src="<?php echo e($car->photo ? $car->photo->file : 'http://via.placeholder.com/200x200'); ?>" alt=""></td>
                        <td data-label="<?php echo trans('home.PRICE'); ?>"><?php echo e($car->price_per_day_car); ?>$</td>
                        <td data-label="<?php echo trans('home.Characteristics'); ?>" align="left" width="90%"><a data-toggle="popover" data-trigger="click" data-content="<table class='table table-bordered'>
                                       <tr>
                                        <td><?php echo trans('home.Type'); ?> <?php echo trans('home.Car'); ?>:</td><td><?php echo e($car->type->name); ?></td>
                                       </tr>
                                       <tr>
                                        <td><?php echo trans('home.ac'); ?>:</td> <td> <?php echo e(($car->ac == 1) ? 'Yes' : 'No'); ?> </td>
                                       </tr>
                                       <tr>
                                        <td><?php echo trans('home.Gearbox'); ?>:</td> <td><?php echo e($car->gearbox->name); ?></td>
                                       </tr>
                                       <tr>
                                        <td><?php echo trans('home.no.'); ?> <?php echo trans('home.Passengers'); ?>:</td> <td><?php echo e($car->passengers); ?></td>
                                       </tr>
                                       <tr>
                                        <td><?php echo trans('home.no.'); ?> <?php echo trans('home.Doors'); ?>:</td> <td><?php echo e($car->doors); ?></td>
                                       </tr>
                                       <tr>
                                        <td><?php echo trans('home.no.'); ?> <?php echo trans('home.Suitcases'); ?>:</td> <td><?php echo e($car->capacity); ?></td>
                                       </tr>
                                       <tr>
                                        <td><?php echo trans('home.Location'); ?>:</td> <td><?php echo e($car->branch->location); ?></td>
                                       </tr>
                                       <tr>
                                        <td><?php echo trans('home.Types_of_fuel'); ?>:</td> <td><?php echo e($car->fuel->name); ?></td>
                                       </tr>
                                       <tr>
                                        <td>Additional Info:</td> <td><?php echo e($car->aditional_info); ?></td>
                                       </tr>
                                       </table>" title="Characteristics" data-html="true" class="btn btn-info"><?php echo trans('home.Characteristics'); ?></a>
                        </td>
                        <td data-label="Optional Equipment:" align="left" width="80%"><a data-toggle="popover" data-trigger="click" data-content="<table class='table table-bordered'>
                                       <tr>
                                        <td><?php echo trans('home.Optional'); ?> <?php echo trans('home.GPS'); ?> <?php echo trans('home.PRICE'); ?>:</td> <td><?php echo e($car->gps); ?>$</td>
                                       </tr>
                                       <tr>
                                        <td><?php echo trans('home.Optional'); ?> <?php echo trans('home.CHILD_SEAT'); ?> <?php echo trans('home.PRICE'); ?>:</td> <td><?php echo e($car->baby_chair); ?>$</td>
                                       </tr>
                                       <tr>
                                        <td><?php echo trans('home.Optional'); ?> <?php echo trans('home.BABY_CHAIR'); ?> <?php echo trans('home.PRICE'); ?>:</td> <td><?php echo e($car->child_seat); ?>$</td>
                                       </tr>
                                       <tr>
                                        <td><?php echo trans('home.Optional'); ?> <?php echo trans('home.WI_FI_ROUTER'); ?> <?php echo trans('home.PRICE'); ?>:</td> <td><?php echo e($car->wifi_price); ?>$</td>
                                       </tr>
                                       <tr>
                                        <td><?php echo trans('home.Optional'); ?> <?php echo trans('home.SNOW_CHAIN'); ?> <?php echo trans('home.PRICE'); ?>:</td> <td><?php echo e($car->snow_chains); ?>$</td>
                                       </tr>
                                       <tr>
                                        <td><?php echo trans('home.Optional'); ?> <?php echo trans('home.SKY_SUPPORT'); ?> <?php echo trans('home.PRICE'); ?>:</td> <td><?php echo e($car->sky_support); ?>$</td>
                                       </tr>
                                       </table>" title="Extra" data-html="true" class="btn btn-info">Extra</a>
                        </td>
                        <td data-label="Available">
                            <?php if($car->is_available == 0): ?>
                                <?php echo Form::model($car, ['method' => 'PATCH', 'action' => ['CarController@update', $car->id] ]); ?>

                                <input type="hidden" name="is_available" value="1">
                                <?php echo Form::submit(Lang::get('home.Yes'), ['class' => 'btn btn-success']); ?>

                                <?php echo Form::close(); ?>

                            <?php elseif($car->is_available == 1): ?>
                                <?php echo Form::model($car, ['method' => 'PATCH', 'action' => ['CarController@update', $car->id] ]); ?>

                                <input type="hidden" name="is_available" value="0">
                                <?php echo Form::submit(Lang::get('home.Not'), ['class' => 'btn btn-danger']); ?>

                                <?php echo Form::close(); ?>

                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            </tbody>
        </table>
        
    <?php else: ?>
        <h1><?php echo trans('home.Not'); ?> <?php echo trans('home.Cars'); ?></h1>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <script>
        $(function () {
            $('[data-toggle="popover"]').popover();
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>