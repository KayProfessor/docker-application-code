<?php $__env->startSection('content'); ?>
    <div style="margin-top:50px" class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <?php if(Session::has('created_reservation_moto')): ?>
                    <div class="alert alert-success" role="alert">
                        <p><?php echo trans('home.completed_reservation1'); ?></p>
                        <p><?php echo trans('home.Go_to'); ?> <a href="<?php echo e(route('user.user-reservations')); ?>"><strong><?php echo trans('home.Your_Account'); ?></strong></a> <?php echo trans('home.completed_reservation2'); ?>.</p>
                    </div>
                <?php else: ?>
                    <script>window.location = "/";</script>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>