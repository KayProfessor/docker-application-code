<?php $__env->startSection('styles'); ?>
    <link href="<?php echo e(asset('css/libs/filter-style.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <ul class="four steps steps1">
                    <li class="completed"></li>
                    <li class="completed"><a href="#">1</a><br><span class="stepstext"><?php echo trans('home.CHOOSE_CAR'); ?></span></li>
                    <li class="text-center"><a href="#">2</a><br><span class="stepstext"><?php echo trans('home.ADDITIONAL_SERVICES'); ?></span></li>
                    <li><a href="#">3</a><br><span class="stepstext steplast"><?php echo trans('home.FINISH'); ?></span></li>
                </ul>
            </div>
        </div>
    </div>

    <div class="container">

    <?php echo $__env->make('includes.form-errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo Form::open(['method' => 'GET', 'action' => 'RentalCarsController@additional_services', 'id'=>'car-rental-form', 'files'=>true]); ?>


    


    <input type="hidden" name="branch_pickup" value="<?php echo e($branch_pickup); ?>">
    <input type="hidden" name="branch_return" value="<?php echo e($branch_return); ?>">
    <input type="hidden" name="pickupDate" value="<?php echo e($pickupDate); ?>">
    <input type="hidden" name="returnDate" value="<?php echo e($returnDate); ?>">
    <input type="hidden" name="pickupTime" value="<?php echo e($pickupTime); ?>">
    <input type="hidden" name="returnTime" value="<?php echo e($returnTime); ?>">



    <?php ($date1=date_create($pickupDate)); ?>
    <?php ($date2=date_create($returnDate)); ?>
    <?php ($diff=date_diff($date1,$date2)); ?>
    <?php ($result=$diff->format("%a")); ?>

    <main class="cd-main-content">
        <div class="vehicles cd-gallery filter-is-visible">
            <?php if($branch_return): ?>
                <?php if($branch_pickup != $branch_return): ?>

                    <div class="clearfix"></div>

                    <div style="margin: 0 15px 30px;" class="col-md-12 alert alert-info">
                        <i class="fa fa-exclamation-circle"></i>

                        <strong>
                            <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($branch->id == $branch_pickup): ?>
                                    <?php echo e($branch->name); ?>

                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </strong>
                        takeover location is different from the teaching assignment
                        <strong>
                            <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($branch->id == $branch_return): ?>
                                    <?php echo e($branch->name); ?>

                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </strong>
                        For this dislocation will be charged a fee of <b>150$</b>.
                    </div>
                <?php endif; ?>
            <?php endif; ?>

            <?php

            $interval_start = strtotime('09:00');
            $interval_end = strtotime('18:00');

            $pickup_time = strtotime($pickupTime);
            $return_time = strtotime($returnTime);

            $over_time_pickup = 0;
            $over_time_pickup_cond = 0;

            $over_time_return = 0;
            $over_time_return_cond = 0;

            $over_time = 0;

            if($interval_start <= $pickup_time && $pickup_time < $interval_end) {}
            else { $over_time_pickup = 20; $over_time_pickup_cond = 1; }

            if($interval_start <= $return_time && $return_time < $interval_end) {}
            else { $over_time_return = 20; $over_time_return_cond = 1; }

            $over_time = $over_time_pickup + $over_time_return;
            ?>



            <?php if($over_time_pickup_cond == 1 || $over_time_return_cond == 1): ?>

                <div style="margin: 0 15px 30px;" class="col-md-12 alert alert-info">
                    <i class="fa fa-exclamation-circle"></i>
                    The chosen time interval exceeds the hours of the program.
                    An Extra Hours fee of
                    <strong><?php echo e($over_time); ?>$</strong> will apply for this reservation. <br>
                    Schedule: <strong>Monday to Friday from 09:00 to 18:00.</strong>
                    <div class="clearfix"></div>
                </div>

            <?php endif; ?>

            <ul>
                <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($car->branch->id == $branch_pickup && $car->is_available == 1): ?>
                        <li class="mix <?php echo e($car->name); ?> <?php echo e($car->type->name); ?> <?php echo e($car->gearbox->name); ?>">
                            <div class="rental_item">
                                <div class="wrap_img">
                                    <div class="relative">
                                        <img class="featured" height="150" src="<?php echo e($car->photo->file); ?>" alt="">
                                        <div class="flex-zone">
                                            <div class="flex-zone-inside">
                                                <a class="button-rent-it"><?php echo trans('home.SELECT_CAR'); ?></a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="bottom">
                                        <div class="wrap_btn">
                                            <a href="#" class="btn_price">
                                                <span class="wrap_content"><span class="amount"><span price="<?php echo e($car->price_per_day_car); ?>" class="price-amount"><span class="currencySymbol">$</span><?php echo e($car->price_per_day_car); ?></span></span><span class="time">/ <?php echo trans('home.Day'); ?> </span></span>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="content">
                                    <h3  name="<?php echo e($car->id); ?>" class="title name"><?php echo e($car->name); ?></h3>
                                    <div class="car-type"><span><?php echo e($car->type->name); ?></span></div>
                                    <div class="features">
                                        <div class="container-fluid">
                                            <div class="row">
                                                <?php if($car->ac == 1): ?>
                                                    <div class="feature-item odd"> <img src="<?php echo e(asset('public/img/icons/ac.png')); ?>" alt=""><span>A/C</span></div>
                                                <?php endif; ?>
                                                <?php if($car->gearbox->name): ?>
                                                    <div class="feature-item eve">
                                                        <img src="<?php echo e(asset('public/img/icons/cog.png')); ?>" alt=""><span><?php echo e($car->gearbox->name); ?></span>
                                                    </div>
                                                <?php endif; ?>
                                                <?php if($car->fuel->name): ?>
                                                    <div class="feature-item odd">
                                                        <img src="<?php echo e(asset('public/img/icons/gas-pump.png')); ?>" alt=""><span><?php echo e($car->fuel->name); ?></span>
                                                    </div>
                                                <?php endif; ?>
                                                <?php if($car->passengers): ?>
                                                    <div class="feature-item eve">
                                                        <img src="<?php echo e(asset('public/img/icons/man.png')); ?>" alt=""><span><?php echo e($car->passengers); ?></span>
                                                    </div>
                                                <?php endif; ?>
                                                <?php if($car->capacity): ?>
                                                    <div class="feature-item odd">
                                                        <img src="<?php echo e(asset('public/img/icons/luggage.png')); ?>" alt=""><span><?php echo e($car->capacity); ?></span>
                                                    </div>
                                                <?php endif; ?>
                                                <?php if($car->doors): ?>
                                                    <div class="feature-item eve">
                                                        <img src="<?php echo e(asset('public/img/icons/doors.png')); ?>" alt=""><span><?php echo e($car->doors); ?></span>
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
             <div class="cd-fail-message">No results found</div>
        </div>

        <div class="cd-filter filter-is-visible">
                <div class="cd-filter-block">
                    <h4>Search</h4>

                    <div class="cd-filter-content">
                        <input type="search" placeholder="Try compact...">
                    </div> <!-- cd-filter-content -->
                </div> <!-- cd-filter-block -->

                <div class="cd-filter-block">
                    <h4>Transmissions</h4>
                    <ul class="cd-filter-content cd-filters list">
                        <?php $__currentLoopData = $transmissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transmission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <input class="filter" data-filter=".<?php echo e($transmission->name); ?>" type="radio" name="radioButton" id="<?php echo e($transmission->name); ?>">
                            <label class="radio-label" for="<?php echo e($transmission->name); ?>"><span><?php echo e($transmission->name); ?></span></label>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>

                <div class="cd-filter-block">
                    <h4>Class </h4>
                    <ul class="cd-filter-content cd-filters list">
                        <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <input class="filter" data-filter=".<?php echo e($type->name); ?>" type="checkbox" id="<?php echo e($type->name); ?>">
                            <label class="checkbox-label" for="<?php echo e($type->name); ?>"><span><?php echo e($type->name); ?></span></label>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>

        </div> <!-- cd-filter -->

        <a href="#0" class="cd-filter-trigger">Search Car</a>
    </main>

    <input class="car-id required" type="hidden" name="car_id" value="">

    <input type="hidden" name="status" value="0">

    <div id="next-step">
        <div class="form-group">
            <?php echo Form::submit(Lang::get('home.Next_step'), ['class' => 'btn btn-primary']); ?>

        </div>
    </div>

    <p class="text"></p>
    <p class="total"></p>

<div class="clearfix"></div>

<?php echo Form::close(); ?>


    </div> 

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <script src="<?php echo e(asset('js/libs/modernizr.js')); ?>"></script>
    <script src="<?php echo e(asset('js/libs/jquery.mixitup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/libs/filter-main.js')); ?>"></script>
    <script>
        $(function() {
            /* parseaza car id si price*/
            $('.vehicles .rental_item').on('click', function(){

                var name = $('.name', this ).attr('name');
                $('.car-id' ).attr( "value", name );

                $('.vehicles .rental_item .flex-zone' ).removeClass( "active");
                $('.vehicles .rental_item .flex-zone .button-rent-it' ).text('<?php echo __('home.SELECT_CAR') ?>');

                $('.flex-zone', this ).addClass( "active");
                $('.flex-zone .button-rent-it',this ).text('<?php echo __('home.SELECTED') ?>');

            });
        });
    </script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>