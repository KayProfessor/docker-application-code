<?php $__env->startSection('content'); ?>
    <h1><?php echo trans('home.Create'); ?> <?php echo trans('home.Car'); ?></h1>
    <?php echo Form::open(['method' => 'POST', 'action' => 'CarController@store', 'files'=>true]); ?>

    <?php echo $__env->make('includes.form-errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="row">
    <div class="col-md-6">
        <div class="form-group">
            <?php echo Form::label('name', Lang::get('home.Name')); ?>

            <?php echo Form::text('name', null, ['class' => 'form-control']); ?>

        </div>

        <div class="form-group">
            <?php echo Form::label('type_id', Lang::get('home.Type')); ?>

            <?php echo Form::select('type_id', [''=> 'Choose type'] + $types, null, ['class' => 'form-control']); ?>

        </div>

        <div class="form-group">
            <?php echo Form::label('ac', Lang::get('home.ac')); ?>

            <?php echo Form::select('ac', ['1'=> 'Yes', '0'=> 'No'], null, ['class' => 'form-control']); ?>

        </div>

        <div class="form-group">
            <?php echo Form::label('gearbox_id', Lang::get('home.Gearbox')); ?>

            <?php echo Form::select('gearbox_id', [''=> 'Choose gearbox'] + $gearboxes, null, ['class' => 'form-control']); ?>

        </div>

        <div class="form-group">
            <?php ($no_passe = Lang::get('home.no.') . ' ' . Lang::get('home.Passengers')); ?>
            <?php echo Form::label('passengers', $no_passe); ?>

            <?php echo Form::text('passengers', null, ['class' => 'form-control']); ?>

        </div>

        <div class="form-group">
            <?php ($no_doors = Lang::get('home.no.') . ' ' . Lang::get('home.Doors')); ?>
            <?php echo Form::label('doors', $no_doors); ?>

            <?php echo Form::text('doors', null, ['class' => 'form-control']); ?>

        </div>

        <div class="form-group">
            <?php ($no_suitcases = Lang::get('home.no.') . ' ' . Lang::get('home.Suitcases')); ?>
            <?php echo Form::label('capacity', $no_suitcases); ?>

            <?php echo Form::text('capacity', null, ['class' => 'form-control']); ?>

        </div>

        <div class="form-group">
            <?php echo Form::label('aditional_info', 'Additional Info:'); ?>

            <?php echo Form::textarea('aditional_info', null, ['class' => 'form-control', 'rows'=>'5']); ?>

        </div>

        <div class="form-group">
            <?php ($day_price = Lang::get('home.PRICE') . '/' . Lang::get('home.Day') . '($)'); ?>
            <?php echo Form::label('price_per_day_car', $day_price); ?>

            <?php echo Form::text('price_per_day_car', null, ['class' => 'form-control']); ?>

        </div>


    </div>

    <div class="col-md-6">


        <div class="form-group">
            <?php ($optional_gps_price = Lang::get('home.Optional') . ' ' . Lang::get('home.GPS') . ' ' . Lang::get('home.PRICE')); ?>
            <?php echo Form::label('gps', $optional_gps_price); ?>

            <?php echo Form::text('gps', null, ['class' => 'form-control']); ?>

        </div>

        <div class="form-group">
            <?php ($optional_CHILD_SEAT_price = Lang::get('home.Optional') . ' ' . Lang::get('home.CHILD_SEAT') . ' ' . Lang::get('home.PRICE')); ?>
            <?php echo Form::label('baby_chair', $optional_CHILD_SEAT_price); ?>

            <?php echo Form::text('baby_chair', null, ['class' => 'form-control']); ?>

        </div>

        <div class="form-group">
            <?php ($optional_BABY_CHAIR_price = Lang::get('home.Optional') . ' ' . Lang::get('home.BABY_CHAIR') . ' ' . Lang::get('home.PRICE')); ?>
            <?php echo Form::label('child_seat', $optional_BABY_CHAIR_price); ?>

            <?php echo Form::text('child_seat', null, ['class' => 'form-control']); ?>

        </div>

        <div class="form-group">
            <?php ($optional_wifi_price_price = Lang::get('home.Optional') . ' ' . Lang::get('home.wifi_price') . ' ' . Lang::get('home.PRICE')); ?>
            <?php echo Form::label('wifi_price', $optional_wifi_price_price); ?>

            <?php echo Form::text('wifi_price', null, ['class' => 'form-control']); ?>

        </div>

        <div class="form-group">
            <?php ($optional_SNOW_CHAIN_price = Lang::get('home.Optional') . ' ' . Lang::get('home.SNOW_CHAIN') . ' ' . Lang::get('home.PRICE')); ?>
            <?php echo Form::label('snow_chains', $optional_SNOW_CHAIN_price); ?>

            <?php echo Form::text('snow_chains', null, ['class' => 'form-control']); ?>

        </div>

        <div class="form-group">
            <?php ($optional_SKY_SUPPORT_price = Lang::get('home.Optional') . ' ' . Lang::get('home.SKY_SUPPORT') . ' ' . Lang::get('home.PRICE')); ?>
            <?php echo Form::label('sky_support', $optional_SKY_SUPPORT_price); ?>

            <?php echo Form::text('sky_support', null, ['class' => 'form-control']); ?>

        </div>

        <div class="form-group">
            <?php echo Form::label('branch_id', Lang::get('home.Branche')); ?>

            <?php echo Form::select('branch_id', [''=> 'Choose branch'] + $branches, null, ['class' => 'form-control']); ?>

        </div>

        <div class="form-group">
            <?php echo Form::label('fuel_id', Lang::get('home.Type_of_fuel')); ?>

            <?php echo Form::select('fuel_id', [''=> 'Choose fuel'] + $fuels, null, ['class' => 'form-control']); ?>

        </div>

        <div class="form-group">
            <?php echo Form::label('photo_id', Lang::get('home.Image')); ?>

            <?php echo Form::file('photo_id', null, ['class' => 'form-control']); ?>

        </div>
    <div class="form-group">
        <?php ($create_car = Lang::get('home.Create') . ' ' . Lang::get('home.Car') ); ?>
        <!-- <?php echo Form::submit($create_car, ['class' => 'btn btn-primary']); ?> -->
    </div>
    </div>
    </div>
    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>