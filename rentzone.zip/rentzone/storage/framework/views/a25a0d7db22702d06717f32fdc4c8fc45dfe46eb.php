<?php $__env->startSection('content'); ?>
    <div class="col-md-4">
        <h1><?php echo trans('home.Create'); ?> <?php echo trans('home.Branches'); ?></h1>
        <?php echo Form::open(['method' => 'POST', 'action' => 'CarBranchController@store']); ?>

        <div class="form-group">
            <?php echo Form::label('name', Lang::get('home.Name')); ?>

            <?php echo Form::text('name', null, ['class' => 'form-control']); ?>

        </div>
        <div class="form-group">
            <?php echo Form::label('email','Email'); ?>

            <?php echo Form::email('email', null, ['class' => 'form-control']); ?>

        </div>
        <div class="form-group">
            <?php echo Form::label('address', Lang::get('home.Address')); ?>

            <?php echo Form::text('address', null, ['class' => 'form-control']); ?>

        </div>
        <div class="form-group">
            <?php echo Form::label('location', Lang::get('home.Location')); ?>

            <?php echo Form::text('location', null, ['class' => 'form-control']); ?>

        </div>
        <div class="form-group">
            <?php echo Form::label('phone', Lang::get('home.Phone')); ?>

            <?php echo Form::text('phone', null, ['class' => 'form-control']); ?>

        </div>
        <?php ($create_branch = Lang::get('home.Create') . ' ' . Lang::get('home.Branch') ); ?>
        <div class="form-group">
            <?php echo Form::submit($create_branch, ['class' => 'btn btn-primary']); ?>

        </div>
        <?php echo $__env->make('includes.form-errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo Form::close(); ?>

    </div>
    <?php if(count($branches) > 0): ?>
        <div class="col-md-8">
            <h1><?php echo trans('home.Branches'); ?></h1>
            <table style="margin-bottom:50px" class="table-responsive-design">
                <thead>
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col"><?php echo trans('home.Name'); ?></th>
                    <th scope="col">Email</th>
                    <th scope="col">Info</th>
                </tr>
                </thead>
                <tbody>
                <?php if($branches): ?>
                    <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td data-label="ID"><?php echo e($branch->id); ?></td>
                            <td data-label="<?php echo trans('home.Name'); ?>"><a href="<?php echo e(route('cars.branches.edit', $branch->id)); ?>"><?php echo e($branch->name); ?></a></td>
                            <td data-label="Email"><?php echo e($branch->email); ?></td>
                            <td data-label="Info" align="left" width="90%"><a data-placement="bottom" data-toggle="popover" data-trigger="click"  data-content="<table class='table table-bordered'>
                               <tr>
                                <td><?php echo trans('home.Address'); ?>:</td><td><?php echo e($branch->address); ?></td>
                               </tr>
                               <tr>
                                <td><?php echo trans('home.Location'); ?>:</td><td><?php echo e($branch->location); ?></td>
                               </tr>
                               <tr>
                                <td><?php echo trans('home.Phone'); ?>:</td><td><?php echo e($branch->phone); ?></td>
                               </tr>
                               </table>" title="Characteristics" data-html="true" class="btn btn-info">Info</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <h1><?php echo trans('home.Not'); ?> <?php echo trans('home.Branches'); ?></h1>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <script>
        $(function () {
            $('[data-toggle="popover"]').popover();
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>