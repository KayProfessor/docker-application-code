<?php $__env->startSection('content'); ?>
    <h1><?php echo trans('home.Create'); ?> <?php echo trans('home.Post'); ?></h1>
    <?php echo Form::open(['method' => 'POST', 'action' => 'AdminPostsController@store', 'files'=>true]); ?>

    <div class="form-group">
        <?php echo Form::label('title', Lang::get('home.TITLE')); ?>

        <?php echo Form::text('title', null, ['class' => 'form-control']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('category_id', Lang::get('home.Category')); ?>

        <?php echo Form::select('category_id', [''=> 'Choose category'] + $categories, null, ['class' => 'form-control']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('photo_id', Lang::get('home.Photo')); ?>

        <?php echo Form::file('photo_id', null, ['class' => 'form-control']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('body', Lang::get('home.BODY')); ?>

        <?php echo Form::textarea('body', null, ['class' => 'form-control', 'rows'=>10]); ?>

    </div>
    <?php ($create_post = Lang::get('home.Create') . ' ' . Lang::get('home.Post') ); ?>
<!--     <div class="form-group">
        <?php echo Form::submit($create_post, ['class' => 'btn btn-primary']); ?>

    </div> -->
    <?php echo $__env->make('includes.form-errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>