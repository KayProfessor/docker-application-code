

<?php $__env->startSection('styles'); ?>

    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.5.1/min/dropzone.min.css">

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

    <h1>Upload Media</h1>

    <?php echo Form::open(['method' => 'POST', 'action' => 'AdminMediaController@store', 'class'=>'dropzone']); ?>



    <?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.5.1/min/dropzone.min.js"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>