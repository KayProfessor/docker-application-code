

<?php $__env->startSection('content'); ?>

    <h1>Create Bike</h1>

    <?php echo Form::open(['method' => 'POST', 'action' => 'BikeController@store', 'files'=>true]); ?>


    <?php echo $__env->make('includes.form-errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="row">
        <div class="col-md-6">

            <div class="form-group">
                <?php echo Form::label('name', 'Bike Name :'); ?>

                <?php echo Form::text('name', null, ['class' => 'form-control']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('branch_id', 'Select Location:'); ?>

                <?php echo Form::select('branch_id', [''=> 'Choose Location'] + $branches, null, ['class' => 'form-control']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('price_per_day', 'Price Car/Day ($) :'); ?>

                <?php echo Form::text('price_per_day', null, ['class' => 'form-control']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('type', 'Type:'); ?>

                <?php echo Form::text('type', null, ['class' => 'form-control']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('bike_for', 'Bike For :'); ?>

                <?php echo Form::text('bike_for', null, ['class' => 'form-control']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('max_weight', 'Maximum weight supported :'); ?>

                <?php echo Form::text('max_weight', null, ['class' => 'form-control']); ?>

            </div>

        </div>

            <div class="col-md-6">

                <div class="form-group">
                    <?php echo Form::label('handlebar_width', 'Handlebar width :'); ?>

                    <?php echo Form::text('handlebar_width', null, ['class' => 'form-control']); ?>

                </div>

                <div class="form-group">
                    <?php echo Form::label('wheel_size', 'Wheel size :'); ?>

                    <?php echo Form::text('wheel_size', null, ['class' => 'form-control']); ?>

                </div>

                <div class="form-group">
                    <?php echo Form::label('frame_size', 'Frame size :'); ?>

                    <?php echo Form::text('frame_size', null, ['class' => 'form-control']); ?>

                </div>

                <div class="form-group">
                    <?php echo Form::label('chain', 'Chain :'); ?>

                    <?php echo Form::text('chain', null, ['class' => 'form-control']); ?>

                </div>

                <div class="form-group">
                    <?php echo Form::label('photo_id', 'Featured Image:'); ?>

                    <?php echo Form::file('photo_id', null, ['class' => 'form-control']); ?>

                </div>

                <div class="form-group">
                    <?php echo Form::submit('Create Bike', ['class' => 'btn btn-primary']); ?>

                </div>

        </div>

    </div>

    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>