<?php $__env->startSection('content'); ?>
    <?php if(count($photos) > 0): ?>
    <h1><?php echo trans('home.Media'); ?></h1>
    <table class="table-responsive-design">
       <thead>
          <tr>
            <th scope="col">Id</th>
            <th scope="col"><?php echo trans('home.Name'); ?></th>
            <th scope="col"><?php echo trans('home.CREATED'); ?></th>
            <th scope="col"><?php echo trans('home.Action'); ?></th>
          </tr>
        </thead>
        <tbody>
        <?php if($photos): ?>
            <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td data-label="ID"><?php echo e($photo->id); ?></td>
                <td data-label="<?php echo trans('home.Name'); ?>"><img height="50" src="<?php echo e($photo->file); ?>" alt=""></td>
                <td data-label="<?php echo trans('home.CREATED'); ?>"><?php echo e($photo->created_at ? $photo->created_at : 'No date'); ?></td>
                <td data-label="<?php echo trans('home.Action'); ?>">
                    <?php echo Form::open(['method' => 'DELETE', 'action' => ['AdminMediaController@destroy', $photo->id]]); ?>

                    <?php ($delete_image = Lang::get('home.Delete') . ' ' . Lang::get('home.Image') ); ?>
                    <div class="form-group">
                        <?php echo Form::submit($delete_image, ['class' => 'btn btn-danger']); ?>

                    </div>
                    <?php echo Form::close(); ?>

                </td>
              </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
       </tbody>
     </table>
    <?php else: ?>
        <h1>No <?php echo trans('home.No_media'); ?></h1>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>