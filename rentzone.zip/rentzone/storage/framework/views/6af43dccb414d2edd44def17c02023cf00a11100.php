


<?php $__env->startSection('content'); ?>

    <?php if(count($photos) > 0): ?>

    <h1>Media</h1>

    <table class="table-responsive-design">
       <thead>
          <tr>
            <th scope="col">Id</th>
            <th scope="col">Name</th>
            <th scope="col">Created at</th>
            <th scope="col">Action</th>
          </tr>
        </thead>
        <tbody>

        <?php if($photos): ?>
            <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td data-label="ID"><?php echo e($photo->id); ?></td>
                <td data-label="Name"><img height="50" src="<?php echo e($photo->file); ?>" alt=""></td>
                <td data-label="Created at"><?php echo e($photo->created_at ? $photo->created_at : 'No date'); ?></td>
                <td data-label="Action">
                    <?php echo Form::open(['method' => 'DELETE', 'action' => ['AdminMediaController@destroy', $photo->id]]); ?>


                    <div class="form-group">
                        <?php echo Form::submit('Delete Image', ['class' => 'btn btn-danger']); ?>

                    </div>

                    <?php echo Form::close(); ?>

                </td>
              </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

       </tbody>
     </table>

    <?php else: ?>
        <h1>No Media</h1>

    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>