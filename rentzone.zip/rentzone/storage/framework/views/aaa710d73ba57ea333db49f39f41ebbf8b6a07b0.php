<?php $__env->startSection('content'); ?>
        <div class="col-md-6">
            <h1><?php echo trans('home.Create'); ?> <?php echo trans('home.Car'); ?> <?php echo trans('home.Type'); ?></h1>
            <?php echo Form::open(['method' => 'POST', 'action' => 'CarTypeController@store']); ?>

            <div class="form-group">
                <?php echo Form::label('name', 'Name:'); ?>

                <?php echo Form::text('name', null, ['class' => 'form-control']); ?>

            </div>
            <div class="form-group">
                <?php ($create_car_type = Lang::get('home.Create') . ' ' . Lang::get('home.Car') . ' ' . Lang::get('home.Type')); ?>
                <?php echo Form::submit($create_car_type, ['class' => 'btn btn-primary']); ?>

            </div>
            <?php echo $__env->make('includes.form-errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo Form::close(); ?>

        </div>
        <?php if(count($types) > 0): ?>
        <div class="col-md-6">
            <h1><?php echo trans('home.All'); ?> <?php echo trans('home.Car'); ?> <?php echo trans('home.Types'); ?></h1>
            <table class="table-responsive-design">
                <thead>
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Name</th>
                    <th scope="col"><?php echo trans('home.CREATED'); ?></th>
                    <th scope="col"><?php echo trans('home.UPDATED'); ?></th>
                </tr>
                </thead>
                <tbody>
                <?php if($types): ?>
                    <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td data-label="ID"><?php echo e($type->id); ?></td>
                            <td data-label="Name"><a href="<?php echo e(route('cars.types.edit', $type->id)); ?>"><?php echo e($type->name); ?></a></td>
                            <td data-label="<?php echo trans('home.CREATED'); ?>"><?php echo e($type->created_at ? $type->created_at->diffForHumans() : 'no date'); ?></td>
                            <td data-label="<?php echo trans('home.UPDATED'); ?>"><?php echo e($type->updated_at ? $type->updated_at->diffForHumans() : 'no date'); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <h1><?php echo trans('home.Not'); ?> <?php echo trans('home.Car'); ?> <?php echo trans('home.Types'); ?></h1>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>