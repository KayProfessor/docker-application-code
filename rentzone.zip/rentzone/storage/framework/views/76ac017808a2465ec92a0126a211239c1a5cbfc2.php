<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <ul class="four steps steps1">
                    <li class="complete"></li>
                    <li class="complete"><a href="#">1</a><br><span class="stepstext"><?php echo trans('home.CHOOSE_CAR'); ?></span></li>
                    <li class="complete"><a href="#">2</a><br><span class="stepstext"><?php echo trans('home.ADDITIONAL_SERVICES'); ?></span></li>
                    <li class="complete"><a href="#">3</a><br><span class="stepstext steplast"><?php echo trans('home.FINISH'); ?></span></li>
                </ul>
            </div>
        </div>
    </div>
    <div class="container">
    <?php echo Form::open(['method' => 'POST', 'action' => 'RentalCarsController@store','id'=>'final-step-form', 'files'=>true]); ?>

    <?php echo $__env->make('includes.form-errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <input type="hidden" name="branch_pickup" value="<?php echo e($branch_pickup); ?>">
    <input type="hidden" name="branch_return" value="<?php echo e($branch_return); ?>">
    <input type="hidden" name="pickupDate" value="<?php echo e($pickupDate); ?>">
    <input type="hidden" name="returnDate" value="<?php echo e($returnDate); ?>">
    <input type="hidden" name="pickupTime" value="<?php echo e($pickupTime); ?>">
    <input type="hidden" name="returnTime" value="<?php echo e($returnTime); ?>">
    <input type="hidden" name="car_id" value="<?php echo e($car_id); ?>">
    <?php ($date1=date_create($pickupDate)); ?>
    <?php ($date2=date_create($returnDate)); ?>
    <?php ($diff=date_diff($date1,$date2)); ?>
    <?php ($days=$diff->format("%a")); ?>
    <?php if($days == 0): ?>
        <?php ( $days = 1 ); ?>
    <?php endif; ?>
    <div class="row car-details-row">
        <div class="col-md-6 car_details">
            <button href="#" onclick="return false;" class="btn btn-rent-title"><?php echo trans('home.FINISH'); ?></button>
            <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($car->id == $car_id): ?>
                    <?php ($total_price = $days * $car->price_per_day_car); ?>
                    <h1 class="car-name"><?php echo e($car->type->name); ?> <?php echo e($car->name); ?> Rental</h1>
                    <p class="days"> <?php echo trans('home.Rent_for'); ?> <strong><?php echo e($days); ?></strong> <?php echo trans('home.Day_s'); ?> <strong class="pull-right"><?php echo e($days * $car->price_per_day_car); ?> $</strong></p>
                    <?php if($garantie == 1): ?>
                        <p class="garantie-car">Warranty <span class="warranty-name">Limited</span> <span class="pull-right"> <b class="warranty-price"><?php echo e(18 * $days); ?></b> <b>$</b></span></p>
                    <?php elseif($garantie == 3): ?>
                        <p class="garantie-car">Warranty <span class="warranty-name">No Coverage</span> <span class="pull-right"> <b class="warranty-price">0</b> <b>$</b></span></p>
                    <?php elseif($garantie == 2): ?>
                        <p class="garantie-car">Warranty <span class="warranty-name">Relaxed</span> <span class="pull-right"> <b class="warranty-price"><?php echo e(30 * $days); ?></b> <b>$</b></span></p>
                    <?php endif; ?>
                    <p class="additional-car-services-title"><?php echo trans('home.ADDITIONAL_SERVICES'); ?></p>
                    <div id="fulloptions">
                        <?php if($car_gps): ?>
                            <?php ($total_price += $car_gps); ?>
                            <p><?php echo trans('home.GPS'); ?> x <?php echo e($days); ?> <?php echo trans('home.Day_s'); ?><strong class="pull-right"><?php echo e($car_gps); ?> $</strong></p>
                        <?php endif; ?>
                        <?php if($car_baby_chair): ?>
                            <?php ($total_price += $car_baby_chair); ?>
                            <p><?php echo trans('home.CHILD_SEAT'); ?> x <?php echo e($days); ?> <?php echo trans('home.Day_s'); ?><strong class="pull-right"><?php echo e($car_baby_chair); ?> $</strong></p>
                        <?php endif; ?>
                        <?php if($car_child_seat): ?>
                            <?php ($total_price += $car_child_seat); ?>
                            <p><?php echo trans('home.BABY_CHAIR'); ?> x <?php echo e($days); ?> <?php echo trans('home.Day_s'); ?><strong class="pull-right"><?php echo e($car_child_seat); ?> $</strong></p>
                        <?php endif; ?>
                        <?php if($car_wifi_price): ?>
                            <?php ($total_price += $car_wifi_price); ?>
                            <p><?php echo trans('home.WI_FI_ROUTER'); ?> x <?php echo e($days); ?> <?php echo trans('home.Day_s'); ?><strong class="pull-right"><?php echo e($car_wifi_price); ?> $</strong></p>
                        <?php endif; ?>
                        <?php if($car_snow_chains): ?>
                            <?php ($total_price += $car_snow_chains); ?>
                            <p><?php echo trans('home.SNOW_CHAIN'); ?> x <?php echo e($days); ?> <?php echo trans('home.Day_s'); ?><strong class="pull-right"><?php echo e($car_snow_chains); ?> $</strong></p>
                        <?php endif; ?>
                        <?php if($car_sky_support): ?>
                            <?php ($total_price += $car_sky_support); ?>
                            <p><?php echo trans('home.SKY_SUPPORT'); ?> x <?php echo e($days); ?> <?php echo trans('home.Day_s'); ?><strong class="pull-right"><?php echo e($car_sky_support); ?> $</strong></p>
                        <?php endif; ?>
                    <br>
                    <br>
                    </div>
                    <?php $dislocation = 0; ?>
                    <?php if($branch_return): ?>
                        <?php if($branch_pickup != $branch_return): ?>
                            <p>
                                Dislocation
                                <strong>
                                    <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($branch->id == $branch_pickup): ?>
                                            <?php echo e($branch->name); ?>

                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    -
                                    <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($branch->id == $branch_return): ?>
                                            <?php echo e($branch->name); ?>

                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </strong>
                                <strong class="pull-right">150 $</strong>
                            </p>
                            <?php  $dislocation = 150; ?>
                        <?php endif; ?>
                    <?php endif; ?>

                    <?php

                    $interval_start = strtotime('09:00');
                    $interval_end = strtotime('18:00');

                    $pickup_time = strtotime($pickupTime);
                    $return_time = strtotime($returnTime);

                    $over_time_pickup = 0;
                    $over_time_pickup_cond = 0;

                    $over_time_return = 0;
                    $over_time_return_cond = 0;

                    $over_time = 0;

                    if($interval_start <= $pickup_time && $pickup_time < $interval_end) {}
                    else { $over_time_pickup = 20; $over_time_pickup_cond = 1; }

                    if($interval_start <= $return_time && $return_time < $interval_end) {}
                    else { $over_time_return = 20; $over_time_return_cond = 1; }

                    $over_time = $over_time_pickup + $over_time_return;
                    ?>

                    <?php if($over_time_pickup_cond == 1 || $over_time_return_cond == 1): ?>
                        <p>Program additional charges
                            <strong class="pull-right"><?php echo e($over_time); ?> $</strong>
                        </p>
                    <?php endif; ?>

                    <?php $garantie_total = 0; ?>
                    <?php if($garantie == 1): ?>
                        <?php $garantie_total = 18 * $days ?>
                    <?php elseif($garantie == 3): ?>
                        <?php $garantie_total = 0 ?>
                    <?php elseif($garantie == 2): ?>
                        <?php $garantie_total = 30 * $days ?>
                    <?php endif; ?>


                    <br>
                    <br>

                    <h3 class="total"><?php echo trans('home.Total_price'); ?>: <span class="pull-right"><?php echo e($total_price + $dislocation+$over_time+$garantie_total); ?>   $</span></h3>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="col-md-6 user_details">
            <button href="#" onclick="return false;" class="btn btn-rent-title"><?php echo trans('home.Personal_Data'); ?></button>
            <?php if(Auth::user()): ?>
            <p><?php echo trans('home.Name_and_Surname'); ?>: <?php echo e(Auth::user()->name); ?></p>
            <?php if(Auth::user()->address): ?>
                <p><?php echo trans('home.Address'); ?>:  <?php echo e(Auth::user()->address); ?></p>
            <?php endif; ?>
            <?php if(Auth::user()->phone): ?>
                <p><?php echo trans('home.Phone'); ?>:  <?php echo e(Auth::user()->phone); ?></p>
            <?php endif; ?>
            <?php if(Auth::user()->email): ?>
                <p>Email:  <?php echo e(Auth::user()->email); ?></p>
            <?php endif; ?>
            <?php else: ?>
                <div class="row">
                    <div class="form-group col-md-6">
                        <?php echo Form::label('name', 'Name'); ?>

                        <?php echo Form::text('name', null, ['class' => 'form-control']); ?>

                    </div>
                    <div class="form-group col-md-6">
                        <?php echo Form::label('email', 'Email'); ?>

                        <?php echo Form::email('email', null, ['class' => 'form-control']); ?>

                    </div>
                </div>
                <div class="row">
                    <div class="form-group col-md-6">
                        <?php echo Form::label('city', Lang::get('home.City')); ?>

                        <?php echo Form::text('city', null, ['class' => 'form-control']); ?>

                    </div>
                    <div class="form-group col-md-6">
                        <?php echo Form::label('phone', Lang::get('home.Phone')); ?>

                        <?php echo Form::text('phone', null, ['class' => 'form-control']); ?>

                    </div>
                </div>
                <div class="row">
                    <div class="form-group col-md-12">
                        <?php echo Form::label('flight_number', Lang::get('home.Flight_number')); ?>

                        <?php echo Form::text('flight_number', null, ['class' => 'form-control']); ?>

                    </div>
                </div>
                <div class="row">
                    <div class="form-group col-md-12">
                        <?php echo Form::label('reservation_info', Lang::get('home.Reservation_info')); ?>

                        <?php echo Form::text('reservation_info', null, ['class' => 'form-control']); ?>

                    </div>
                </div>
                <div class="row">
                    <div class="form-group col-md-6">
                        <?php echo Form::label('password', Lang::get('home.Password')); ?>

                        <?php echo Form::password('password', ['class' => 'form-control']); ?>

                    </div>
                    <div class="form-group col-md-6">
                        <?php echo Form::label('password_confirmation', Lang::get('home.Password_Confirm')); ?>

                        <?php echo Form::password('password_confirmation', ['class' => 'form-control']); ?>

                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <?php echo Form::label('password', Lang::get('home.Read_Agreed')); ?>

                    </div>
                </div>
                <div class="row">
                    <label class="checkboxes-final-form">
                    <div class="form-group col-md-12 checkbox-inline">
                        <?php echo Form::checkbox('terms_condition', null, null, ['class' => 'checkboxe-final-form']); ?><span class="checkmark"></span>
                        <?php echo e(Lang::get('home.Terms_Conditions')); ?>

                    </div>
                    </label>
                </div>
                <div class="row">
                    <label class="checkboxes-final-form">
                        <div class="form-group col-md-12 checkbox-inline">
                            <?php echo Form::checkbox('personal_data', null, null, ['class' => 'checkboxe-final-form']); ?><span class="checkmark"></span>
                            <?php echo e(Lang::get('home.Personal_Data_Policy')); ?>

                        </div>
                    </label>
                </div>
            <?php endif; ?>
                <div class="form-group text-left">
                    <?php echo Form::submit(Lang::get('home.Payment_on_pickup'), ['class' => 'btn btn-primary']); ?>

                </div>
        </div>
    </div>
    <div class="row car-details-row">
        <input type="hidden" name="price" value="<?php echo e($total_price + $dislocation + $over_time +$garantie_total); ?>">
    </div>
    <?php echo Form::close(); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>