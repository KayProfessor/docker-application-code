<?php $__env->startSection('content'); ?>

    <h1>Update Bike</h1>

    <div class="text-left">
        <img style="margin-bottom: 50px;max-width:400px" src="<?php echo e($bike->photo ? $bike->photo['file'] : 'http://via.placeholder.com/400x400'); ?>" alt="">
    </div>
    <div style="margin-bottom: 50px;" class="row">
        <div class="col-md-6">

            <?php echo Form::model($bike, ['method' => 'PATCH', 'action' => ['BikeController@update', $bike->id], 'files'=>true]); ?>


            <div class="form-group">
                <?php echo Form::label('name', 'Bike Name :'); ?>

                <?php echo Form::text('name', null, ['class' => 'form-control']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('branch_id', 'Select Location:'); ?>

                <?php echo Form::select('branch_id', [''=> 'Choose Location'] + $branches, null, ['class' => 'form-control']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('price_per_day', 'Price Car/Day ($) :'); ?>

                <?php echo Form::text('price_per_day', null, ['class' => 'form-control']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('type', 'Type:'); ?>

                <?php echo Form::text('type', null, ['class' => 'form-control']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('bike_for', 'Bike For :'); ?>

                <?php echo Form::text('bike_for', null, ['class' => 'form-control']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('max_weight', 'Maximum weight supported :'); ?>

                <?php echo Form::text('max_weight', null, ['class' => 'form-control']); ?>

            </div>

        </div>

        <div class="col-md-6">


            <div class="form-group">
                <?php echo Form::label('handlebar_width', 'Handlebar width :'); ?>

                <?php echo Form::text('handlebar_width', null, ['class' => 'form-control']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('wheel_size', 'Wheel size :'); ?>

                <?php echo Form::text('wheel_size', null, ['class' => 'form-control']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('frame_size', 'Frame size :'); ?>

                <?php echo Form::text('frame_size', null, ['class' => 'form-control']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('chain', 'Chain :'); ?>

                <?php echo Form::text('chain', null, ['class' => 'form-control']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('photo_id', 'Featured Image:'); ?>

                <?php echo Form::file('photo_id', null, ['class' => 'form-control']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::submit('Update Bike', ['class' => 'btn btn-primary']); ?>

            </div>

            <?php echo $__env->make('includes.form-errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <?php echo Form::close(); ?>


            <?php echo Form::open(['method' => 'DELETE', 'action' => ['BikeController@destroy', $bike->id]]); ?>


            <div class="form-group">
                <?php echo Form::submit('Delete Bike', ['class' => 'btn btn-danger']); ?>

            </div>

            <?php echo Form::close(); ?>


        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>