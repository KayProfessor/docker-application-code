

<?php $__env->startSection('content'); ?>

        <div class="col-md-6">

            <h1>Create Gearbox</h1>

            <?php echo Form::open(['method' => 'POST', 'action' => 'CarGearboxController@index']); ?>


            <div class="form-group">
                <?php echo Form::label('name', 'Name:'); ?>

                <?php echo Form::text('name', null, ['class' => 'form-control']); ?>

            </div>


            <div class="form-group">
                <?php echo Form::submit('Submit', ['class' => 'btn btn-primary']); ?>

            </div>

            <?php echo $__env->make('includes.form-errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <?php echo Form::close(); ?>


        </div>

        <?php if(count($gearboxes) > 0): ?>

        <div class="col-md-6">

            <h1>All Gearboxes</h1>

            <table class="table-responsive-design">
                <thead>
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Name</th>
                    <th scope="col">Created</th>
                    <th scope="col">Updated</th>
                </tr>
                </thead>
                <tbody>

                <?php if($gearboxes): ?>
                    <?php $__currentLoopData = $gearboxes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gearbox): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td data-label="ID"><?php echo e($gearbox->id); ?></td>
                            <td data-label="Name"><a href="<?php echo e(route('cars.gearboxes.edit', $gearbox->id)); ?>"><?php echo e($gearbox->name); ?></a></td>
                            <td data-label="Created"><?php echo e($gearbox->created_at ? $gearbox->created_at->diffForHumans() : 'no date'); ?></td>
                            <td data-label="Updated"><?php echo e($gearbox->updated_at ? $gearbox->updated_at->diffForHumans() : 'no date'); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

                </tbody>
            </table>

        </div>

    <?php else: ?>
        <h1>No Gearboxes</h1>

    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>