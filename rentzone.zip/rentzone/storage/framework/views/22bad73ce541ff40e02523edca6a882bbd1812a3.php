<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="outer-welcome-vehicle outer-welcome-bike">
    <div class="container rent-zone-search">
        <div class="row">
            <div class="col-md-6">
            <?php echo Form::open(['method'=>'GET', 'action' => 'RentalBikesController@choose_bike' ,'class'=>'rent-zone-search']); ?>

                <div class="col-md-12">
                    <h1 class="homepagetitle"><?php echo trans('home.Fast_and_easy_to_rent_a_bike'); ?></h1>
                    <?php echo $__env->make('includes.form-errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <?php echo Form::label('branch_pickup', Lang::get('home.Pickup_Location')); ?>

                        <?php echo Form::select('branch_pickup', [''=> Lang::get('home.Choose_Pickup_Location')] + $branches, null, ['class' => 'form-control required']); ?>

                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group" id="another-location">
                        <div class="checkbox form-control"></div>
                        <?php echo Form::label('another-location', Lang::get('home.Return_to_another_place'), ['id' => 'another-location']); ?>

                    </div>
                    <div class="form-group hidden branch_return">
                        <?php echo Form::label('branch_return', Lang::get('home.Return_Location')); ?>

                        <?php echo Form::select('branch_return', [''=> Lang::get('home.Choose_Return_Location')] + $branches, null, ['class' => 'form-control']); ?>

                    </div>
                </div>
                <div class="clearfix"></div>
                <div class="col-md-6">
                    <div class="form-group">
                        <?php echo Form::label('pickupDate', Lang::get('home.Pickup_Date')); ?>

                            <?php echo Form::date('pickupDate', null, ['class' => 'form-control rent-date pickupDate required', 'id'=> 'pickupDate']); ?>

                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <?php echo Form::label('returnDate', Lang::get('home.Return_Date')); ?>

                        <?php echo Form::date('returnDate', null, ['class' => 'form-control rent-date returnDate required', 'id'=> 'returnDate']); ?>

                    </div>
                </div>
                <div class="clearfix"></div>
                <div class="col-md-6">
                    <div class="form-group">
                        <?php echo Form::label('pickupTime', Lang::get('home.Pickup_Time')); ?>

                        <?php echo Form::time('pickupTime', null, ['class' => 'form-control required']); ?>

                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <?php echo Form::label('returnTime', Lang::get('home.Return_Time')); ?>

                        <?php echo Form::time('returnTime', null, ['class' => 'form-control required', 'id'=> 'returnTime']); ?>

                    </div>
                </div>
                <div class="clearfix"></div>
                <div class="col-md-12">
                    <div class="form-group">
                        <?php echo Form::submit(Lang::get('home.rent_a_bike'), ['class' => 'btn btn-primary']); ?>

                    </div>
                </div>
                <div class="clearfix"></div>
        <?php echo Form::close(); ?>

        </div> 
    </div> 
</div> 
</div> 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
<script>
    $("#pickupDate, #returnDate").flatpickr({
        dateFormat: "Y-m-d",
        minDate: "today",
        defaultDate: "today"
    });
    $("#pickupTime, #returnTime").flatpickr({
        enableTime: true,
        noCalendar: true,
        dateFormat: "H:i",
        defaultDate: "13:45"
    });
</script>
<script>
    $(function(){
        $( "#another-location" ).on("click", function() {
            $( '.branch_return' ).removeClass( "hidden" );
            $(this).addClass( "hidden" );
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>