<?php $__env->startSection('content'); ?>
    <div class="col-md-6">
        <h1>Add <?php echo trans('home.Category'); ?></h1>
        <?php echo Form::open(['method' => 'POST', 'action' => 'AdminCategoriesController@store']); ?>

        <div class="form-group">
            <?php echo Form::label('name', 'Name:'); ?>

            <?php echo Form::text('name', null, ['class' => 'form-control']); ?>

        </div>
        <?php ($create_category = Lang::get('home.Create') . ' ' . Lang::get('home.Category') ); ?>
        <div class="form-group">
            <?php echo Form::submit($create_category, ['class' => 'btn btn-primary']); ?>

        </div>
        <?php echo $__env->make('includes.form-errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo Form::close(); ?>

    </div>
    <?php if(count($categories) > 0): ?>
        <div class="col-md-6">
            <h1><?php echo trans('home.Categories'); ?></h1>
            <table class="table-responsive-design">
                <thead>
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col"><?php echo trans('home.Name'); ?></th>
                    <th scope="col"><?php echo trans('home.CREATED'); ?></th>
                    <th scope="col"><?php echo trans('home.UPDATED'); ?></th>
                </tr>
                </thead>
                <tbody>
                <?php if($categories): ?>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td data-label="ID"><?php echo e($category->id); ?></td>
                            <td data-label="<?php echo trans('home.Name_and_Surname'); ?>"><a href="<?php echo e(route('admin.categories.edit', $category->id)); ?>"><?php echo e($category->name); ?></a></td>
                            <td data-label="<?php echo trans('home.CREATED'); ?>"><?php echo e($category->created_at ? $category->created_at->diffForHumans() : 'no date'); ?></td>
                            <td data-label="<?php echo trans('home.UPDATED'); ?>"><?php echo e($category->updated_at ? $category->updated_at->diffForHumans() : 'no date'); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <div class="col-md-12">
            <h1><?php echo trans('home.No_categories'); ?></h1>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>