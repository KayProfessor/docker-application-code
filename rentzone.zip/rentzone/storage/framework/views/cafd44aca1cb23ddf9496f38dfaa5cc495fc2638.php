

<?php $__env->startSection('content'); ?>

    <div class="container user-information-section">
        <div class="row">

            <div class="col-md-3">
                <ul id="nav-tabs-wrapper" class="nav nav-pills nav-stacked well menu-my-account">
                    <li class="active"><a href="<?php echo e(route('user.user-profile')); ?>" title="">Overview</a></li>
                    <li><a href="<?php echo e(route('user.user-edit')); ?>" title="">Profile</a></li>
                    <li><a href="<?php echo e(route('user.user-reservations')); ?>" title="">Reservations</a></li>
                </ul>
                <br>
                <ul id="nav-tabs-wrapper" class="nav nav-pills nav-stacked well menu-my-account">
                    <li class="rent-now-btn"><a href="<?php echo e(route('rent-a-car.search-car')); ?>">Rent a car</a></li>
                    <li class="rent-now-btn"><a href="<?php echo e(route('rent-a-bike.search-bike')); ?>">Rent a bike</a></li>
                    <li class="rent-now-btn"><a href="<?php echo e(route('rent-a-moto.search-moto')); ?>">Rent a moto</a></li>
                </ul>
            </div>

            <div class="col-md-9">

                <div class="col-md-4">
                    <img class="img-responsive img-rounded" src="<?php echo e(Auth::user()->photo ? Auth::user()->photo['file'] : 'http://via.placeholder.com/200x200'); ?>" alt="">
                </div>

                <div class="col-md-8">
                    <h1 class="name"><?php echo e(Auth::user()->name); ?></h1>
                    <?php if(Auth::user()->email): ?>
                        <p><i class="fa fa-envelope-o" aria-hidden="true"></i> <?php echo e(Auth::user()->email); ?></p>
                    <?php endif; ?>
                    <?php if(Auth::user()->phone): ?>
                        <p><i class="fa fa-phone" aria-hidden="true"></i> <?php echo e(Auth::user()->phone); ?></p>
                    <?php endif; ?>
                    <?php if(Auth::user()->city || Auth::user()->address): ?>
                        <p><i class="fa fa-map-marker" aria-hidden="true"></i><?php echo e(Auth::user()->city); ?>, <?php echo e(Auth::user()->address); ?></p>
                    <?php endif; ?>
                </div>

            </div> 

        </div> 
    </div> 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>