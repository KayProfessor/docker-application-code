

<?php $__env->startSection('content'); ?>


    <!-- Blog Post -->

    <!-- Title -->
    <h1><?php echo e($post->title); ?></h1>

    <!-- Author -->
    <p class="lead">
        by <a href="#"><?php echo e($post->user->name); ?></a>
    </p>

    <hr>

    <!-- Date/Time -->
    <p><i class="fa fa-clock-o" aria-hidden="true"></i> Posted on <?php echo e($post->created_at->diffForHumans()); ?></p>

    <hr>

    <!-- Preview Image -->

    <img class="img-responsive" src="<?php echo e($post->photo ? $post->photo->file : 'http://via.placeholder.com/200x200'); ?>" alt="">

    <hr>

    <!-- Post Content -->
    <p><?php echo e($post->body); ?></p>

    <hr>

    <!-- Blog Comments -->

    <?php if(Session::has('comment_message')): ?>
        <div class="alert alert-success" role="alert">
            <p><?php echo e(session('comment_message')); ?></p>
        </div>
    <?php endif; ?>

    <?php if(Auth::check()): ?>

    <!-- Comments Form -->
    <div class="well">
        <h4>Leave a Comment:</h4>

        <?php echo Form::open(['method' => 'POST', 'action' => 'PostsCommentsController@store']); ?>


        <input type="hidden" name="post_id" value="<?php echo e($post->id); ?>">

        <div class="form-group">
            <?php echo Form::textarea('body', null, ['class' => 'form-control', 'rows'=>'3']); ?>

        </div>

        <div class="form-group">
            <?php echo Form::submit('Submit', ['class' => 'btn btn-primary']); ?>

        </div>

        <?php echo Form::close(); ?>


    </div>

    <?php endif; ?>

    <hr>

    <!-- Posted Comments -->

    

    <?php if(count($comments) > 0): ?>

        <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <!-- Comment -->
            <div class="media">
                <a class="pull-left" href="#">

                    <img height="65" class="media-object" src="<?php echo e($comment->photo); ?>" alt="">
                </a>
                <div class="media-body">
                    <h4 class="media-heading"><?php echo e($comment->author); ?>

                        <small><?php echo e($comment->created_at->diffForHumans()); ?></small>
                    </h4>
                    <p><?php echo e($comment->body); ?></p>

                    <?php if(count($comment->replies) > 0): ?>
                        <?php $__currentLoopData = $comment->replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($reply->is_active == 1): ?>
                            <!-- Nested Comment -->
                            <div class="media">
                                <a class="pull-left" href="#">
                                    <img height="65" class="media-object" src="<?php echo e($reply->photo); ?>" alt="">
                                </a>
                                <div class="media-body">
                                    <h4 class="media-heading"><?php echo e($reply->author); ?>

                                        <small><?php echo e($reply->created_at->diffForHumans()); ?></small>
                                    </h4>
                                    <p><?php echo e($reply->body); ?></p>
                                </div>
                            </div>
                             <br>
                            <!-- End Nested Comment -->
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                    <?php echo Form::open(['method' => 'POST', 'action' => 'CommentsRepliesController@createReply']); ?>


                    <input type="hidden" name="comment_id" value="<?php echo e($comment->id); ?>">

                    <div class="form-group">
                        <?php echo Form::label('body', 'Body:'); ?>

                        <?php echo Form::textarea('body', null, ['class' => 'form-control','rows'=>'2']); ?>

                    </div>

                    <div class="form-group">
                        <?php echo Form::submit('Submit', ['class' => 'btn btn-primary']); ?>

                    </div>

                    <?php echo Form::close(); ?>



                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.blog-post', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>