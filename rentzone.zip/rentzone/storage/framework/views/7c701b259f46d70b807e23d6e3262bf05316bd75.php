<!doctype html>
<html lang="en" class="no-js">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:300,400,700' rel='stylesheet' type='text/css'>

    <link href="<?php echo e(asset('css/libs/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/libs/font-awesome.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/libs/style.css')); ?>" rel="stylesheet">

    <title>RentZone</title>
    <link rel="icon" href="<?php echo e(asset('public/img/favicon.ico')); ?>" type="image/ico" sizes="16x16">

    <?php echo $__env->yieldContent('styles'); ?>
</head>
<body>
    <header class="cd-main-header">
        <a href="<?php echo e(url('/')); ?>" class="cd-logo"><img src="<?php echo e(asset('public/img/logo.png')); ?>" alt="Logo"></a>

        <a href="#0" class="cd-nav-trigger">Menu<span></span></a>

        <nav class="cd-nav">
            <ul class="cd-top-nav">

                <?php if(auth()->guest()): ?>
                    <?php if(!Request::is('auth/login')): ?>
                        <li><a href="<?php echo e(url('/auth/login')); ?>"><?php echo trans('home.login'); ?></a></li>
                    <?php endif; ?>
                    <?php if(!Request::is('auth/register')): ?>
                        <li><a href="<?php echo e(url('/auth/register')); ?>"><?php echo trans('home.register'); ?></a></li>
                    <?php endif; ?>
                <?php else: ?>

                    <li><a href="/settings/lang/en"><?php echo trans('home.english'); ?></a></li>
                    <li><a href="/settings/lang/de"><?php echo trans('home.german'); ?></a></li>

                    <li class="has-children account">
                        <a href="#0">
                            <img src="<?php echo e(Auth::user()->photo ? Auth::user()->photo->file : 'public/img/cd-avatar.png'); ?>" alt="avatar">
                            <?php echo e(auth()->user()->name); ?>

                        </a>
                        <ul>                     
                            <?php if(Auth::user()->role->name == 'administrator'): ?>
                                <li><a href="<?php echo e(url('/admin/users')); ?>/<?php echo e(auth()->user()->id); ?>/edit"><?php echo trans('home.Profile'); ?></a></li>
                            <?php endif; ?>
                            <?php if(Auth::user()->role->name == 'author'): ?>
                                <a href="<?php echo e(url('/admin/authors')); ?>/<?php echo e(auth()->user()->id); ?>"><?php echo trans('home.Profile'); ?></a>
                            <?php endif; ?>
                            <li>
                                <a href="<?php echo e(route('logout')); ?>"
                                   onclick="event.preventDefault();
                                             document.getElementById('logout-form').submit();">
                                    <?php echo trans('home.logout'); ?>

                                </a>

                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                    <?php echo e(csrf_field()); ?>

                                </form>
                            </li>
                        </ul>
                    </li>                  
                    
                <?php endif; ?>
            </ul>
        </nav>
    </header> <!-- .cd-main-header -->

    <main class="cd-main-content">
        <nav class="cd-side-nav">
            <ul>

                <?php if(Auth::user()->role->name == 'administrator'): ?>

                <li class="has-children users">
                    <a href="#0"><?php echo trans('home.Users'); ?></a>
                    <ul>
                        <li><a href="<?php echo e(route('admin.users.index')); ?>"><?php echo trans('home.All'); ?> <?php echo trans('home.Users'); ?></a></li>
                        <li><a href="<?php echo e(route('admin.users.create')); ?>"><?php echo trans('home.Create'); ?> <?php echo trans('home.Users'); ?></a> </li>
                    </ul>
                </li>
                <?php endif; ?>

                <li class="has-children bookmarks">
                    <a href="#0"><?php echo trans('home.Posts'); ?></a>
                    <ul>
                        <li><a href="<?php echo e(route('admin.posts.index')); ?>"><?php echo trans('home.All'); ?> <?php echo trans('home.Posts'); ?></a></li>
                        <li><a href="<?php echo e(route('admin.posts.create')); ?>"><?php echo trans('home.Create'); ?> <?php echo trans('home.Posts'); ?></a></li>
                        <li><a href="<?php echo e(route('admin.comments.index')); ?>"><?php echo trans('home.All'); ?> <?php echo trans('home.Comments'); ?></a></li>
                        <li><a href="<?php echo e(route('admin.categories.index')); ?>"><?php echo trans('home.All'); ?> <?php echo trans('home.Categories'); ?></a></li>
                    </ul>
                </li>

                <li class="has-children images">
                    <a href="#0"><?php echo trans('home.Media'); ?></a>
                    <ul>
                        <li><a href="<?php echo e(route('admin.media.index')); ?>"><?php echo trans('home.All'); ?> <?php echo trans('home.Media'); ?></a> </li>
                        <li><a href="<?php echo e(route('admin.media.create')); ?>"><?php echo trans('home.Upload'); ?> <?php echo trans('home.Media'); ?></a></li>
                    </ul>
                </li>

                <?php if(Auth::user()->role->name == 'administrator'): ?>

                <li class="overview"><a href="<?php echo e(route('cars.branches.index')); ?>"><?php echo trans('home.All'); ?> <?php echo trans('home.Branches'); ?></a></li>

                <li class="has-children images">
                    <a href="#0"><?php echo trans('home.Cars'); ?></a>
                    <ul>
                        <li><a href="<?php echo e(route('cars.index')); ?>"><?php echo trans('home.All'); ?> <?php echo trans('home.Cars'); ?></a></li>
                        <li><a href="<?php echo e(route('cars.create')); ?>"><?php echo trans('home.Create'); ?> <?php echo trans('home.Car'); ?></a></li>
                    </ul>
                </li>

                <li class="has-children images">
                    <a href="#0"><?php echo trans('home.Car'); ?> <?php echo trans('home.Characteristics'); ?></a>
                    <ul>
                        <li><a href="<?php echo e(route('cars.types.index')); ?>"><?php echo trans('home.All'); ?> <?php echo trans('home.Types'); ?></a></li>
                        <li><a href="<?php echo e(route('cars.fuels.index')); ?>"><?php echo trans('home.All'); ?> <?php echo trans('home.Types_of_fuel'); ?></a></li>
                        <li><a href="<?php echo e(route('cars.gearboxes.index')); ?>"><?php echo trans('home.All'); ?> <?php echo trans('home.Gearboxes'); ?></a></li>
                    </ul>
                </li>

                <li class="has-children bookmarks">
                    <a href="#0"><?php echo trans('home.Car'); ?> <?php echo trans('home.Reservations'); ?></a>
                    <ul>
                        <li><a href="<?php echo e(route('rent-a-car.show')); ?>"><?php echo trans('home.All'); ?> <?php echo trans('home.Reservations'); ?></a></li>
                        <li><a href="<?php echo e(route('rent-a-car.search-car')); ?>"><?php echo trans('home.Create'); ?> <?php echo trans('home.Reservations'); ?></a></li>
                    </ul>
                </li>

                <li class="has-children images">
                    <a href="#0"><?php echo trans('home.Bikes'); ?></a>
                    <ul>
                        <li><a href="<?php echo e(route('bikes.index')); ?>"><?php echo trans('home.All'); ?> <?php echo trans('home.Bikes'); ?></a></li>
                        <li><a href="<?php echo e(route('bikes.create')); ?>"><?php echo trans('home.Create'); ?> <?php echo trans('home.Bikes'); ?></a></li>
                    </ul>
                </li>

                <li class="has-children bookmarks">
                    <a href="#0"><?php echo trans('home.Bike'); ?> <?php echo trans('home.Reservations'); ?></a>
                    <ul>
                        <li><a href="<?php echo e(route('rent-a-bike.show')); ?>"><?php echo trans('home.All'); ?> <?php echo trans('home.Reservations'); ?></a></li>
                        <li><a href="<?php echo e(route('rent-a-bike.search-bike')); ?>"><?php echo trans('home.Create'); ?> <?php echo trans('home.Reservations'); ?></a></li>
                    </ul>
                </li>

                <li class="has-children images">
                    <a href="#0"><?php echo trans('home.Moto'); ?></a>
                    <ul>
                        <li><a href="<?php echo e(route('motos.index')); ?>"><?php echo trans('home.All'); ?> <?php echo trans('home.Motos'); ?></a></li>
                        <li><a href="<?php echo e(route('motos.create')); ?>"><?php echo trans('home.Create'); ?> <?php echo trans('home.Moto'); ?></a></li>
                    </ul>
                </li>

                <li class="has-children bookmarks">
                    <a href="#0"><?php echo trans('home.Moto'); ?> <?php echo trans('home.Reservations'); ?></a>
                    <ul>
                        <li><a href="<?php echo e(route('rent-a-moto.show')); ?>"><?php echo trans('home.All'); ?> <?php echo trans('home.Reservations'); ?></a></li>
                        <li><a href="<?php echo e(route('rent-a-moto.search-moto')); ?>"><?php echo trans('home.Create'); ?> <?php echo trans('home.Reservations'); ?></a></li>
                    </ul>
                </li>

                 <?php endif; ?>

                <?php if(Auth::user()->role->name == 'author'): ?>
                        <li class="has-children bookmarks">
                            <a href="<?php echo e(route('rent-a-car.search-car')); ?>"><?php echo trans('home.Create'); ?> <?php echo trans('home.Car'); ?> <?php echo trans('home.Reservations'); ?></a>
                        </li>
                        <li class="has-children bookmarks">
                            <a href="<?php echo e(route('rent-a-bike.search-bike')); ?>"><?php echo trans('home.Create'); ?> <?php echo trans('home.Bike'); ?> <?php echo trans('home.Reservations'); ?></a>
                        </li>
                        <li class="has-children bookmarks">
                            <a href="<?php echo e(route('rent-a-moto.search-moto')); ?>"><?php echo trans('home.Create'); ?> <?php echo trans('home.Moto'); ?> <?php echo trans('home.Reservations'); ?></a>
                        </li>
                <?php endif; ?>

            </ul>
        </nav>

        <div class="content-wrapper">
            <div class="alert alert-success fade in alert-dismissible" style="margin-top:50px;">
                <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
                 <?php echo trans('home.disabled'); ?>

            </div>
            <?php echo $__env->yieldContent('content'); ?>
        </div> <!-- .content-wrapper -->
    </main> <!-- .cd-main-content -->

    <script src="<?php echo e(asset('js/libs.js')); ?>"></script>

    <?php echo $__env->yieldContent('footer'); ?>

</body>
</html>