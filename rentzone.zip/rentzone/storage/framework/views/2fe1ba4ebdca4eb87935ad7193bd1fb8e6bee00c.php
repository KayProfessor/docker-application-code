<?php $__env->startSection('content'); ?>



    <?php if(count($motos) > 0): ?>



        <h1>Motos</h1>



        <table class="table-responsive-design">

            <thead>

            <tr>

                <th scope="col">ID</th>

                <th scope="col">Name</th>

                <th scope="col">Image</th>

                <th scope="col">Price</th>

                <th scope="col">Characteristics</th>

                <th scope="col">Available</th>

            </tr>

            </thead>

            <tbody>



            <?php if($motos): ?>

                <?php $__currentLoopData = $motos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $moto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr>

                        <td data-label="ID"><?php echo e($moto->id); ?></td>

                        <td valign="center" data-label="Name"><a href="<?php echo e(route('motos.edit', $moto->id)); ?>"><?php echo e($moto->name); ?></a></td>

                        <td data-label="Image"><img height="50" src="<?php echo e($moto->photo ? $moto->photo->file : 'http://via.placeholder.com/200x200'); ?>" alt=""></td>

                        <td data-label="Price"><?php echo e($moto->price_per_day); ?>$</td>

                        <td data-label="Moto Characteristics" align="left" width="90%"><a data-toggle="popover" data-trigger="click" data-content="<table class='table table-bordered'>

                                       <tr>

                                        <td>Moto Type:</td><td><?php echo e($moto->type); ?></td>

                                       </tr>

                                       <tr>

                                        <td>Max weight:</td><td><?php echo e($moto->max_weight); ?></td>

                                       </tr>

                                       <tr>

                                        <td>Max speed:</td><td><?php echo e($moto->max_speed); ?></td>

                                       </tr>

                                       <tr>

                                        <td>Fuel Economy:</td><td><?php echo e($moto->fuel_economy); ?></td>

                                       </tr>

                                       <tr>

                                        <td>Engine:</td><td><?php echo e($moto->engine); ?></td>

                                       </tr>

                                       </table>" title="Characteristics" data-html="true" class="btn btn-info">Characteristics</a>

                        </td>

                        <td data-label="Available">



                            <?php if($moto->is_available == 0): ?>



                                <?php echo Form::model($moto, ['method' => 'PATCH', 'action' => ['MotoController@update', $moto->id] ]); ?>


                                <input type="hidden" name="is_available" value="1">

                                <?php echo Form::submit('Yes', ['class' => 'btn btn-success']); ?>


                                <?php echo Form::close(); ?>




                            <?php elseif($moto->is_available == 1): ?>



                                <?php echo Form::model($moto, ['method' => 'PATCH', 'action' => ['MotoController@update', $moto->id] ]); ?>


                                <input type="hidden" name="is_available" value="0">

                                <?php echo Form::submit('No', ['class' => 'btn btn-danger']); ?>


                                <?php echo Form::close(); ?>




                            <?php endif; ?>



                        </td>

                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php endif; ?>



            </tbody>

        </table>





    <?php else: ?>

        <h1>No Motos</h1>



    <?php endif; ?>



<?php $__env->stopSection(); ?>



<?php $__env->startSection('footer'); ?>

    <script>

        $(function () {

            $('[data-toggle="popover"]').popover();

        });

    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>