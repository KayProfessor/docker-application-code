<?php $__env->startSection('content'); ?>
    <?php if(count($bikes) > 0): ?>
        <h1><?php echo trans('home.Bikes'); ?></h1>
        <table class="table-responsive-design">
            <thead>
            <tr>
                <th scope="col">ID</th>
                <th scope="col">Name</th>
                <th scope="col"><?php echo trans('home.Image'); ?></th>
                <th scope="col"><?php echo trans('home.PRICE'); ?></th>
                <th scope="col"><?php echo trans('home.Characteristics'); ?> </th>
                <th scope="col"><?php echo trans('home.AVAILABLE'); ?></th>
            </tr>
            </thead>
            <tbody>
            <?php if($bikes): ?>
                <?php $__currentLoopData = $bikes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bike): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td data-label="ID"><?php echo e($bike->id); ?></td>
                        <td valign="center" data-label="Name"><a href="<?php echo e(route('bikes.edit', $bike->id)); ?>"><?php echo e($bike->name); ?></a></td>
                        <td data-label="<?php echo trans('home.Image'); ?>"><img height="50" src="<?php echo e($bike->photo ? $bike->photo->file : 'http://via.placeholder.com/200x200'); ?>" alt=""></td>
                        <td data-label="<?php echo trans('home.PRICE'); ?>"><?php echo e($bike->price_per_day); ?>$</td>
                        <td data-label="<?php echo trans('home.Characteristics'); ?>" align="left" width="90%"><a data-toggle="popover" data-trigger="click" data-content="<table class='table table-bordered'>
                                       <tr>
                                        <td><?php echo trans('home.Bike_Type'); ?>:</td><td><?php echo e($bike->type); ?></td>
                                       </tr>
                                        <tr>
                                        <td><?php echo trans('home.Bike_For'); ?> :</td><td><?php echo e($bike->bike_for); ?></td>
                                       </tr>
                                       <tr>
                                        <td><?php echo trans('home.Maximum_weight_supported'); ?> :</td><td><?php echo e($bike->max_weight); ?></td>
                                       </tr>
                                       <tr>
                                        <td><?php echo trans('home.Handlebar_width'); ?> :</td><td><?php echo e($bike->handlebar_width); ?></td>
                                       </tr>
                                       <tr>
                                        <td><?php echo trans('home.Wheel_size'); ?> :</td><td><?php echo e($bike->wheel_size); ?></td>
                                       </tr>
                                       <tr>
                                        <td><?php echo trans('home.Frame_size'); ?> :</td><td><?php echo e($bike->frame_size); ?></td>
                                       </tr>
                                       <tr>
                                        <td><?php echo trans('home.Chain'); ?> :</td><td><?php echo e($bike->chain); ?></td>
                                       </tr>
                                       <tr>
                                        <td><?php echo trans('home.Location'); ?> :</td><td><?php echo e($bike->branch->location); ?></td>
                                       </tr>
                                       </table>" title="<?php echo trans('home.Characteristics'); ?>" data-html="true" class="btn btn-info"><?php echo trans('home.Characteristics'); ?></a>
                        </td>
                        <td data-label="<?php echo trans('home.AVAILABLE'); ?>">
                            <?php if($bike->is_available == 0): ?>
                                <?php echo Form::model($bike, ['method' => 'PATCH', 'action' => ['BikeController@update', $bike->id] ]); ?>

                                <input type="hidden" name="is_available" value="1">
                                <?php echo Form::submit(Lang::get('home.Yes'), ['class' => 'btn btn-success']); ?>

                                <?php echo Form::close(); ?>

                            <?php elseif($bike->is_available == 1): ?>
                                <?php echo Form::model($bike, ['method' => 'PATCH', 'action' => ['BikeController@update', $bike->id] ]); ?>

                                <input type="hidden" name="is_available" value="0">
                                <?php echo Form::submit(Lang::get('home.Not'), ['class' => 'btn btn-danger']); ?>

                                <?php echo Form::close(); ?>

                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            </tbody>
        </table>
    <?php else: ?>
        <h1><?php echo trans('home.Not'); ?> <?php echo trans('home.Bikes'); ?></h1>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <script>
        $(function () {
            $('[data-toggle="popover"]').popover();
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>