<!doctype html>
<html lang="en" class="no-js">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:300,400,700' rel='stylesheet' type='text/css'>

    <link href="<?php echo e(asset('css/libs/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/libs/font-awesome.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/libs/style.css')); ?>" rel="stylesheet">

    <title>RentZone</title>
    <link rel="icon" href="<?php echo e(asset('public/img/favicon.ico')); ?>" type="image/ico" sizes="16x16">

    <?php echo $__env->yieldContent('styles'); ?>
</head>
<body>
    <header class="cd-main-header">
        <a href="<?php echo e(url('/')); ?>" class="cd-logo"><img src="<?php echo e(asset('public/img/logo.png')); ?>" alt="Logo"></a>

        <a href="#0" class="cd-nav-trigger">Menu<span></span></a>

        <nav class="cd-nav">
            <ul class="cd-top-nav">
                <?php if(auth()->guest()): ?>
                    <?php if(!Request::is('auth/login')): ?>
                        <li><a href="<?php echo e(url('/auth/login')); ?>">Login</a></li>
                    <?php endif; ?>
                    <?php if(!Request::is('auth/register')): ?>
                        <li><a href="<?php echo e(url('/auth/register')); ?>">Register</a></li>
                    <?php endif; ?>
                <?php else: ?>
                    <li class="has-children account">
                        <a href="#0">
                            <img src="<?php echo e(Auth::user()->photo ? Auth::user()->photo->file : 'public/img/cd-avatar.png'); ?>" alt="avatar">
                            <?php echo e(auth()->user()->name); ?>

                        </a>
                        <ul>
                            <li>
                                <a href="<?php echo e(route('logout')); ?>"
                                   onclick="event.preventDefault();
                                             document.getElementById('logout-form').submit();">
                                    Logout
                                </a>

                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                    <?php echo e(csrf_field()); ?>

                                </form>
                            </li>
                            <?php if(Auth::user()->role->name == 'administrator'): ?>
                                <li><a href="<?php echo e(url('/admin/users')); ?>/<?php echo e(auth()->user()->id); ?>/edit">Profile</a></li>
                            <?php endif; ?>
                            <?php if(Auth::user()->role->name == 'author'): ?>
                                <a href="<?php echo e(url('/admin/authors')); ?>/<?php echo e(auth()->user()->id); ?>">Profile</a>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>
            </ul>
        </nav>
    </header> <!-- .cd-main-header -->

    <main class="cd-main-content">
        <nav class="cd-side-nav">
            <ul>

                <?php if(Auth::user()->role->name == 'administrator'): ?>

                <li class="has-children users">
                    <a href="#0">Users</a>
                    <ul>
                        <li><a href="<?php echo e(route('admin.users.index')); ?>">All Users</a></li>
                        <li><a href="<?php echo e(route('admin.users.create')); ?>">Create User</a> </li>
                    </ul>
                </li>
                <?php endif; ?>

                <li class="has-children bookmarks">
                    <a href="#0">Posts</a>
                    <ul>
                        <li><a href="<?php echo e(route('admin.posts.index')); ?>">All Posts</a></li>
                        <li><a href="<?php echo e(route('admin.posts.create')); ?>">Create Post</a></li>
                        <li><a href="<?php echo e(route('admin.comments.index')); ?>">All Comments</a></li>
                        <li><a href="<?php echo e(route('admin.categories.index')); ?>">All Categories</a></li>
                    </ul>
                </li>

                <li class="has-children images">
                    <a href="#0">Media</a>
                    <ul>
                        <li><a href="<?php echo e(route('admin.media.index')); ?>">All Media</a> </li>
                        <li><a href="<?php echo e(route('admin.media.create')); ?>">Upload Media</a></li>
                    </ul>
                </li>

                <?php if(Auth::user()->role->name == 'administrator'): ?>

                <li class="overview"><a href="<?php echo e(route('cars.branches.index')); ?>">All Branches</a></li>

                <li class="has-children images">
                    <a href="#0">Cars</a>
                    <ul>
                        <li><a href="<?php echo e(route('cars.index')); ?>">All Cars</a></li>
                        <li><a href="<?php echo e(route('cars.create')); ?>">Create Car</a></li>
                    </ul>
                </li>

                <li class="has-children images">
                    <a href="#0">Car Characteristics</a>
                    <ul>
                        <li><a href="<?php echo e(route('cars.types.index')); ?>">All Types</a></li>
                        <li><a href="<?php echo e(route('cars.fuels.index')); ?>">All Fuels Types</a></li>
                        <li><a href="<?php echo e(route('cars.gearboxes.index')); ?>">All Gearboxes</a></li>
                    </ul>
                </li>

                <li class="has-children bookmarks">
                    <a href="#0">Car Reservations</a>
                    <ul>
                        <li><a href="<?php echo e(route('rent-a-car.show')); ?>">All Reservations</a></li>
                        <li><a href="<?php echo e(route('rent-a-car.search-car')); ?>">Create Reservation</a></li>
                    </ul>
                </li>

                <li class="has-children images">
                    <a href="#0">Bikes</a>
                    <ul>
                        <li><a href="<?php echo e(route('bikes.index')); ?>">All Bikes</a></li>
                        <li><a href="<?php echo e(route('bikes.create')); ?>">Create Bike</a></li>
                    </ul>
                </li>

                <li class="has-children bookmarks">
                    <a href="#0">Bike Reservations</a>
                    <ul>
                        <li><a href="<?php echo e(route('rent-a-bike.show')); ?>">All Reservations</a></li>
                        <li><a href="<?php echo e(route('rent-a-bike.search-bike')); ?>">Create Reservation</a></li>
                    </ul>
                </li>

                <li class="has-children images">
                    <a href="#0">Motos</a>
                    <ul>
                        <li><a href="<?php echo e(route('motos.index')); ?>">All Motos</a></li>
                        <li><a href="<?php echo e(route('motos.create')); ?>">Create Moto</a></li>
                    </ul>
                </li>

                <li class="has-children bookmarks">
                    <a href="#0">Moto Reservations</a>
                    <ul>
                        <li><a href="<?php echo e(route('rent-a-moto.show')); ?>">All Reservations</a></li>
                        <li><a href="<?php echo e(route('rent-a-moto.search-moto')); ?>">Create Reservation</a></li>
                    </ul>
                </li>

                 <?php endif; ?>

                <?php if(Auth::user()->role->name == 'author'): ?>
                        <li class="has-children bookmarks">
                            <a href="<?php echo e(route('rent-a-car.search-car')); ?>">Create Reservation</a>
                        </li>
                        <li class="has-children bookmarks">
                            <a href="<?php echo e(route('rent-a-bike.search-bike')); ?>">Create Reservation</a>
                        </li>
                        <li class="has-children bookmarks">
                            <a href="<?php echo e(route('rent-a-moto.search-moto')); ?>">Create Moto Reservation</a>
                        </li>
                <?php endif; ?>

            </ul>
        </nav>

        <div class="content-wrapper">
            <div class="alert alert-success fade in alert-dismissible" style="margin-top:50px;">
                <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
                 All buttons are <strong>disabled</strong> durring the demo.
            </div>
            <?php echo $__env->yieldContent('content'); ?>
        </div> <!-- .content-wrapper -->
    </main> <!-- .cd-main-content -->

    <script src="<?php echo e(asset('js/libs.js')); ?>"></script>

    <?php echo $__env->yieldContent('footer'); ?>

</body>
</html>