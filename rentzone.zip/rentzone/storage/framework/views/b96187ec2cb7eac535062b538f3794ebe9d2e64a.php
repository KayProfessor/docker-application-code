

<?php $__env->startSection('content'); ?>

    <?php if(count($rentalcars) > 0): ?>

        <h1>Rental Cars</h1>

        <div class="col-md-12">

            <table class="table-responsive-design">
                <thead>
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Car</th>
                    <th scope="col">Dates & Locations</th>
                    <th scope="col">price</th>
                    <th scope="col">User Information</th>
                    <th scope="col">status</th>
                    <th scope="col">action</th>
                </tr>
                </thead>
                <tbody>

                <?php if($rentalcars): ?>
                    <?php $__currentLoopData = $rentalcars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rentalcar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td data-label="ID"><?php echo e($rentalcar->id); ?></td>
                            <td data-label="Car"><?php echo e($rentalcar->car->name); ?></td>

                            <td data-label="Dates & Locations" align="left" width="90%"><a data-toggle="popover" data-trigger="click" data-content="<table class='table table-bordered'>
                                       <tr>
                                        <td>Pickup Location:</td><td><?php echo e($rentalcar->pickupConfiguration->location); ?></td>
                                        </tr>
                                        <tr>
                                        <td>Return Location:</td><td><?php echo e($rentalcar->returnConfiguration ? $rentalcar->returnConfiguration->location : $rentalcar->pickupConfiguration->location); ?></td>
                                        </tr>
                                        <tr>
                                        <td>Pickup Date:</td><td><?php echo e($rentalcar->pickupDate); ?></td>
                                        </tr>
                                        <tr>
                                        <td>Return Date:</td><td><?php echo e($rentalcar->returnDate); ?></td>
                                        </tr>
                                        <tr>
                                        <td>Pickup Time:</td><td><?php echo e($rentalcar->pickupTime); ?></td>
                                        </tr>
                                        <tr>
                                        <td>Return Time:</td><td><?php echo e($rentalcar->returnTime); ?></td>
                                        </tr>
                                       </table>" title="Dates & Locations" data-html="true" class="btn btn-info">Dates & Locations</a>
                            </td>

                            <td data-label="price"><?php echo e($rentalcar->price); ?> $</td>

                            <td data-label="User Information" align="left" width="90%"><a data-toggle="popover" data-trigger="click" data-content="<table class='table table-bordered'>
                                       <tr>
                                        <td>Name:</td><td><?php echo e($rentalcar->user->name); ?></td>
                                        </tr>
                                        <tr>
                                        <td>Email:</td><td><?php echo e($rentalcar->user->email); ?></td>
                                        </tr>
                                        <?php if($rentalcar->user->phone): ?>
                                        <tr>
                                        <td>Phone:</td><td><?php echo e($rentalcar->user->phone); ?></td>
                                        </tr>
                                        <?php endif; ?>
                                        <tr>
                                        <td>City:</td><td><?php echo e($rentalcar->user->city); ?></td>
                                        </tr>
                                        <tr>
                                        <td>Address:</td><td><?php echo e($rentalcar->user->address); ?></td>
                                        </tr>
                                       </table>" title="User Information" data-html="true" class="btn btn-info">User Information</a>
                            </td>

                            <td data-label="status">
                                <?php if($rentalcar->status == 0): ?>
                                    <span>Not Confirmed</span>
                                <?php elseif($rentalcar->status == 1): ?>
                                    <span>Confirmed</span>
                                <?php elseif($rentalcar->status == 2): ?>
                                    <span>Car Delivered</span>
                                <?php elseif($rentalcar->status == 3): ?>
                                    <span>Car Returned</span>
                                <?php endif; ?>
                            </td>
                            <td data-label="action">
                                <?php if($rentalcar->status == 0): ?>

                                    <?php echo Form::model($rentalcar, ['method' => 'PATCH', 'action' => ['RentalCarsController@update', $rentalcar->id] ]); ?>


                                    <input type="hidden" name="status" value="1">

                                    <div class="form-group">
                                        <?php echo Form::submit('Confirm', ['class' => 'btn btn-success']); ?>

                                    </div>

                                    <?php echo Form::close(); ?>


                                <?php elseif($rentalcar->status == 1): ?>

                                    <?php echo Form::model($rentalcar, ['method' => 'PATCH', 'action' => ['RentalCarsController@update', $rentalcar->id] ]); ?>


                                    <input type="hidden" name="status" value="2">

                                    <div class="form-group">
                                        <?php echo Form::submit('Car Picked Up', ['class' => 'btn btn-success']); ?>

                                    </div>

                                    <?php echo Form::close(); ?>


                                <?php elseif($rentalcar->status == 2): ?>

                                    <?php echo Form::model($rentalcar, ['method' => 'PATCH', 'action' => ['RentalCarsController@update', $rentalcar->id] ]); ?>


                                    <input type="hidden" name="status" value="3">

                                    <div class="form-group">
                                        <?php echo Form::submit('Car Returned', ['class' => 'btn btn-success']); ?>

                                    </div>

                                    <?php echo Form::close(); ?>


                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

                </tbody>
            </table>

        </div>

    <?php else: ?>
        <h1>No Reservations for Cars</h1>

    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <script>
        $(function () {
            $('[data-toggle="popover"]').popover();
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>