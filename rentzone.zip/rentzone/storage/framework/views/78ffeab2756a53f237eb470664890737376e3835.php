<?php $__env->startSection('content'); ?>
<div style="margin-top:50px" class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Dashboard</div>

                <div class="panel-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    You are logged in! <br>
                    Welcome <?php echo e(Auth::user()->name); ?>. You can go to 
                    <?php if(Auth::user()->role): ?>
                        <?php if(Auth::user()->role->name == 'client'): ?>
                            <a style="color:#21aa48" href="<?php echo e(route('user.user-profile')); ?>">Your profile</a>
                        <?php endif; ?>
                        <?php if(Auth::user()->role->name == 'author'): ?>
                            <a style="color:#21aa48" href="/admin/authors/<?php echo e(Auth::user()->id); ?>">Your profile</a>
                        <?php endif; ?>
                        <?php if(Auth::user()->role->name == 'administrator'): ?>
                            <a style="color:#21aa48" href="<?php echo e(url('/admin/users')); ?>/<?php echo e(auth()->user()->id); ?>/edit">Your profile</a>
                        <?php endif; ?>
                    <?php endif; ?>
                    page.
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>