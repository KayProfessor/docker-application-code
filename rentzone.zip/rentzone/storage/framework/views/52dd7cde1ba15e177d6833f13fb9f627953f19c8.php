<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <ul class="four steps steps1">
                    <li class="complete"></li>
                    <li class="complete"><a href="#">1</a><br><span class="stepstext"><?php echo trans('home.CHOOSE_DATE'); ?></span></li>
                    <li class="complete text-center"><a href="#">2</a><br><span class="stepstext"><?php echo trans('home.CHOOSE_BIKE'); ?></span></li>
                    <li><a href="#">3</a><br><span class="stepstext steplast"><?php echo trans('home.FINISH'); ?></span></li>
                </ul>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="row">

            <?php echo Form::open(['method' => 'GET', 'action' => 'RentalBikesController@final_step','id'=>'car-rental-form', 'files'=>true]); ?>


            <div class="col-md-12">
                <button href="#" onclick="return false;" class="btn btn-rent-title"><?php echo trans('home.Choose_Bike_in'); ?>

                <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($branch->id == $branch_pickup): ?>
                        <?php echo e($branch->name); ?>

                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </button>
            </div>

            <div class="col-md-12">
                <?php echo $__env->make('includes.form-errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>

            <input type="hidden" name="branch_pickup" value="<?php echo e($branch_pickup); ?>">
            <input type="hidden" name="branch_return" value="<?php echo e($branch_return); ?>">
            <input type="hidden" name="pickupDate" value="<?php echo e($pickupDate); ?>">
            <input type="hidden" name="returnDate" value="<?php echo e($returnDate); ?>">
            <input type="hidden" name="pickupTime" value="<?php echo e($pickupTime); ?>">
            <input type="hidden" name="returnTime" value="<?php echo e($returnTime); ?>">

            <?php ($date1=date_create($pickupDate)); ?>
            <?php ($date2=date_create($returnDate)); ?>
            <?php ($diff=date_diff($date1,$date2)); ?>
            <?php ($result=$diff->format("%a")); ?>


            <div class="vehicles">
                <?php $__currentLoopData = $bikes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bike): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($bike->branch->id == $branch_pickup && $bike->is_available == 1): ?>
                        <div class="rental_item col-lg-4 col-md-6">
                            <div class="wrap_img">
                                <div class="relative">
                                    <img class="featured" height="150" src="<?php echo e($bike->photo->file); ?>" alt="">
                                    <div class="flex-zone">
                                        <div class="flex-zone-inside">
                                            <a class="button-rent-it"><?php echo trans('home.SELECT_BIKE'); ?></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="bottom">
                                    <div class="wrap_btn">
                                        <a href="#" class="btn_price">
                                            <span class="wrap_content"><span class="amount"><span price="<?php echo e($bike->price_per_day); ?>" class="price-amount"><span class="currencySymbol">$</span><?php echo e($bike->price_per_day); ?></span></span><span class="time">/ <?php echo trans('home.Day'); ?> </span></span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="content">
                                <h3  name="<?php echo e($bike->id); ?>" class="title name"><?php echo e($bike->name); ?></h3>
                                <div class="car-type"><span><?php echo e($bike->type); ?></span></div>
                                <div class="features">
                                    <div class="container-fluid">
                                        <div class="row">
                                            <?php if($bike->bike_for): ?>
                                                <div class="feature-item odd"> <img src="<?php echo e(asset('public/img/icons/man.png')); ?>" alt=""><span><?php echo e($bike->bike_for); ?></span></div>
                                            <?php endif; ?>
                                            <?php if($bike->max_weight): ?>
                                                <div class="feature-item eve"> <img src="<?php echo e(asset('public/img/icons/weighing-scale.png')); ?>" alt=""><span><?php echo e($bike->max_weight); ?></span></div>
                                            <?php endif; ?>
                                            <?php if($bike->wheel_size): ?>
                                                <div class="feature-item odd"> <img src="<?php echo e(asset('public/img/icons/bike-wheel-size.png')); ?>" alt=""><span><?php echo e($bike->wheel_size); ?></span></div>
                                            <?php endif; ?>
                                            <?php if($bike->frame_size): ?>
                                                <div class="feature-item eve"> <img src="<?php echo e(asset('public/img/icons/bicycle-frame-size.png')); ?>" alt=""><span><?php echo e($bike->frame_size); ?></span></div>
                                            <?php endif; ?>
                                            <?php if($bike->chain): ?>
                                                <div class="feature-item odd"> <img src="<?php echo e(asset('public/img/icons/bike-chain.png')); ?>" alt=""><span><?php echo e($bike->chain); ?></span></div>
                                            <?php endif; ?>
                                            <?php if($bike->handlebar_width): ?>
                                                <div class="feature-item eve"> <img src="<?php echo e(asset('public/img/icons/handlebar-width.png')); ?>" alt=""><span><?php echo e($bike->handlebar_width); ?></span></div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <input class="bike-id required" type="hidden" name="bike_id" value="">

            <input type="hidden" name="status" value="0">

            <div id="next-step" class="col-md-12">
                <div class="form-group">
                    <?php echo Form::submit(Lang::get('home.Next_step'), ['class' => 'btn btn-primary']); ?>

                </div>
            </div>

            <p class="text"></p>
            <p class="total"></p>

            <div class="clearfix"></div>

            <?php echo Form::close(); ?>


        </div>
    </div> 

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

    <script>
        $(function() {
            /* parseaza bike id si price*/
            $('.vehicles .rental_item').on('click', function(){

                var name = $('.name', this ).attr('name');
                $('.bike-id' ).attr( "value", name );

                $('.vehicles .rental_item .flex-zone' ).removeClass( "active");
                $('.vehicles .rental_item .flex-zone .button-rent-it' ).text( '<?php echo __('home.SELECT_BIKE') ?>');

                $('.flex-zone',this ).addClass( "active");
                $('.flex-zone .button-rent-it',this ).text('<?php echo __('home.SELECTED') ?>');
            });
        });
    </script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>