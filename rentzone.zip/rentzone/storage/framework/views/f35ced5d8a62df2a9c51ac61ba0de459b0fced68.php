<?php $__env->startSection('content'); ?>



    <?php if(count($cars) > 0): ?>



        <h1>Cars</h1>



        <table class="table-responsive-design">

            <thead>

            <tr>

                <th scope="col">ID</th>

                <th scope="col">Name</th>

                <th scope="col">Image</th>

                <th scope="col">Price</th>

                <th scope="col">Characteristics</th>

                <th scope="col">Extra</th>

                <th scope="col">Available</th>

            </tr>

            </thead>

            <tbody>



            <?php if($cars): ?>

                <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr>

                        <td data-label="ID"><?php echo e($car->id); ?></td>

                        <td valign="center" data-label="Name"><a href="<?php echo e(route('cars.edit', $car->id)); ?>"><?php echo e($car->name); ?></a></td>

                        <td data-label="Image"><img height="50" src="<?php echo e($car->photo ? $car->photo->file : 'http://via.placeholder.com/200x200'); ?>" alt=""></td>

                        <td data-label="Price"><?php echo e($car->price_per_day_car); ?>$</td>

                        <td data-label="Car Characteristics" align="left" width="90%"><a data-toggle="popover" data-trigger="click" data-content="<table class='table table-bordered'>

                                       <tr>

                                        <td>Type Car:</td><td><?php echo e($car->type->name); ?></td>

                                       </tr>

                                       <tr>

                                        <td>AC:</td> <td> <?php echo e(($car->ac == 1) ? 'Yes' : 'No'); ?> </td>

                                       </tr>

                                       <tr>

                                        <td>Gearbox:</td> <td><?php echo e($car->gearbox->name); ?></td>

                                       </tr>

                                       <tr>

                                        <td>No. Passengers:</td> <td><?php echo e($car->passengers); ?></td>

                                       </tr>

                                       <tr>

                                        <td>No. Doors:</td> <td><?php echo e($car->doors); ?></td>

                                       </tr>

                                       <tr>

                                        <td>No. Suitcases:</td> <td><?php echo e($car->capacity); ?></td>

                                       </tr>

                                       <tr>

                                        <td>Location:</td> <td><?php echo e($car->branch->location); ?></td>

                                       </tr>

                                       <tr>

                                        <td>Fuel Type:</td> <td><?php echo e($car->fuel->name); ?></td>

                                       </tr>

                                       <tr>

                                        <td>Additional Info:</td> <td><?php echo e($car->aditional_info); ?></td>

                                       </tr>

                                       </table>" title="Characteristics" data-html="true" class="btn btn-info">Characteristics</a>

                        </td>

                        <td data-label="Optional Equipment:" align="left" width="80%"><a data-toggle="popover" data-trigger="click" data-content="<table class='table table-bordered'>

                                       <tr>

                                        <td>Optional GPS Price:</td> <td><?php echo e($car->gps); ?>$</td>

                                       </tr>

                                       <tr>

                                        <td>Optional Baby Chair Price:</td> <td><?php echo e($car->baby_chair); ?>$</td>

                                       </tr>

                                       <tr>

                                        <td>Optional Child Seat Price:</td> <td><?php echo e($car->child_seat); ?>$</td>

                                       </tr>

                                       <tr>

                                        <td>Optional WIFI Price:</td> <td><?php echo e($car->wifi_price); ?>$</td>

                                       </tr>

                                       <tr>

                                        <td>Optional Snow Chains Price:</td> <td><?php echo e($car->snow_chains); ?>$</td>

                                       </tr>

                                       <tr>

                                        <td>Optional Sky Support Price:</td> <td><?php echo e($car->sky_support); ?>$</td>

                                       </tr>

                                       </table>" title="Extra" data-html="true" class="btn btn-info">Extra</a>

                        </td>



                        <td data-label="Available">



                            <?php if($car->is_available == 0): ?>



                                <?php echo Form::model($car, ['method' => 'PATCH', 'action' => ['CarController@update', $car->id] ]); ?>


                                <input type="hidden" name="is_available" value="1">

                                <?php echo Form::submit('Yes', ['class' => 'btn btn-success']); ?>


                                <?php echo Form::close(); ?>




                            <?php elseif($car->is_available == 1): ?>



                                <?php echo Form::model($car, ['method' => 'PATCH', 'action' => ['CarController@update', $car->id] ]); ?>


                                <input type="hidden" name="is_available" value="0">

                                <?php echo Form::submit('No', ['class' => 'btn btn-danger']); ?>


                                <?php echo Form::close(); ?>




                            <?php endif; ?>



                        </td>

                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php endif; ?>



            </tbody>

        </table>

        



    <?php else: ?>

        <h1>No Cars</h1>



    <?php endif; ?>



<?php $__env->stopSection(); ?>



<?php $__env->startSection('footer'); ?>

    <script>

        $(function () {

            $('[data-toggle="popover"]').popover();

        });

    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>