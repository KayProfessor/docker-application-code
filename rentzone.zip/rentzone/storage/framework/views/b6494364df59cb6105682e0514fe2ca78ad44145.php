<?php $__env->startSection('content'); ?>
    <h1><?php echo trans('home.Update'); ?> <?php echo trans('home.Branche'); ?></h1>
    <?php echo Form::model($branch, ['method' => 'PATCH', 'action' => ['CarBranchController@update', $branch->id], 'files'=>true]); ?>

    <div class="form-group">
        <?php echo Form::label('name', 'Name:'); ?>

        <?php echo Form::text('name', null, ['class' => 'form-control']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('email', 'Email:'); ?>

        <?php echo Form::email('email', null, ['class' => 'form-control']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('address', Lang::get('home.Address')); ?>

        <?php echo Form::text('address', null, ['class' => 'form-control']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('location', Lang::get('home.Location')); ?>

        <?php echo Form::text('location', null, ['class' => 'form-control']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('phone', Lang::get('home.Phone')); ?>

        <?php echo Form::text('phone', null, ['class' => 'form-control']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::submit(Lang::get('home.Update'), ['class' => 'btn btn-primary']); ?>

    </div>
    <?php echo $__env->make('includes.form-errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo Form::close(); ?>

    <?php echo Form::open(['method' => 'DELETE', 'action' => ['CarBranchController@destroy', $branch->id]]); ?>

    <div class="form-group">
        <?php echo Form::submit(Lang::get('home.Delete'), ['class' => 'btn btn-danger']); ?>

    </div>
    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>