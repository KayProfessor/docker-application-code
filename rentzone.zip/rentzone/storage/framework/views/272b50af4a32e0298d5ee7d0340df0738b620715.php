

<?php $__env->startSection('content'); ?>

    <?php if(count($rentalmotos) > 0): ?>

        <h1>Rental Moto</h1>

        <div class="col-md-12">

            <table class="table-responsive-design">
                <thead>
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Moto</th>
                    <th scope="col">Dates & Locations</th>
                    <th scope="col">price</th>
                    <th scope="col">User Information</th>
                    <th scope="col">status</th>
                    <th scope="col">action</th>
                </tr>
                </thead>
                <tbody>

                <?php if($rentalmotos): ?>
                    <?php $__currentLoopData = $rentalmotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rentalmoto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td data-label="ID"><?php echo e($rentalmoto->id); ?></td>
                            <td data-label="Moto"><?php echo e($rentalmoto->moto->name); ?></td>

                            <td data-label="Dates & Locations" align="left" width="90%"><a data-toggle="popover" data-trigger="click" data-content="<table class='table table-bordered'>
                                       <tr>
                                        <td>Pickup Location:</td><td><?php echo e($rentalmoto->pickupConfiguration->location); ?></td>
                                        </tr>
                                        <tr>
                                        <td>Return Location:</td><td><?php echo e($rentalmoto->returnConfiguration ? $rentalmoto->returnConfiguration->location : $rentalmoto->pickupConfiguration->location); ?></td>
                                        </tr>
                                        <tr>
                                        <td>Pickup Date:</td><td><?php echo e($rentalmoto->pickupDate); ?></td>
                                        </tr>
                                        <tr>
                                        <td>Return Date:</td><td><?php echo e($rentalmoto->returnDate); ?></td>
                                        </tr>
                                        <tr>
                                        <td>Pickup Time:</td><td><?php echo e($rentalmoto->pickupTime); ?></td>
                                        </tr>
                                        <tr>
                                        <td>Return Time:</td><td><?php echo e($rentalmoto->returnTime); ?></td>
                                        </tr>
                                       </table>" title="Dates & Locations" data-html="true" class="btn btn-info">Dates & Locations</a>
                            </td>

                            <td data-label="price"><?php echo e($rentalmoto->price); ?> $</td>

                            <td data-label="User Information" align="left" width="90%"><a data-toggle="popover" data-trigger="click" data-content="<table class='table table-bordered'>
                                       <tr>
                                        <td>Name:</td><td><?php echo e($rentalmoto->user->name); ?></td>
                                        </tr>
                                        <tr>
                                        <td>Email:</td><td><?php echo e($rentalmoto->user->email); ?></td>
                                        </tr>
                                        <?php if($rentalmoto->user->phone): ?>
                                        <tr>
                                        <td>Phone:</td><td><?php echo e($rentalmoto->user->phone); ?></td>
                                        </tr>
                                        <?php endif; ?>
                                        <tr>
                                        <td>City:</td><td><?php echo e($rentalmoto->user->city); ?></td>
                                        </tr>
                                        <tr>
                                        <td>Address:</td><td><?php echo e($rentalmoto->user->address); ?></td>
                                        </tr>
                                       </table>" title="User Information" data-html="true" class="btn btn-info">User Information</a>
                            </td>

                            <td data-label="status">
                                <?php if($rentalmoto->status == 0): ?>
                                    <span>Not Confirmed</span>
                                <?php elseif($rentalmoto->status == 1): ?>
                                    <span>Confirmed</span>
                                <?php elseif($rentalmoto->status == 2): ?>
                                    <span>Moto Delivered</span>
                                <?php elseif($rentalmoto->status == 3): ?>
                                    <span>Moto Returned</span>
                                <?php endif; ?>
                            </td>
                            <td data-label="action">
                                <?php if($rentalmoto->status == 0): ?>

                                    <?php echo Form::model($rentalmoto, ['method' => 'PATCH', 'action' => ['RentalMotoController@update', $rentalmoto->id] ]); ?>


                                    <input type="hidden" name="status" value="1">

                                    <div class="form-group">
                                        <?php echo Form::submit('Confirm', ['class' => 'btn btn-success']); ?>

                                    </div>

                                    <?php echo Form::close(); ?>


                                <?php elseif($rentalmoto->status == 1): ?>

                                    <?php echo Form::model($rentalmoto, ['method' => 'PATCH', 'action' => ['RentalMotoController@update', $rentalmoto->id] ]); ?>


                                    <input type="hidden" name="status" value="2">

                                    <div class="form-group">
                                        <?php echo Form::submit('Moto Picked Up', ['class' => 'btn btn-success']); ?>

                                    </div>

                                    <?php echo Form::close(); ?>


                                <?php elseif($rentalmoto->status == 2): ?>

                                    <?php echo Form::model($rentalmoto, ['method' => 'PATCH', 'action' => ['RentalMotoController@update', $rentalmoto->id] ]); ?>


                                    <input type="hidden" name="status" value="3">

                                    <div class="form-group">
                                        <?php echo Form::submit('Moto Returned', ['class' => 'btn btn-success']); ?>

                                    </div>

                                    <?php echo Form::close(); ?>


                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

                </tbody>
            </table>

        </div>

    <?php else: ?>
        <h1>No Reservations for Motos</h1>

    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <script>
        $(function () {
            $('[data-toggle="popover"]').popover();
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>