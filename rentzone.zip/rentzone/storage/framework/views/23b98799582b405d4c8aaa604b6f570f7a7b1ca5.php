<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>RentZone</title>
    <link rel="icon" href="<?php echo e(asset('public/img/favicon.ico')); ?>" type="image/ico" sizes="16x16">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/libs/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/libs/font-awesome.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/libs/style.css')); ?>" rel="stylesheet">
    <?php echo $__env->yieldContent('styles'); ?>
</head>
<body>
<div id="app">
    <nav class="rent-zone-nav navbar navbar-default navbar-static-top">
        <div class="container">
            <div class="navbar-header">

                <!-- Collapsed Hamburger -->
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse">
                    <span class="sr-only">Toggle Navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>

                <!-- Branding Image -->
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    <img src="<?php echo e(asset('public/img/logo-black.png')); ?>" alt="">
                </a>
            </div>

            <div class="collapse navbar-collapse" id="app-navbar-collapse">

                <!-- Right Side Of Navbar -->
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="/"><i class="fa fa-car" aria-hidden="true"></i>
                            Rent a car</a></li>
                    <li><a href="<?php echo e(route('rent-a-bike.search-bike')); ?>"><i class="fa fa-bicycle" aria-hidden="true"></i>
                            Rent a bike</a></li>
                    <li><a href="<?php echo e(route('rent-a-moto.search-moto')); ?>"><i class="fa fa-motorcycle" aria-hidden="true"></i>
                            Rent a moto</a></li>
                    <!-- Authentication Links -->
                    <?php if(Auth::guest()): ?>
                        <li><a href="<?php echo e(route('login')); ?>"><i class="fa fa-sign-in"></i> Login</a></li>
                        <li><a href="<?php echo e(route('register')); ?>"><i class="fa fa-user-plus" aria-hidden="true"></i> Register</a></li>
                    <?php else: ?>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                                <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                            </a>

                            <ul class="dropdown-menu" role="menu">
                                <li>
                                    <?php if(Auth::user()->role): ?>
                                        <?php if(Auth::user()->role->name == 'client'): ?>
                                            <a href="<?php echo e(route('user.user-profile')); ?>">My profile</a>
                                        <?php endif; ?>
                                        <?php if(Auth::user()->role->name == 'administrator'): ?>
                                            <a href="<?php echo e(url('/admin/users')); ?>/<?php echo e(auth()->user()->id); ?>/edit">My profile</a>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                             document.getElementById('logout-form').submit();">
                                        Logout
                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo e(csrf_field()); ?>

                                    </form>
                                </li>
                            </ul>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>
    <div class="auth-content">
        <?php echo $__env->yieldContent('content'); ?>
    </div>

</div>

<!-- Scripts -->
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<?php echo $__env->yieldContent('footer'); ?>
</body>
</html>
