

<?php $__env->startSection('content'); ?>

    <div class="container user-information-section">
        <div class="row">


            <div class="col-md-3">
                <ul id="nav-tabs-wrapper" class="nav nav-pills nav-stacked well menu-my-account">
                    <li><a href="<?php echo e(route('user.user-profile')); ?>" title="">Overview</a></li>
                    <li class="active"><a href="<?php echo e(route('user.user-edit')); ?>" title="">Profile</a></li>
                    <li><a href="<?php echo e(route('user.user-reservations')); ?>" title="">Reservations</a></li>
                </ul>
                <br>
                <ul id="nav-tabs-wrapper" class="nav nav-pills nav-stacked well menu-my-account">
                    <li class="rent-now-btn"><a href="<?php echo e(route('rent-a-car.search-car')); ?>">Rent a car</a></li>
                    <li class="rent-now-btn"><a href="<?php echo e(route('rent-a-bike.search-bike')); ?>">Rent a bike</a></li>
                    <li class="rent-now-btn"><a href="<?php echo e(route('rent-a-moto.search-moto')); ?>">Rent a moto</a></li>
                </ul>
            </div>

            <div class="col-md-9">

                <div class="row">
                    <div class="col-md-4">
                        <img class="img-responsive img-rounded" src="<?php echo e(Auth::user()->photo ? Auth::user()->photo['file'] : 'http://via.placeholder.com/200x200'); ?>" alt="">
                    </div>

                    <div class="col-md-8">
                        <h1 class="name"><?php echo e(Auth::user()->name); ?></h1>
                        <?php if(Auth::user()->email): ?>
                            <p><i class="fa fa-envelope-o" aria-hidden="true"></i> <?php echo e(Auth::user()->email); ?></p>
                        <?php endif; ?>
                        <?php if(Auth::user()->phone): ?>
                            <p><i class="fa fa-phone" aria-hidden="true"></i> <?php echo e(Auth::user()->phone); ?></p>
                        <?php endif; ?>
                        <?php if(Auth::user()->city || Auth::user()->address): ?>
                            <p><i class="fa fa-map-marker" aria-hidden="true"></i> <?php echo e(Auth::user()->city); ?>, <?php echo e(Auth::user()->address); ?></p>
                        <?php endif; ?>
                    </div>
                </div>

                <?php echo Form::model($user, ['method' => 'POST', 'action' => ['RentalCarsController@user_update', $user->id], 'id' => 'user_update_form', 'files' => true] ); ?>


                <div class="form-group">
                    <?php echo Form::label('name', 'Name:'); ?>

                    <?php echo Form::text('name', null, ['class' => 'form-control']); ?>

                </div>

                <div class="form-group">
                    <?php echo Form::label('email', 'Email:'); ?>

                    <?php echo Form::email('email', null, ['class' => 'form-control']); ?>

                </div>

                <div class="form-group">
                    <?php echo Form::label('phone', 'Phone:'); ?>

                    <?php echo Form::text('phone', null, ['class' => 'form-control']); ?>

                </div>

                <div class="form-group">
                    <?php echo Form::label('city', 'City:'); ?>

                    <?php echo Form::text('city', null, ['class' => 'form-control']); ?>

                </div>

                <div class="form-group">
                    <?php echo Form::label('address', 'Address:'); ?>

                    <?php echo Form::text('address', null, ['class' => 'form-control']); ?>

                </div>

                <div class="form-group">
                    <?php echo Form::label('photo_id', 'Photo:'); ?>

                    <?php echo Form::file('photo_id', null, ['class' => 'form-control']); ?>

                </div>

                <div class="form-group">
                    <?php echo Form::submit('Update Profile', ['class' => 'btn btn-primary']); ?>

                </div>

                <?php echo $__env->make('includes.form-errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                <?php echo Form::close(); ?>

            </div>

        </div> 
    </div> 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>