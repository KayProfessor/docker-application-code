

<?php $__env->startSection('content'); ?>

    <?php if(count($rentalbikes) > 0): ?>

        <h1>Rental Bikes</h1>

        <div class="col-md-12">

            <table class="table-responsive-design">
                <thead>
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Bike</th>
                    <th scope="col">Dates & Locations</th>
                    <th scope="col">price</th>
                    <th scope="col">User Information</th>
                    <th scope="col">status</th>
                    <th scope="col">action</th>
                </tr>
                </thead>
                <tbody>

                <?php if($rentalbikes): ?>
                    <?php $__currentLoopData = $rentalbikes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rentalbike): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td data-label="ID"><?php echo e($rentalbike->id); ?></td>
                            <td data-label="Bike"><?php echo e($rentalbike->bike->name); ?></td>

                            <td data-label="Dates & Locations" align="left" width="90%"><a data-toggle="popover" data-trigger="click" data-content="<table class='table table-bordered'>
                                       <tr>
                                        <td>Pickup Location:</td><td><?php echo e($rentalbike->pickupConfiguration->location); ?></td>
                                        </tr>
                                        <tr>
                                        <td>Return Location:</td><td><?php echo e($rentalbike->returnConfiguration ? $rentalbike->returnConfiguration->location : $rentalbike->pickupConfiguration->location); ?></td>
                                        </tr>
                                        <tr>
                                        <td>Pickup Date:</td><td><?php echo e($rentalbike->pickupDate); ?></td>
                                        </tr>
                                        <tr>
                                        <td>Return Date:</td><td><?php echo e($rentalbike->returnDate); ?></td>
                                        </tr>
                                        <tr>
                                        <td>Pickup Time:</td><td><?php echo e($rentalbike->pickupTime); ?></td>
                                        </tr>
                                        <tr>
                                        <td>Return Time:</td><td><?php echo e($rentalbike->returnTime); ?></td>
                                        </tr>
                                       </table>" title="Dates & Locations" data-html="true" class="btn btn-info">Dates & Locations</a>
                            </td>

                            <td data-label="price"><?php echo e($rentalbike->price); ?> $</td>

                            <td data-label="User Information" align="left" width="90%"><a data-toggle="popover" data-trigger="click" data-content="<table class='table table-bordered'>
                                       <tr>
                                        <td>Name:</td><td><?php echo e($rentalbike->user->name); ?></td>
                                        </tr>
                                        <tr>
                                        <td>Email:</td><td><?php echo e($rentalbike->user->email); ?></td>
                                        </tr>
                                        <?php if($rentalbike->user->phone): ?>
                                        <tr>
                                        <td>Phone:</td><td><?php echo e($rentalbike->user->phone); ?></td>
                                        </tr>
                                        <?php endif; ?>
                                        <tr>
                                        <td>City:</td><td><?php echo e($rentalbike->user->city); ?></td>
                                        </tr>
                                        <tr>
                                        <td>Address:</td><td><?php echo e($rentalbike->user->address); ?></td>
                                        </tr>
                                       </table>" title="User Information" data-html="true" class="btn btn-info">User Information</a>
                            </td>

                            <td data-label="status">
                                <?php if($rentalbike->status == 0): ?>
                                    <span>Not Confirmed</span>
                                <?php elseif($rentalbike->status == 1): ?>
                                    <span>Confirmed</span>
                                <?php elseif($rentalbike->status == 2): ?>
                                    <span>Bike Delivered</span>
                                <?php elseif($rentalbike->status == 3): ?>
                                    <span>Bike Returned</span>
                                <?php endif; ?>
                            </td>
                            <td data-label="action">
                                <?php if($rentalbike->status == 0): ?>

                                    <?php echo Form::model($rentalbike, ['method' => 'PATCH', 'action' => ['RentalBikesController@update', $rentalbike->id] ]); ?>


                                    <input type="hidden" name="status" value="1">

                                    <div class="form-group">
                                        <?php echo Form::submit('Confirm', ['class' => 'btn btn-success']); ?>

                                    </div>

                                    <?php echo Form::close(); ?>


                                <?php elseif($rentalbike->status == 1): ?>

                                    <?php echo Form::model($rentalbike, ['method' => 'PATCH', 'action' => ['RentalBikesController@update', $rentalbike->id] ]); ?>


                                    <input type="hidden" name="status" value="2">

                                    <div class="form-group">
                                        <?php echo Form::submit('Bike Picked Up', ['class' => 'btn btn-success']); ?>

                                    </div>

                                    <?php echo Form::close(); ?>


                                <?php elseif($rentalbike->status == 2): ?>

                                    <?php echo Form::model($rentalbike, ['method' => 'PATCH', 'action' => ['RentalBikesController@update', $rentalbike->id] ]); ?>


                                    <input type="hidden" name="status" value="3">

                                    <div class="form-group">
                                        <?php echo Form::submit('Bike Returned', ['class' => 'btn btn-success']); ?>

                                    </div>

                                    <?php echo Form::close(); ?>


                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

                </tbody>
            </table>

        </div>

    <?php else: ?>
        <h1>No Reservations for Bikes</h1>

    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <script>
        $(function () {
            $('[data-toggle="popover"]').popover();
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>