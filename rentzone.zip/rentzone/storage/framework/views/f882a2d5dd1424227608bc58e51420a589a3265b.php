<?php $__env->startSection('content'); ?>
    <h1><?php echo trans('home.Create'); ?> <?php echo trans('home.Bikes'); ?></h1>
    <?php echo Form::open(['method' => 'POST', 'action' => 'BikeController@store', 'files'=>true]); ?>

    <?php echo $__env->make('includes.form-errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="row">
        <div class="col-md-6">
        <div class="form-group">
                <?php echo Form::label('name', Lang::get('home.Bike')); ?>

                <?php echo Form::text('name', null, ['class' => 'form-control']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('branch_id', Lang::get('home.Location')); ?>

                <?php echo Form::select('branch_id', [''=> 'Choose Location'] + $branches, null, ['class' => 'form-control']); ?>

            </div>

            <div class="form-group">
                <?php ($day_price = Lang::get('home.PRICE') . '/' . Lang::get('home.Day') . '($)'); ?>
                <?php echo Form::label('price_per_day', $day_price); ?>

                <?php echo Form::text('price_per_day', null, ['class' => 'form-control']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('type', Lang::get('home.Type')); ?>

                <?php echo Form::text('type', null, ['class' => 'form-control']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('bike_for', Lang::get('home.Bike_For')); ?>

                <?php echo Form::text('bike_for', null, ['class' => 'form-control']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('max_weight', Lang::get('home.Maximum_weight_supported')); ?>

                <?php echo Form::text('max_weight', null, ['class' => 'form-control']); ?>

            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group">
                <?php echo Form::label('handlebar_width', Lang::get('home.Handlebar_width')); ?>

                <?php echo Form::text('handlebar_width', null, ['class' => 'form-control']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('wheel_size', Lang::get('home.Wheel_size')); ?>

                <?php echo Form::text('wheel_size', null, ['class' => 'form-control']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('frame_size', Lang::get('home.Frame_size')); ?>

                <?php echo Form::text('frame_size', null, ['class' => 'form-control']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('chain', Lang::get('home.Chain')); ?>

                <?php echo Form::text('chain', null, ['class' => 'form-control']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('photo_id', Lang::get('home.Image')); ?>

                <?php echo Form::file('photo_id', null, ['class' => 'form-control']); ?>

            </div>
<!--             <div class="form-group">
                <?php echo Form::submit(Lang::get('home.Create'), ['class' => 'btn btn-primary']); ?>

            </div> -->
        </div>
    </div>
    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>