<?php $__env->startSection('content'); ?>



    <?php if(count($bikes) > 0): ?>



        <h1>Bikes</h1>



        <table class="table-responsive-design">

            <thead>

            <tr>

                <th scope="col">ID</th>

                <th scope="col">Name</th>

                <th scope="col">Image</th>

                <th scope="col">Price</th>

                <th scope="col">Characteristics</th>

                <th scope="col">Available</th>

            </tr>

            </thead>

            <tbody>



            <?php if($bikes): ?>

                <?php $__currentLoopData = $bikes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bike): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr>

                        <td data-label="ID"><?php echo e($bike->id); ?></td>

                        <td valign="center" data-label="Name"><a href="<?php echo e(route('bikes.edit', $bike->id)); ?>"><?php echo e($bike->name); ?></a></td>

                        <td data-label="Image"><img height="50" src="<?php echo e($bike->photo ? $bike->photo->file : 'http://via.placeholder.com/200x200'); ?>" alt=""></td>

                        <td data-label="Price"><?php echo e($bike->price_per_day); ?>$</td>

                        <td data-label="Bike Characteristics" align="left" width="90%"><a data-toggle="popover" data-trigger="click" data-content="<table class='table table-bordered'>

                                       <tr>

                                        <td>Bike Type:</td><td><?php echo e($bike->type); ?></td>

                                       </tr>

                                        <tr>

                                        <td>Bike For :</td><td><?php echo e($bike->bike_for); ?></td>

                                       </tr>

                                       <tr>

                                        <td>Maximum weight supported :</td><td><?php echo e($bike->max_weight); ?></td>

                                       </tr>

                                       <tr>

                                        <td>Handlebar width :</td><td><?php echo e($bike->handlebar_width); ?></td>

                                       </tr>

                                       <tr>

                                        <td>Wheel size :</td><td><?php echo e($bike->wheel_size); ?></td>

                                       </tr>

                                       <tr>

                                        <td>Frame size :</td><td><?php echo e($bike->frame_size); ?></td>

                                       </tr>

                                       <tr>

                                        <td>Chain :</td><td><?php echo e($bike->chain); ?></td>

                                       </tr>

                                       <tr>

                                        <td>Location :</td><td><?php echo e($bike->branch->location); ?></td>

                                       </tr>

                                       </table>" title="Characteristics" data-html="true" class="btn btn-info">Characteristics</a>

                        </td>

                        <td data-label="Available">



                            <?php if($bike->is_available == 0): ?>



                                <?php echo Form::model($bike, ['method' => 'PATCH', 'action' => ['BikeController@update', $bike->id] ]); ?>


                                <input type="hidden" name="is_available" value="1">

                                <?php echo Form::submit('Yes', ['class' => 'btn btn-success']); ?>


                                <?php echo Form::close(); ?>




                            <?php elseif($bike->is_available == 1): ?>



                                <?php echo Form::model($bike, ['method' => 'PATCH', 'action' => ['BikeController@update', $bike->id] ]); ?>


                                <input type="hidden" name="is_available" value="0">

                                <?php echo Form::submit('No', ['class' => 'btn btn-danger']); ?>


                                <?php echo Form::close(); ?>




                            <?php endif; ?>



                        </td>

                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php endif; ?>



            </tbody>

        </table>





    <?php else: ?>

        <h1>No Bikes</h1>



    <?php endif; ?>



<?php $__env->stopSection(); ?>



<?php $__env->startSection('footer'); ?>

    <script>

        $(function () {

            $('[data-toggle="popover"]').popover();

        });

    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>