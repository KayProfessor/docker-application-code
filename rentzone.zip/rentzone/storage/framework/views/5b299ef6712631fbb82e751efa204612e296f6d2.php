<?php $__env->startSection('content'); ?>
    <?php if(count($rentalcars) > 0): ?>
        <h1><?php echo trans('home.Rental'); ?> <?php echo trans('home.Cars'); ?></h1>
        <div class="col-md-12">
            <table class="table-responsive-design">
                <thead>
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col"><?php echo trans('home.Car'); ?></th>
                    <th scope="col"><?php echo trans('home.DATES_LOCATIONS'); ?></th>
                    <th scope="col"><?php echo trans('home.PRICE'); ?></th>
                    <th scope="col"><?php echo trans('home.User_information'); ?></th>
                    <th scope="col"><?php echo trans('home.Status'); ?></th>
                    <th scope="col"><?php echo trans('home.Action'); ?></th>
                </tr>
                </thead>
                <tbody>
                <?php if($rentalcars): ?>
                    <?php $__currentLoopData = $rentalcars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rentalcar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td data-label="ID"><?php echo e($rentalcar->id); ?></td>
                            <td data-label="<?php echo trans('home.Car'); ?>"><?php echo e($rentalcar->car->name); ?></td>
                            <td data-label="<?php echo trans('home.DATES_LOCATIONS'); ?>" align="left" width="90%"><a data-toggle="popover" data-trigger="click" data-content="<table class='table table-bordered'>
                                       <tr>
                                        <td><?php echo trans('home.Pickup_Location'); ?>:</td><td><?php echo e($rentalcar->pickupConfiguration->location); ?></td>
                                        </tr>
                                        <tr>
                                        <td><?php echo trans('home.Return_Location'); ?>:</td><td><?php echo e($rentalcar->returnConfiguration ? $rentalcar->returnConfiguration->location : $rentalcar->pickupConfiguration->location); ?></td>
                                        </tr>
                                        <tr>
                                        <td><?php echo trans('home.Pickup_Date'); ?>:</td><td><?php echo e($rentalcar->pickupDate); ?></td>
                                        </tr>
                                        <tr>
                                        <td><?php echo trans('home.Return_Date'); ?>:</td><td><?php echo e($rentalcar->returnDate); ?></td>
                                        </tr>
                                        <tr>
                                        <td><?php echo trans('home.Pickup_Time'); ?>:</td><td><?php echo e($rentalcar->pickupTime); ?></td>
                                        </tr>
                                        <tr>
                                        <td><?php echo trans('home.Return_Time'); ?>:</td><td><?php echo e($rentalcar->returnTime); ?></td>
                                        </tr>
                                        <tr>
                                        <td><?php echo trans('home.Flight_number'); ?>:</td><td><?php echo e($rentalcar->flight_number); ?></td>
                                        </tr>
                                        <tr>
                                        <td><?php echo trans('home.Reservation_info'); ?>:</td><td><?php echo e($rentalcar->reservation_info); ?></td>
                                        </tr>
                                       </table>" title="<?php echo trans('home.DATES_LOCATIONS'); ?>" data-html="true" class="btn btn-info"><?php echo trans('home.DATES_LOCATIONS'); ?></a>
                            </td>
                            <td data-label="<?php echo trans('home.PRICE'); ?>"><?php echo e($rentalcar->price); ?> $</td>
                            <td data-label="<?php echo trans('home.User_information'); ?>" align="left" width="90%"><a data-toggle="popover" data-trigger="click" data-content="<table class='table table-bordered'>
                                       <tr>
                                        <td>Name:</td><td><?php echo e($rentalcar->user->name); ?></td>
                                        </tr>
                                        <tr>
                                        <td>Email:</td><td><?php echo e($rentalcar->user->email); ?></td>
                                        </tr>
                                        <?php if($rentalcar->user->phone): ?>
                                        <tr>
                                        <td><?php echo trans('home.Phone'); ?>:</td><td><?php echo e($rentalcar->user->phone); ?></td>
                                        </tr>
                                        <?php endif; ?>
                                        <tr>
                                        <td><?php echo trans('home.City'); ?>:</td><td><?php echo e($rentalcar->user->city); ?></td>
                                        </tr>
                                        <tr>
                                        <td><?php echo trans('home.Address'); ?>:</td><td><?php echo e($rentalcar->user->address); ?></td>
                                        </tr>
                                       </table>" title="<?php echo trans('home.User_information'); ?>" data-html="true" class="btn btn-info"><?php echo trans('home.User_information'); ?></a>
                            </td>
                            <td data-label="<?php echo trans('home.Status'); ?>">
                                <?php if($rentalcar->status == 0): ?>
                                    <span><?php echo trans('home.Not'); ?> <?php echo trans('home.Confirmed'); ?></span>
                                <?php elseif($rentalcar->status == 1): ?>
                                    <span><?php echo trans('home.Confirmed'); ?></span>
                                <?php elseif($rentalcar->status == 2): ?>
                                    <span><?php echo trans('home.Car'); ?> <?php echo trans('home.Delivered'); ?></span>
                                <?php elseif($rentalcar->status == 3): ?>
                                    <span><?php echo trans('home.Car'); ?> <?php echo trans('home.Returned'); ?></span>
                                <?php endif; ?>
                            </td>
                            <td data-label="<?php echo trans('home.Action'); ?>">
                                <?php if($rentalcar->status == 0): ?>
                                    <?php echo Form::model($rentalcar, ['method' => 'PATCH', 'action' => ['RentalCarsController@update', $rentalcar->id] ]); ?>

                                    <input type="hidden" name="status" value="1">
                                    <div class="form-group">
                                        <?php echo Form::submit(Lang::get('home.Confirm'), ['class' => 'btn btn-success']); ?>

                                    </div>
                                    <?php echo Form::close(); ?>

                                <?php elseif($rentalcar->status == 1): ?>
                                    <?php ($car_picked_up = Lang::get('home.Car') . ' ' . Lang::get('home.Picked_Up') ); ?>
                                    <?php echo Form::model($rentalcar, ['method' => 'PATCH', 'action' => ['RentalCarsController@update', $rentalcar->id] ]); ?>

                                    <input type="hidden" name="status" value="2">
                                    <div class="form-group">
                                        <?php echo Form::submit($car_picked_up, ['class' => 'btn btn-success']); ?>

                                    </div>
                                    <?php echo Form::close(); ?>

                                <?php elseif($rentalcar->status == 2): ?>
                                    <?php ($car_returned = Lang::get('home.Car') . ' ' . Lang::get('home.Returned') ); ?>
                                    <?php echo Form::model($rentalcar, ['method' => 'PATCH', 'action' => ['RentalCarsController@update', $rentalcar->id] ]); ?>

                                    <input type="hidden" name="status" value="3">
                                    <div class="form-group">
                                        <?php echo Form::submit($car_returned, ['class' => 'btn btn-success']); ?>

                                    </div>
                                    <?php echo Form::close(); ?>

                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <h1><?php echo trans('home.Not'); ?> <?php echo trans('home.Reservations'); ?> <?php echo trans('home.Cars'); ?></h1>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <script>
        $(function () {
            $('[data-toggle="popover"]').popover();
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>