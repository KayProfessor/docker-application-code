<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>RentZone</title>
    <link rel="icon" href="<?php echo e(asset('public/img/favicon.ico')); ?>" type="image/ico" sizes="16x16">
    <!-- Styles -->
    <link href="<?php echo e(asset('css/libs/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/libs/font-awesome.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/libs/style.css')); ?>" rel="stylesheet">
    <?php echo $__env->yieldContent('styles'); ?>
</head>
<body>
<div id="app">
    <nav class="rent-zone-nav navbar navbar-default navbar-static-top">
        <div class="container">
            <div class="navbar-header">
                <!-- Collapsed Hamburger -->
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse">
                    <span class="sr-only">Toggle Navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <!-- Branding Image -->
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    <img src="<?php echo e(asset('public/img/logo-black.png')); ?>" alt="">
                </a>
            </div>
            <div class="collapse navbar-collapse" id="app-navbar-collapse">
                <!-- Right Side Of Navbar -->
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="/"><i class="fa fa-car" aria-hidden="true"></i>
                            Rent a car</a></li>
                    <li><a href="<?php echo e(route('rent-a-bike.search-bike')); ?>"><i class="fa fa-bicycle" aria-hidden="true"></i>
                            Rent a bike</a></li>
                    <li><a href="<?php echo e(route('rent-a-moto.search-moto')); ?>"><i class="fa fa-motorcycle" aria-hidden="true"></i>
                            Rent a moto</a></li>
                    <!-- Authentication Links -->
                    <?php if(Auth::guest()): ?>
                        <li><a href="<?php echo e(route('login')); ?>"><i class="fa fa-sign-in"></i> Login</a></li>
                        <li><a href="<?php echo e(route('register')); ?>"><i class="fa fa-user-plus" aria-hidden="true"></i> Register</a></li>
                    <?php else: ?>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                                <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                            </a>
                            <ul class="dropdown-menu" role="menu">
                                <li>
                                    <?php if(Auth::user()->role): ?>
                                        <?php if(Auth::user()->role->name == 'client'): ?>
                                            <a href="<?php echo e(route('user.user-profile')); ?>">My profile</a>
                                        <?php endif; ?>
                                        <?php if(Auth::user()->role->name == 'author'): ?>
                                            <a href="<?php echo e(url('/admin/authors')); ?>/<?php echo e(Auth::user()->id); ?>">My profile</a>
                                        <?php endif; ?>
                                        <?php if(Auth::user()->role->name == 'administrator'): ?>
                                            <a href="<?php echo e(url('/admin/users')); ?>/<?php echo e(Auth::user()->id); ?>/edit">My profile</a>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                             document.getElementById('logout-form').submit();">
                                        Logout
                                    </a>
                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo e(csrf_field()); ?>

                                    </form>
                                </li>
                            </ul>
                        </li>
                    <?php endif; ?>
                    <li><a href="https://codecanyon.net/item/rentzone-laravel-rental-management-system/22598152"><i class="fa fa-shopping-basket" aria-hidden="true"></i>
 Buy</a></li>
                </ul>
            </div>
        </div>
    </nav>
    <?php echo $__env->yieldContent('content'); ?>
    <div class="band pawb">
        <div class="container">
            <div class="col-md-12">
                <div class="row">
                    <ul class="nav nav-justified nopadding">
                        <li>
                            <div class="sliderbuttons nopadding">
                                <i class="fa fa-check bbb" aria-hidden="true"></i>New Vehicles
                            </div>
                        </li>
                        <li>
                            <div class="sliderbuttons nopadding" href="#">
                                <i class="fa fa-check bbb" aria-hidden="true"></i> City Free Delivery
                            </div>
                        </li>
                        <li>
                            <div class="sliderbuttons nopadding" href="#">
                                <i class="fa fa-check bbb" aria-hidden="true"></i> Reservation and Road Assistance 24/7
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="container why-us">
        <h1 class="homepagetitle text-center">WHY CHOOSE US</h1>
        
        <div class="col-md-4">
            <div class="icon-box">
                <div class="icon">
                    <i class="fa fa-thumbs-o-up" aria-hidden="true"></i>
                </div>
                <div class="icon-text">
                    <h4 class="title heading-font"> Outstanding Services</h4>
                    <div class="content">
                        <p>Lorem ipsum dolor sit amet, adipiscing elit. Interdum et malesuada fames ac ante ipsum primis in faucibus. Maecenas lobortis vestibulum ipsum vitae pellentesque.</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="icon-box">
                <div class="icon">
                    <i class="fa fa-trophy" aria-hidden="true"></i>
                </div>
                <div class="icon-text">
                    <h4 class="title heading-font"> Name for Quality Vehicles</h4>
                    <div class="content">
                        <p>Lorem ipsum dolor sit amet, adipiscing elit. Interdum et malesuada fames ac ante ipsum primis in faucibus. Maecenas lobortis vestibulum ipsum vitae pellentesque.</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="icon-box">
                <div class="icon">
                    <i class="fa fa-map-marker" aria-hidden="true"></i>
                </div>
                <div class="icon-text">
                    <h4 class="title heading-font"> GPS on Every Vehicle!</h4>
                    <div class="content">
                        <p>Lorem ipsum dolor sit amet, adipiscing elit. Interdum et malesuada fames ac ante ipsum primis in faucibus. Maecenas lobortis vestibulum ipsum vitae pellentesque.</p>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-4">
            <div class="icon-box">
                <div class="icon">
                    <i class="fa fa-child" aria-hidden="true"></i>
                </div>
                <div class="icon-text">
                    <h4 class="title heading-font"> Baby Chairs/Booster Seats</h4>
                    <div class="content">
                        <p>Lorem ipsum dolor sit amet, adipiscing elit. Interdum et malesuada fames ac ante ipsum primis in faucibus. Maecenas lobortis vestibulum ipsum vitae pellentesque.</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="icon-box">
                <div class="icon">
                    <i class="fa fa-cog" aria-hidden="true"></i>
                </div>
                <div class="icon-text">
                    <h4 class="title heading-font"> AT/MT Transmission</h4>
                    <div class="content">
                        <p>Lorem ipsum dolor sit amet, adipiscing elit. Interdum et malesuada fames ac ante ipsum primis in faucibus. Maecenas lobortis vestibulum ipsum vitae pellentesque.</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="icon-box">
                <div class="icon">
                    <i class="fa fa-phone" aria-hidden="true"></i>
                </div>
                <div class="icon-text">
                    <h4 class="title heading-font"> 24 Hours Support</h4>
                    <div class="content">
                        <p>Lorem ipsum dolor sit amet, adipiscing elit. Interdum et malesuada fames ac ante ipsum primis in faucibus. Maecenas lobortis vestibulum ipsum vitae pellentesque.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<footer id="footer-main">
    <div class="container">
        <div class="col-md-3">
            <h6>About <span>RentZone</span></h6>
            <div class="text">
                <p>Lorem ipsum dolor sit amet, adipiscing elit. Interdum et malesuada fames ac ante ipsum primis in faucibus. Maece nas lobortis vestibulum ipsum.</p>
            </div>
        </div>
        <div class="col-md-3">
            <h6>CONTACT INFO</h6>
            <div class="text">
                <p><span>Rentzone office 1:</span> (323) 938-5798</p>
                <p><span>Rentzone office 2:</span> (888) 637-7262</p>
                <p><span>Email:</span> <a href="mailto:info@rentzone.com">rentzone@example.com</a></p>
            </div>
        </div>
        <div class="col-md-3">
            <h6>SERVICE HOURS</h6>
            <div class="text">
                <p><span>Monday - Friday:</span> 09:00AM - 09:00PM</p>
                <p><span>Saturday:</span> 09:00AM - 07:00PM</p>
                <p><span>Sunday:</span> Closed</a></p>
            </div>
        </div>
        <div class="col-md-3">
            <h6>SOCIAL NETWORK</h6>
            <div class="socials_wrapper">
                <ul class="socials_lists">
                    <li><a href="#" target="_blank"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="#" target="_blank"><i class="fa fa-twitter"></i></a></li>
                    <li> <a href="#" target="_blank"> <i class="fa fa-google-plus"></i></a></li>
                </ul>
            </div>
        </div>
    </div>
</footer>
<!-- Scripts -->
<script src="<?php echo e(asset('public/js/libs/jquery-2.1.4.js')); ?>"></script>
<script src="<?php echo e(asset('public/js/libs/bootstrap.min.js')); ?>"></script>
<?php echo $__env->yieldContent('footer'); ?>
</body>
</html>
