<?php $__env->startSection('content'); ?>
    <?php if(count($posts) > 0): ?>
    <h1><?php echo trans('home.Posts'); ?></h1>
    <table class="table-responsive-design">
        <thead>
        <tr>
            <th scope="col">ID</th>
            <th scope="col"><?php echo trans('home.Photo'); ?></th>
            <th scope="col"><?php echo trans('home.OWNER'); ?></th>
            <th scope="col"><?php echo trans('home.TITLE'); ?></th>
            <th scope="col"><?php echo trans('home.Category'); ?></th>
            <th scope="col"><?php echo trans('home.BODY'); ?></th>
            <th scope="col"><?php echo trans('home.CREATED'); ?></th>
            <th scope="col"><?php echo trans('home.UPDATED'); ?></th>
            <th scope="col"><?php echo trans('home.VIEW_POST'); ?></th>
            <th scope="col"><?php echo trans('home.VIEW_COMMENTS'); ?></th>
        </tr>
        </thead>
        <tbody>
        <?php if($posts): ?>
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td data-label="ID"><?php echo e($post->id); ?></td>
                    <td data-label="<?php echo trans('home.Photo'); ?>"><img height="50" src="<?php echo e($post->photo ? $post->photo->file : 'http://via.placeholder.com/200x200'); ?>" alt=""></td>
                    <td data-label="<?php echo trans('home.OWNER'); ?>"><?php echo e($post->user->name); ?></td>
                    <td data-label="<?php echo trans('home.TITLE'); ?>"><a href="<?php echo e(route('admin.posts.edit', $post->id)); ?>"><?php echo e($post->title); ?></a></td>
                    <td data-label="<?php echo trans('home.Category'); ?>"><?php echo e($post->category ? $post->category->name : 'Uncategorized'); ?></td>
                    <td data-label="<?php echo trans('home.BODY'); ?>"><?php echo e(str_limit($post->body,6)); ?></td>
                    <td data-label="<?php echo trans('home.CREATED'); ?>"><?php echo e($post->created_at->diffForHumans()); ?></td>
                    <td data-label="<?php echo trans('home.UPDATED'); ?>"><?php echo e($post->updated_at->diffForHumans()); ?></td>
                    <td data-label="<?php echo trans('home.VIEW_POST'); ?>"><a href="<?php echo e(route('home.post', $post->slug)); ?>"><?php echo trans('home.VIEW_POST'); ?></a></td>
                    <td data-label="<?php echo trans('home.VIEW_COMMENTS'); ?>"><a href="<?php echo e(route('admin.comments.show', $post->id)); ?>"><?php echo trans('home.VIEW_COMMENTS'); ?></a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        </tbody>
    </table>
    <div class="row">
        <div class="col-sm-12 text-center"><?php echo e($posts->render()); ?></div>
    </div>
    <?php else: ?>
        <h1>No Posts</h1>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>