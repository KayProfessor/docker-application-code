@extends('layouts.app')

@section('content')

<h1 class="text-center">404 Page</h1>

@stop